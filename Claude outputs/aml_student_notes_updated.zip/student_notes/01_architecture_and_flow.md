# Chapter 1 — Architecture and execution flow

## 1.1 The one-paragraph version

Python invents 3,400 fake bank customers, each with about thirty days of transactions and one planted pattern. Python then counts everything about those transactions — how many cash deposits sat just under a reporting limit, how much of a large credit left within two days, how many different people paid in during the busiest week. Those counts are written into a short summary in English. A small language model reads the summary and answers with JSON: which pattern this looks like, how risky it is, and one sentence saying why. Every answer is checked before anyone sees it. A six-step workflow then builds a case file around the answer, writes a case note in Python, and waits for a human analyst to approve or override. Everything that happened is appended to a log.

## 1.2 The four stages

```
STAGE 1  DATA          generator.py + patterns.py
                       3,400 synthetic alerts, seed 42
                              ↓
STAGE 2  FEATURES      features.py       "Python counts"
                       templates.py      numbers → English summary
                       dataset.py        → data/*.jsonl
                              ↓
          ┌───────────────────┴───────────────────┐
          ↓                                       ↓
STAGE 3a  RULES (baseline)              STAGE 3b  MODEL
          rules.py                                finetune.py  (Colab, 36 min)
          reads the numbers                       predict.py   (Colab, batched)
          no learning                             schema.py    (output checker)
          ↓                                       ↓
          └───────────────────┬───────────────────┘
                              ↓
STAGE 4   evaluate.py  →  results table
                              ↓
          investigator.py → case_store.py → audit.py → app.py
```

The split in the middle is the important part. The rules and the model are two independent systems solving the same problem from the same data, so their scores can be compared fairly. Most portfolio projects have no baseline at all.

**Stage 5, added later (chapter 22).** An uploaded CSV takes a parallel route into the same machinery:

```
upload.py  →  live.py  →  features.py → templates.py  →  model (local or hosted)
                              ↓                               ↓
                        same numbers                   schema.py (same checker)
                                                              ↓
                                            investigator.py → app.py
```

Nothing in stage 5 is a second implementation. It reuses `compute_features`, `render_summary`, `build_messages` and `check_answer` unchanged, which is the only reason a live verdict is comparable with a scored one.

## 1.3 Execution flow, command by command

This is what actually runs, in order. Everything except training runs on a laptop in seconds.

**Step 1 — generate the raw alerts.**

```bash
python -m src.generator
```

`generator.py` builds 3,400 `RawAlert` objects and writes them to `data/raw/{train,validation,test,heldout}.jsonl`. Each line is one alert with its customer, its window dates, its transactions and its true label. This output is deterministic: seed 42 gives byte-identical files every time.

**Step 2 — build the training examples.**

```bash
python -m src.dataset
```

For every raw alert, `dataset.py` calls `compute_features` (the counting), picks a wording template and renders a summary, then writes `data/{train,validation,test,heldout}.jsonl`. Each line now holds `summary` (what the model reads) and `label` (what it should answer), plus the computed `features`.

**Step 3 — fine-tune on Colab.**

```bash
python -m src.finetune --output-dir /content/drive/MyDrive/aml-adapter
```

Loads Qwen2.5-1.5B-Instruct in 4-bit, attaches LoRA adapters, trains for 2 epochs on the 2,400 training examples, saves the adapter. About 36 minutes on a free T4.

**Step 4 — generate answers, still on Colab.**

```bash
python -m src.predict --adapter /path/to/adapter --split test --output results/finetuned_test.jsonl
python -m src.predict --split test --output results/base_test.jsonl      # no adapter = base model
```

`predict.py` runs the model over a whole split in batches of 16, checks every answer, retries a failed one once, and saves one JSON line per alert.

**Step 5 — score everything.**

```bash
python -m src.evaluate            # validation and test
python -m src.evaluate --final    # also the held-out set, run once
```

`evaluate.py` scores the rules directly from the features and scores the models by reading the saved answer files.

**Step 6 — the review app.**

```bash
streamlit run app.py
```

Reads the dataset, the saved answers and the rules, and puts them in front of a human.

## 1.4 Why the laptop/GPU split matters

Notice which steps need a GPU: only steps 3 and 4. Everything else — generating data, computing features, scoring, the app — is plain Python with no heavy libraries. This is why there are two requirements files:

```
requirements.txt          pytest, streamlit, pandas          (laptop)
requirements-train.txt    transformers, peft, bitsandbytes,
                          accelerate, datasets                (Colab only)
```

The consequence that matters for the demo: because `predict.py` saved its answers to files, the app can show the model's verdicts without ever loading the model. That is how a 1.5B model "runs" on a free Streamlit host with no GPU. It does not run. Its homework is on file.

**Interview phrasing:** "Inference is offline and batched. The app reads saved verdicts, which is why it deploys anywhere. Live inference would need a GPU service behind an API, and that is the obvious next step."

## 1.5 The dependency graph of the source files

Arrows mean "imports".

```
models.py     ← nothing            (plain data containers)
money.py      ← nothing            (text helpers)
names.py      ← nothing            (name pools)
schema.py     ← nothing            (labels + the output checker)
patterns.py   ← models, names
generator.py  ← models, names, patterns, schema
features.py   ← models, money, patterns, schema
templates.py  ← features, money, patterns
dataset.py    ← features, generator, models, schema, templates
metrics.py    ← schema
rules.py      ← metrics, schema
prompt.py     ← schema
finetune.py   ← dataset, prompt
predict.py    ← dataset, prompt, schema
evaluate.py   ← dataset, metrics, rules, schema
review.py     ← dataset, evaluate, features, patterns, rules, schema
review_scores.py ← dataset, evaluate, review, rules
audit.py      ← nothing
case_store.py ← audit
case_note.py  ← money, review, schema
investigator.py ← audit, case_note, case_store, review, schema
app.py        ← audit, case_store, investigator, money, review, review_scores, schema
```

Two things to notice.

**`schema.py` sits at the bottom with no imports of its own.** It holds the label lists that everything else agrees on. If you added a sixth typology, that file is where you would start, and the import graph shows why: changing it ripples outward to the generator, the rules, the prompt and the app.

**Nothing imports `app.py`, and `app.py` imports Streamlit.** All the logic lives in `review.py`, `investigator.py` and friends, which import no UI library at all. That is why the workflow can be tested without a browser — and `tests/test_investigator.py` has eleven tests that do exactly that.

## 1.6 The three ideas the architecture is built on

**Idea 1: the model never produces a number.** Every figure in every output traces back to `features.py`. The summary is rendered from computed values; the case note is written by Python from the same values; the only free text the model generates is a one-line reason, and that line is checked to make sure every number in it already appeared in the input. The architectural consequence is that hallucinated figures are not a risk you manage, they are a thing the design makes impossible.

**Idea 2: the baseline is taken seriously.** `rules.py` is not a straw man. It is tuned by grid search over 1,920 threshold combinations on the training set, and it wins on held-out data. Building a strong baseline and then reporting that it beat your model is the opposite of what most projects do, and it is the single most credible thing here.

**Idea 3: nothing happens without a human.** Exports are blocked until a decision is recorded (`ExportBlockedError`), an override requires a written note, the model's verdict is never altered, and the log is append-only. These are enforced in code, not described in a README.

## 1.7 A single alert's journey

Follow alert `A-test-0308` all the way through:

1. **Generated.** `generate_alert` creates customer `C-test-0308`, a homemaker with declared income ₹19,000 a month and a 16-month-old account. Everyday activity is added first (a spouse transfer, rent, groceries, ATM withdrawals), then `plant_structuring` adds 11 cash deposits of roughly ₹40,000–₹47,000 within five days.
2. **Counted.** `compute_features` finds `just_under_count = 11`, `just_under_total = 498300`, `just_under_span_days = 5`, `credits_ratio = 27.2`.
3. **Written.** `pick_template` chooses `terse`; `render_summary` produces `homemaker | income ₹19,000/month | account 16 months | cash in: count 11, total ₹4,98,300; just under ₹50,000: 11 (₹4,98,300, 26.2x income, 5 days) | ...`
4. **Labelled.** `risk_level` sees a ratio of 26.2, which is above 15, so risk is `high`. `reason_for` writes the ground-truth sentence.
5. **Classified.** On Colab, the fine-tuned model reads the summary and answers `{"typology": "STRUCTURING", "risk": "high", "reason": "11 cash deposits just under the ₹50,000 limit within 5 days, totalling ₹4,98,300."}`
6. **Checked.** `check_answer` parses the JSON, confirms the label and risk are in the allowed lists, confirms the reason is under 200 characters, finds no banned words, and confirms every number in the reason appears in the summary. Valid.
7. **Investigated.** In the app, `run_investigation` records five steps, computes two findings, and drafts a case note in Markdown.
8. **Decided.** The analyst clicks Approve. `record_decision` writes the decision into the case file and appends a log line whose `before` is the model's verdict and whose `after` is the analyst's.

Every stage is a separate, testable function. That is the architecture.

## 1.8 Exercises

1. Draw the pipeline from memory, then check it against §1.2. Which stage would you have to change to add a fifth typology?
2. Open `src/review.py` and confirm it imports no Streamlit. Why does that matter for testing?
3. From §1.5, work out what would break if `schema.py` imported `features.py`. (Hint: trace the cycle.)
4. Run `python -m src.generator` twice and compare the files with `md5sum data/raw/test.jsonl`. Explain why they match.
