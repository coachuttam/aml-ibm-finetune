# Chapter 8 — Language model fundamentals

Background for Chapters 9 to 11. No code from the project here; this is the theory you need to explain *why* the code looks as it does.

---

## 8.1 What a language model does

A language model predicts the next token given the tokens so far. That is the entire mechanism. Everything else — answering, classifying, writing JSON — is that one operation repeated.

Given `The cat sat on the`, the model outputs a probability for every token in its vocabulary: `mat` 0.31, `floor` 0.08, `table` 0.05, and so on across roughly 150,000 options for Qwen2.5. One is chosen, appended, and the whole sequence is fed back in for the next token.

Your model producing `{"typology": "STRUCTURING", "risk": "high", "reason": "11 cash deposits..."}` is doing exactly this, about forty times in a row. There is no classification head and no separate "decide the label" step. The label is simply the tokens that were most likely after `{"typology": "`.

This explains something that confuses people about the project: **why validate the output at all, if the model was trained to produce JSON?** Because nothing guarantees it. The model is sampling likely continuations, and a likely continuation is not a guaranteed one. Chapter 11 is about that gap.

---

## 8.2 Tokens

Models do not read characters or words. They read **tokens** — subword pieces from a fixed vocabulary learned before training.

Roughly: common words are one token, rare words split into several, and a token is about four characters of English.

```
"structuring"  →  ["struct", "uring"]        (approximate)
"₹4,98,300"    →  ["₹", "4", ",", "98", ",", "300"]
```

Three consequences for this project:

**Numbers tokenise badly.** `498300` is several tokens, and the model has no concept of its magnitude. It cannot reliably compare ₹4,98,300 with ₹50,000, because arithmetic over token sequences is something language models do poorly. This is a direct argument for the project's core rule: Python counts, the model labels. The design works *with* the weakness rather than against it.

**Token counts are not word counts.** `MAX_SEQ_LENGTH = 512` in `finetune.py` is 512 tokens, and the comment says summaries are under about 190 tokens. A 150-word summary is roughly 190 tokens because of punctuation, the rupee sign and digit splitting.

**The rupee sign costs tokens.** `₹` is non-ASCII and may be several bytes, so every amount is more expensive than it looks. Irrelevant at this scale, but it is the sort of thing that matters when you are paying per token.

---

## 8.3 The transformer, in the detail you need

The model is a stack of identical blocks (28 of them in Qwen2.5-1.5B). Each block does two things.

### Self-attention

Every token looks at every earlier token and decides how much to take from each. Mechanically, each token produces three vectors:

- **Query** — what am I looking for?
- **Key** — what do I offer?
- **Value** — what do I contribute?

A token's query is compared against every key; the resulting scores become weights; the output is the weighted sum of the values.

```latex
\text{Attention}(Q,K,V) = \text{softmax}\!\left(\frac{QK^{\top}}{\sqrt{d_k}}\right)V
```

The division by √d_k keeps the scores from growing with dimension and pushing softmax into a region where gradients vanish.

In a causal (decoder-only) model like Qwen, a token may only attend to tokens **before** it — enforced by masking future positions to −∞ before the softmax. That is what makes next-token prediction well defined.

What this means concretely for your model: when it is generating the `reason` field, the attention mechanism is what lets it copy `₹4,98,300` from the summary forty tokens earlier. Faithfulness is, mechanically, an attention and copying behaviour.

### Feed-forward network

After attention, each position goes through a two-layer MLP independently. This is where most of the parameters live — typically four times wider than the model dimension.

Why it matters for Chapter 9: `target_modules="all-linear"` puts LoRA adapters on **both** the attention projections and these feed-forward layers. The original LoRA paper only adapted attention; adapting everything is now standard and is what gives 18.5M trainable parameters rather than about 5M.

### The pieces around them

Residual connections (add the input back after each sub-layer), layer normalisation (RMSNorm in Qwen), and rotary position embeddings (RoPE) to encode order. You do not need these in depth, but knowing the names prevents a blank look.

---

## 8.4 Base models and instruct models

A **base model** is trained on raw text to continue it. Ask it a question and it may continue with more questions, because that is what a page of questions looks like.

An **instruct model** has been further trained on instruction–response pairs, plus usually a preference-alignment stage, so it answers rather than continues.

Your project starts from `Qwen2.5-1.5B-Instruct`. That choice saves work: the model already understands "follow this instruction and reply". Fine-tuning only has to teach the AML task and the exact output contract.

There is evidence of this in your own results. The untuned base model scored 0.135 but produced **valid JSON 88.5% of the time on test**. It had no idea what structuring was — but it followed the format instruction. That is instruction tuning working, with the task knowledge missing. A non-instruct base model would likely have produced far less valid JSON.

---

## 8.5 Chat templates

Instruct models are trained with special tokens marking who is speaking. Qwen uses ChatML:

```
<|im_start|>system
You are an anti-money-laundering assistant...<|im_end|>
<|im_start|>user
homemaker | income ₹19,000/month | ...<|im_end|>
<|im_start|>assistant
{"typology": "STRUCTURING", ...}<|im_end|>
```

Different model families use different markers — Llama uses `[INST]`, others use their own. Getting this wrong is a classic silent failure: training appears to work, loss goes down, and quality is mysteriously poor, because you fought the pretraining instead of building on it.

Your code never writes these tokens by hand:

```python
tokenizer.apply_chat_template(build_messages(summary), tokenize=False, add_generation_prompt=True)
```

The tokenizer knows its own model's format. `add_generation_prompt=True` appends the opening `<|im_start|>assistant` so the model knows it is its turn.

The same call appears in `finetune.py` and `predict.py`, both built from `prompt.py`. That is deliberate: if training and inference formatted the prompt differently, the model would see something at inference it had never been trained on. Chapter 10 returns to this.

---

## 8.6 How training works

**Forward pass.** Feed in the tokens, get a probability distribution for each next position.

**Loss.** Cross-entropy: how surprised was the model by the token that actually came next?

```latex
\mathcal{L} = -\frac{1}{N}\sum_{i=1}^{N} \log p(t_i \mid t_{<i})
```

If the model gave the correct token probability 1.0, the loss contribution is 0. If it gave 0.5, the contribution is 0.69. Lower is better; 0 is perfect prediction.

**Backward pass.** Backpropagation computes, for every trainable parameter, the gradient of the loss with respect to it.

**Update.** The optimiser (AdamW here, the Trainer default) nudges each parameter against its gradient, scaled by the learning rate.

That cycle is one **step**. Your run did 300 of them.

### Why your loss of 0.0006 is not impressive

The loss is averaged over the tokens the model is asked to predict. In your setup those are only the answer tokens — about forty tokens of JSON with five possible labels, three possible risk levels, and a reason sentence drawn from five templated shapes with the numbers copied from the input.

That is a very narrow distribution. Reaching near-zero loss means the model learned the format, which was easy. It says almost nothing about whether it learned to distinguish a mule account from a cash-heavy shop.

**The correct interview answer:** "Low eval loss told me training ran correctly, and nothing more. The output space is tiny and loss is masked to the answer only, so a low number was expected. The result I actually trusted was macro-F1 on held-out wording, which was 0.936 against 0.990 for tuned rules."

Anyone senior will like that answer, because treating a suspiciously good number with suspicion is the instinct they are testing for.

---

## 8.7 Generation at inference

Training and inference are different operations. Training sees the whole correct answer at once and learns to predict each token from the ones before. Inference produces tokens one at a time, feeding each back in.

**Greedy decoding** always takes the highest-probability token. Deterministic — the same input gives the same output every time.

**Sampling** draws from the distribution, shaped by temperature (flattens or sharpens it) and top-p (restricts to the smallest set of tokens covering probability p).

Your `predict.py` uses `do_sample=False`, which is greedy. Two reasons, and you should give both:

1. **Valid JSON.** Every sampled token is a chance to produce a stray character that breaks the parse.
2. **Reproducibility.** In a regulated setting, the same alert must produce the same verdict twice. A sampled model cannot promise that.

**The KV cache.** Generating token 50 requires attention over tokens 1–49, whose keys and values were already computed when those tokens were generated. The cache stores them so they are not recomputed each step. Without it, generation is quadratic; with it, roughly linear. It is on by default in `model.generate`, which is why it never appears in your code — but you should know it is there.

---

## 8.8 Why 1.5B was the right size

| | Small (1.5B) | Large (70B) |
| --- | --- | --- |
| Fits a free T4 | yes, in 4-bit | no |
| Fine-tuning cost | 36 minutes, free | hours, hundreds of dollars |
| Inference | fast, cheap, CPU-feasible | GPU cluster |
| Reasoning depth | limited | strong |
| Runs inside a bank | yes | hard |

The task is narrow: read a summary where the deciding numbers are printed, pick one of five labels, copy a figure into a sentence. It needs pattern matching, not reasoning. A 70B model would score similarly and cost orders of magnitude more.

There is a second argument that matters for a banking employer: a 1.5B model can run on the bank's own hardware, so customer data never leaves the building. For AML data that is often not a preference but a requirement.

---

## 8.9 Exercises

1. Explain cross-entropy loss to someone who knows no maths, in three sentences.
2. Why can a language model not reliably compare ₹48,000 with ₹50,000? Tie your answer to tokenisation.
3. What would happen if you fine-tuned a Qwen model using Llama's `[INST]` markers? Would you notice?
4. Your base model produced valid JSON 88.5% of the time on test but only 72.0% on held-out. Why would *format* compliance drop when only the wording of the input changed?
5. Give two reasons for greedy decoding in this project, one technical and one regulatory.
6. If the task required explaining an unusual pattern in a paragraph rather than filling a template, would 1.5B still be enough? Argue both sides.
