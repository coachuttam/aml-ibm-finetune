# Chapter 11 — Inference and guardrails (`predict.py`, `schema.py`)

The chapter about not trusting your own model.

---

## 11.1 The problem

The model was trained to produce JSON. It mostly does. "Mostly" is the issue.

A language model samples likely continuations. Nothing in the architecture guarantees balanced braces, a label from your list, or a number that appeared in the input. Training makes failure unlikely, not impossible — and on your held-out set it happened: valid JSON was 99.7%, which is one failure in 300.

In a bank, "almost always correct and occasionally silently wrong" is worse than "correct or clearly refusing". So every answer passes a checker before anyone sees it.

---

## 11.2 The output checker in `schema.py`

```python
@dataclass(frozen=True)
class CheckedAnswer:
    """The result of checking one model answer."""
    valid: bool
    typology: Optional[str]
    risk: Optional[str]
    reason: Optional[str]
    problems: List[str]
```

The result carries the parsed fields **and** the list of what went wrong. A failed answer is not discarded — its problems are recorded, saved to `results/`, and shown in the app ("Needs review: ..."). You can audit why the model failed, not just that it did.

### Parsing tolerantly

```python
def parse_json_object(raw_text: str) -> Optional[dict]:
    """The JSON object in the text, or None. Tolerates text around the braces."""
    start, end = raw_text.find("{"), raw_text.rfind("}")
    if start == -1 or end <= start:
        return None
    try:
        parsed = json.loads(raw_text[start:end + 1])
    except ValueError:
        return None
    return parsed if isinstance(parsed, dict) else None
```

Rather than `json.loads(raw_text)` directly, it finds the first `{` and the **last** `}` and parses what is between.

Why: models add commentary. `Here is the answer: {"typology": ...} Let me know if you need more.` is common, especially from the untuned base model. Strict parsing would reject a perfectly good answer.

Three guards in nine lines:

- `start == -1` — no brace at all.
- `end <= start` — the last `}` comes before the first `{`, so there is no object.
- `isinstance(parsed, dict)` — the text `[1, 2, 3]` would parse as valid JSON but is not an object.

`except ValueError` catches `json.JSONDecodeError`, which subclasses it. Catching the parent is slightly broader but perfectly safe here.

**Is tolerant parsing cheating?** A fair question, and the honest answer is no with a caveat: the validity rate measures *whether a usable answer could be extracted*, not whether the raw output was pure JSON. The base model's 88.5% benefits from this tolerance. Stating that is better than letting someone find it.

### The five checks

```python
def find_problems(answer: dict, summary: str) -> List[str]:
    """Everything wrong with a parsed answer. An empty list means it is fine."""
    problems = []
    if answer.get("typology") not in ALL_LABELS:
        problems.append("typology is not one of the allowed labels")
    if answer.get("risk") not in RISK_LEVELS:
        problems.append("risk is not one of the allowed levels")
    reason = answer.get("reason")
    if not isinstance(reason, str) or not reason.strip():
        return problems + ["reason is missing"]
    if len(reason) > MAX_REASON_LENGTH:
        problems.append("reason is too long")
    if any(word in reason.lower() for word in BANNED_WORDS):
        problems.append("reason uses accusing wording")
    if numbers_in(reason) - numbers_in(summary):
        problems.append("reason uses a number that is not in the summary")
    return problems
```

| Check | Catches |
| --- | --- |
| typology in `ALL_LABELS` | invented labels like `SUSPICIOUS` |
| risk in `RISK_LEVELS` | `critical`, `very high` |
| reason present and non-empty | a missing field |
| reason ≤ 200 characters | a rambling paragraph |
| no banned words | "this is fraud" |
| every number appears in the summary | **invented figures** |

`answer.get("typology")` rather than `answer["typology"]` — `.get` returns `None` for a missing key instead of raising, and `None` is not in `ALL_LABELS`, so a missing field is caught by the same comparison.

The early `return problems + ["reason is missing"]` stops the later checks running on a non-string, which would raise.

`any(word in reason.lower() for word in BANNED_WORDS)` — a substring test, so "fraudulent" is caught by "fraud". It would also catch "fraud" inside an innocent word, which is a false positive this project accepts deliberately: over-refusing is the safe direction.

### The faithfulness check — the important one

```python
def numbers_in(text: str) -> set:
    """Every number in the text, with thousands separators removed."""
    return {match.replace(",", "") for match in re.findall(r"\d[\d,]*", text)}
```

The regex `\d[\d,]*` means: a digit, then any run of digits and commas. So `₹4,98,300` yields `4,98,300`, and stripping commas gives `"498300"`.

Then:

```python
if numbers_in(reason) - numbers_in(summary):
```

Set subtraction: numbers in the reason that are **not** in the summary. A non-empty result means the model produced a figure that was not in its input — the definition of a hallucinated number in this system.

Worked example:

```
summary: "... cash in: count 11, total ₹4,98,300; just under ₹50,000: 11 ..."
reason:  "11 cash deposits just under the ₹50,000 limit within 5 days, totalling ₹4,98,300."

numbers_in(summary) = {"11", "498300", "50000", "19000", "16", "5", "26.2", ...}
numbers_in(reason)  = {"11", "50000", "5", "498300"}
difference          = {}   → faithful
```

If the model had written `totalling ₹5,00,000`, the difference would be `{"500000"}` and the answer would be rejected.

### What the check does not do

Be precise about this, because the usual description of the project overstates it.

- It compares against the **summary text**, not the raw transactions. So a figure that is in the summary but wrongly *used* passes. The model could say "11 cash deposits within 50000 days" — both numbers are present, so no problem is raised.
- It is a set comparison, so it ignores position, units and meaning.
- `26.2` and `26` are different strings, so a rounding change would be flagged. Strict in that direction.

The right way to describe it: **"a cheap, high-recall check for invented figures, not a semantic verification."** It catches the failure mode that matters — numbers from nowhere — and it is explainable to a non-technical reviewer in one sentence, which is worth a great deal in compliance.

### Tying it together

```python
def check_answer(raw_text: str, summary: str) -> CheckedAnswer:
    answer = parse_json_object(raw_text)
    if answer is None:
        return CheckedAnswer(False, None, None, None, ["output is not valid JSON"])
    problems = find_problems(answer, summary)
    return CheckedAnswer(not problems, answer.get("typology"), answer.get("risk"),
                         answer.get("reason"), problems)
```

`valid = not problems` — an empty list is falsy, so no problems means valid.

Note that the fields are returned **even when invalid**, so the app can show what the model said alongside why it was rejected.

---

## 11.3 Retry, then refuse

```python
def classify_with_retry(summary: str, generate: GenerateFunction) -> CheckedAnswer:
    """Ask the model; if the answer fails the checks, ask once more.

    A second failure is returned as-is (valid=False), so the alert goes to "needs review".
    """
    checked = check_answer(generate(summary), summary)
    if checked.valid:
        return checked
    return check_answer(generate(summary), summary)
```

One retry. Not three, not a loop.

**Why retry at all** when decoding is greedy and deterministic? With `do_sample=False` the second call produces the same text, so the retry cannot help in the batch path... except that the retry goes through `generate`, the **single-item** function, while the first attempt in the batch path came from `generate_batch`. Batched generation uses left padding, and padding can very slightly change the output. So the retry is a genuinely different computation, and that is the only reason it can succeed.

This is a subtle point and worth knowing, because it is the kind of thing an interviewer who reads the code will spot. The honest framing: *"The retry exists mainly to handle the batched path, where padding differences can change output. With pure greedy single-item decoding it would be a no-op, and a sampled model would make the retry much more useful."*

**Why only one retry.** Each retry costs a full generation. If the model fails twice, something is wrong with the alert — unusual wording, an edge case — and a human should look. In AML an alert going to manual review is an acceptable outcome; a wrong verdict is not. The failure mode is chosen deliberately: **fail safe, not fail silent.**

---

## 11.4 Batched generation

```python
def load_model(adapter_folder: Optional[str], base_model: str = BASE_MODEL):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

    tokenizer = AutoTokenizer.from_pretrained(base_model)
    tokenizer.padding_side = "left"          # so every answer starts right after its own prompt
    quantisation = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4",
                                      bnb_4bit_compute_dtype=torch.float16)
    model = AutoModelForCausalLM.from_pretrained(
        base_model, quantization_config=quantisation, device_map={"": 0})
    if adapter_folder:
        from peft import PeftModel
        model = PeftModel.from_pretrained(model, adapter_folder)
    model.eval()

    def generate_batch(summaries: List[str]) -> List[str]:
        prompts = [tokenizer.apply_chat_template(build_messages(s), tokenize=False,
                                                 add_generation_prompt=True) for s in summaries]
        inputs = tokenizer(prompts, return_tensors="pt", padding=True).to(model.device)
        with torch.no_grad():
            output = model.generate(**inputs, max_new_tokens=MAX_NEW_TOKENS, do_sample=False,
                                    pad_token_id=tokenizer.pad_token_id)
        new_tokens = output[:, inputs["input_ids"].shape[1]:]
        return tokenizer.batch_decode(new_tokens, skip_special_tokens=True)

    def generate(summary: str) -> str:
        return generate_batch([summary])[0]

    return generate, generate_batch
```

### Left padding — the detail that catches everyone

```python
tokenizer.padding_side = "left"
```

For **training**, padding goes on the right; the attention mask handles it and nothing is generated.

For **generation**, padding must go on the **left**. Generation continues from the last position of the sequence. With right padding, a short prompt's last position is a pad token, and the model would continue from padding rather than from the end of the prompt.

```
RIGHT padding (wrong for generation):
  [prompt tokens][PAD][PAD][PAD] → generate from here ✗

LEFT padding (correct):
  [PAD][PAD][PAD][prompt tokens] → generate from here ✓
```

Get this wrong and generation produces garbage for every sequence except the longest. The comment in the code says exactly why, which is good practice.

### Slicing off the prompt

```python
new_tokens = output[:, inputs["input_ids"].shape[1]:]
```

`model.generate` returns the prompt **and** the continuation. This slices columns from the prompt length onwards, keeping only what was generated. `[:, n:]` is PyTorch tensor slicing: all rows, columns from `n`. Because padding is on the left, every row's prompt occupies the same number of columns, so one slice works for the whole batch.

### `torch.no_grad()` and `model.eval()`

`model.eval()` switches off dropout — including LoRA dropout — so inference is deterministic.

`with torch.no_grad()` stops PyTorch building the computation graph for backpropagation. Inference needs no gradients, and skipping them saves a large amount of memory and some time. Forgetting it is one of the most common causes of out-of-memory errors at inference.

### Why batching matters

The README's problems table records it: generating answers one at a time took about **40 minutes**; batching 16 at a time cut it substantially.

The reason is that generation is **memory-bandwidth bound**, not compute bound. Most of the time is spent moving weights from GPU memory into compute units. Processing 16 sequences at once moves the weights once instead of sixteen times. The GPU was idle most of the time in the single path.

This is a real, specific inference-optimisation story, and it is rarer in candidates than training knowledge.

### Returning two functions

```python
return generate, generate_batch
```

`load_model` returns a **closure** over the model and tokenizer. Callers get two plain functions and never touch the model object.

That is what makes the whole module testable:

```python
GenerateFunction = Callable[[str], str]
```

Any function from string to string fits. `tests/test_predict.py` passes fakes — one that returns valid JSON, one that returns broken JSON, one that fails then succeeds — and tests the retry and checking logic with no GPU and no torch. Ten tests, instant.

**This is the best design decision in the file,** and it generalises: separate the part that needs expensive infrastructure from the part that holds the logic, and connect them with a function type.

---

## 11.5 Running a whole split

```python
def predict_split(examples, generate, generate_batch=None, batch_size=BATCH_SIZE):
    rows = []
    for start in range(0, len(examples), batch_size):
        chunk = examples[start:start + batch_size]
        if generate_batch is None:
            checked_answers = [classify_with_retry(e["summary"], generate) for e in chunk]
        else:
            texts = generate_batch([e["summary"] for e in chunk])
            checked_answers = [check_with_one_retry(e["summary"], text, generate)
                               for e, text in zip(chunk, texts)]
        rows.extend(to_row(e, checked) for e, checked in zip(chunk, checked_answers))
        print(f"  answered {len(rows)} of {len(examples)}", flush=True)
    return rows
```

`range(0, len(examples), batch_size)` steps in chunks of 16. `examples[start:start + batch_size]` is safe past the end, so the final partial batch needs no special case.

```python
def check_with_one_retry(summary: str, first_text: str, generate) -> CheckedAnswer:
    """Check an answer already generated; if it fails, ask once more on its own."""
    checked = check_answer(first_text, summary)
    return checked if checked.valid else check_answer(generate(summary), summary)
```

The batch path needs this variant because the first answer already exists — generated as part of the batch — so only the retry needs a new call. Failures are rare, so the retries are individual and cheap.

`print(..., flush=True)` forces the output to appear immediately. Without it, Python buffers stdout and a Colab cell shows nothing for minutes, which looks like a hang.

The saved row:

```python
def to_row(example: dict, checked: CheckedAnswer) -> dict:
    return {"alert_id": example["alert_id"], "valid": checked.valid,
            "typology": checked.typology, "risk": checked.risk,
            "reason": checked.reason, "problems": checked.problems}
```

Including `problems` is what lets `evaluate.py` compute the faithfulness rate later, by counting how many rows carry the specific problem string. The checking happens once, on the GPU machine, and everything downstream reads the record.

---

## 11.6 The same checker, on the live path

> **Later change (chapter 22).** When an alert is uploaded in the Live run tab, `live.ask_model` calls `check_answer` and retries once on failure — the same two-attempt logic as `classify_with_retry` here. Nothing about the checker changed, and that is the point: a live answer passes exactly the gate a scored answer did. An answer that fails twice, a model that is not connected, and a hosted model that times out all land in the same state — "needs review" — so the screen needs no new case for any of them.

## 11.7 What a stronger guardrail design would look like

Worth having ready, because "what would you do differently" is a near-certain question.

**Constrained decoding.** Instead of checking afterwards, restrict the sampler at each step to tokens that keep the output valid against a JSON schema or grammar. Invalid output becomes impossible rather than unlikely. vLLM's guided decoding and libraries such as Outlines do this.

Why this project did not: it adds a dependency and ties you to a serving stack, and the fallback here is acceptable. In AML, an alert going to a human is a fine outcome, so a hard guarantee was not worth the complexity.

**Semantic verification.** Check not just that numbers appear in the input but that they are used correctly — that the number next to "cash deposits" is actually the cash deposit count. Harder, and arguably the job of the structured output rather than the free text.

**A confidence signal.** The model gives no indication of how sure it is. Token log-probabilities could be surfaced so an analyst sees "the model was uncertain between mule and pass-through". That would be genuinely useful in a review screen and is a good answer to "how would you extend this?".

---

## 11.8 Exercises

1. Run `check_answer('{"typology": "STRUCTURING", "risk": "high", "reason": "9 deposits totalling 500000."}', "... 11 deposits totalling 498300 ...")`. Which problem fires?
2. Why is the parser tolerant of text around the braces? Write an input where strict parsing would wrongly reject a good answer.
3. `numbers_in` strips commas. What happens to `26.2`? Is the decimal point handled?
4. Explain left padding with a diagram, then predict the exact failure if it were set to right.
5. Write a fake generate function that fails once then succeeds, and verify `classify_with_retry` returns a valid answer.
6. Argue for and against replacing the checker with constrained decoding, in a banking context.
7. The faithfulness check compares against the summary, not the transactions. Construct an answer that passes the check but is still wrong.
