# Chapter 5 — Feature engineering (`features.py`)

> "This is where 'Python counts' happens. The model later reads a summary built from these numbers and never produces a number of its own." — the module docstring

280 lines, the heart of the project. It turns a list of transactions into about thirty numbers, then derives the risk level and the ground-truth reason from them.

---

## 5.1 The constants, and why each one exists

```python
LARGE_AMOUNT = 50_000        # a single credit this large is worth following
QUICK_EXIT_DAYS = 2          # "sent on quickly" means within this many days
SENDER_WINDOW_DAYS = 7       # a burst of senders is looked for in any 7-day span
CASH_OUT_DAYS = 5            # after the burst, "cashed out" means within this many days
RETURN_DAYS = 15             # money "came back" if it returns within this many days
RETURN_MIN = 10_000          # ...and the payment out was at least this large
RETURN_LOW, RETURN_HIGH = 0.90, 1.05   # ...and the amount back is 90%–105%
RETURNABLE_CHANNELS = ("neft", "rtgs", "imps", "upi")
MIN_SENDERS = 3
TOP_PAYEES = 3

MEDIUM_RATIO = 5.0
HIGH_RATIO = 15.0
```

`AGENTS.md` bans magic numbers: "Thresholds, window lengths and seeds are named constants at the top of the file, each with a one-line reason." Every constant here has its comment.

Why this matters beyond tidiness: these numbers are the *definitions* of the patterns. "Rapid pass-through" is not a concept the code has — it is `large_count >= 1 and money left within 2 days`. Making the definitions visible and named means a domain expert could read the top of the file and tell you the thresholds are wrong, without reading any code. In a bank, that conversation is the whole job.

The risk cut-offs carry an extra comment:

```python
# These cut-offs were chosen by looking at the training set only: they give each
# pattern a spread of low, medium and high (about 14%, 47% and 39% overall).
```

That sentence is methodological evidence. It says where the numbers came from and confirms the held-out set was not consulted.

---

## 5.2 The `Features` dataclass

```python
@dataclass(frozen=True)
class Features:
    """All the numbers an analyst would want, computed from one alert's transactions."""

    occupation: str
    income: int
    account_age_months: int
    # Cash
    cash_count: int
    cash_total: int
    just_under_count: int
    just_under_total: int
    just_under_span_days: int
    just_under_ratio: float
    # Large credits that left quickly
    large_count: int
    large_total: int
    quick_exit_amount: int
    quick_exit_percent: int
    quick_exit_ratio: float
    # Many senders, then a cash-out
    sender_count: int
    sender_total: int
    sender_span_days: int
    cash_out_percent: int
    sender_ratio: float
    # Money that came back
    return_count: int
    return_total: int
    return_percent: int
    return_same_party: int
    return_ratio: float
    # Overall
    top_payees: List[Tuple[str, int]]
    credits_total: int
    debits_total: int
    credits_ratio: float
```

The comment headings group the fields by pattern. Four groups of features, four typologies — not a coincidence. Each group was designed to make one pattern visible in numbers.

Notice the three kinds of number in each group:

- a **count** (`just_under_count`) — how many
- a **total** (`just_under_total`) — how much
- a **ratio** (`just_under_ratio`) — how much compared with monthly income

The ratio is what makes risk comparable across customers. ₹5,00,000 is routine for a trader earning ₹1,50,000 a month and extraordinary for a student earning ₹10,000.

---

## 5.3 Three tiny helpers that prevent three classes of bug

```python
def ratio_to_income(amount: int, income: int) -> float:
    """How many months of declared income this amount equals, to one decimal."""
    return round(amount / income, 1) if income else 0.0


def percent(part: int, whole: int) -> int:
    """A whole-number percentage, capped at 100."""
    return min(100, round(100 * part / whole)) if whole else 0


def days_between(first, last) -> int:
    """Days from first to last, counting both ends."""
    return (last - first).days + 1
```

**`ratio_to_income`** guards against division by zero. `if income else 0.0` relies on `0` being falsy in Python.

**`percent`** does two things. It guards division by zero, and it caps at 100. The cap matters: in `large_credit_features`, money leaving within two days is compared against the large credits that arrived, and other money can leave in the same window, so the raw figure could exceed 100%. A summary saying "140% of the credits was sent on" would be nonsense. (There is a second guard in the same function, `min(out, credit.amount)`, so the cap is belt and braces.)

**`days_between`** adds 1 deliberately. Deposits on day 3 and day 6 span **4** days, not 3, because both ends count. Off-by-one errors in date spans are among the most common bugs in this kind of code, and there is a test pinning it:

```python
assert features.just_under_span_days == 4   # day 3 to day 6, both included
```

---

## 5.4 The four feature functions

### Cash

```python
def cash_features(credits: List[Transaction]) -> Dict[str, int]:
    cash = [c for c in credits if c.channel == "cash"]
    low = JUST_UNDER_LOW * CASH_REPORTING_LIMIT      # 40,000
    high = JUST_UNDER_HIGH * CASH_REPORTING_LIMIT    # 49,500
    just_under = [c for c in cash if low <= c.amount <= high]
    span = days_between(min(c.day for c in just_under), max(c.day for c in just_under)) if just_under else 0
    return {
        "cash_count": len(cash),
        "cash_total": sum(c.amount for c in cash),
        "just_under_count": len(just_under),
        "just_under_total": sum(c.amount for c in just_under),
        "just_under_span_days": span,
    }
```

`low <= c.amount <= high` is **chained comparison**, a Python feature most languages lack. It means `low <= c.amount and c.amount <= high`, and `c.amount` is evaluated once.

`min(c.day for c in just_under)` is a **generator expression** — no intermediate list is built. The `if just_under else 0` guard is essential: `min()` on an empty sequence raises `ValueError`.

Note the shape of the return: a plain `dict`, not a `Features` object. Each of the four functions returns a dict of its own fields, and `compute_features` merges them. The reason appears in §5.5.

### Large credits that left quickly

```python
def large_credit_features(credits, external_debits) -> Dict[str, int]:
    large = [c for c in credits if c.amount >= LARGE_AMOUNT]
    sent_on = 0
    for credit in large:
        out = sum(d.amount for d in external_debits if 0 <= (d.day - credit.day).days <= QUICK_EXIT_DAYS)
        sent_on += min(out, credit.amount)
    large_total = sum(c.amount for c in large)
    return {
        "large_count": len(large),
        "large_total": large_total,
        "quick_exit_amount": sent_on,
        "quick_exit_percent": percent(sent_on, large_total),
    }
```

For each large credit, sum every outgoing payment within 0 to 2 days of it, then take `min(out, credit.amount)` so a credit cannot send on more than it brought in.

Two subtleties worth knowing:

- `0 <= (d.day - credit.day).days` means same day or later. A payment the day *before* the credit arrived does not count, which is correct — it cannot be the same money.
- **The same debit can be counted against two credits** if two large credits land within two days of each other. `sent_on` would then double count. The `min(out, credit.amount)` cap limits each contribution, and `percent` caps the result at 100, so the number stays sane, but it is an approximation rather than a true matching. Being able to say that out loud is a sign you have read your own code.

`external_debits` excludes the `internal` channel. That single exclusion is what makes the `house_sale` hard negative work.

### The busiest week

```python
def busiest_week(paid_in: List[Transaction]) -> List[Transaction]:
    """The payments in the 7-day span that has the most different senders."""
    ordered = sorted(paid_in, key=lambda c: (c.day, c.txn_id))
    best: List[Transaction] = []
    most_senders = 0
    for first in ordered:
        span = [c for c in ordered if 0 <= (c.day - first.day).days < SENDER_WINDOW_DAYS]
        senders = len({c.counterparty for c in span})
        if senders > most_senders:
            best, most_senders = span, senders
    return best
```

This is a **sliding window**. For every transaction, treat it as the start of a 7-day window, collect everything inside, count distinct senders, keep the best.

`{c.counterparty for c in span}` is a **set comprehension**; a set discards duplicates, so its length is the number of *different* senders.

`key=lambda c: (c.day, c.txn_id)` sorts by date and breaks ties by transaction id, so the result is deterministic.

The complexity is O(n²) — for each of n transactions it scans all n. With about 30 transactions per alert that is 900 operations, which is nothing. For a real bank with millions of rows you would use a two-pointer sweep in O(n log n). Knowing the difference, and knowing why the simple version is right *here*, is a good interview answer.

**Why a burst rather than the whole month?** The docstring says it:

> Looking at one burst, not the whole month, keeps regular income (such as weekly payouts) from hiding a burst of payments.

A delivery driver gets four payouts a month from one platform. Counting distinct senders across the whole month would mix those in. This was a real bug — the README's problems table lists "Mule burst missed for delivery drivers — weekly payouts all month hid the burst — use the busiest 7-day sender window". There is a test for it:

```python
def test_a_burst_of_senders_is_found_even_when_regular_payouts_continue_all_month():
```

### Money that came back

> **Later change (chapter 22):** the pairing loop below was pulled out into `find_returned_pairs`, which `return_features` now calls. The rule is identical — the refactor was made so `evidence.py` could reuse it rather than copy it, and the committed dataset files were checked byte-for-byte afterwards to prove no computed value moved.

```python
def return_features(credits, external_debits) -> Dict[str, int]:
    used = set()
    pairs = []
    sent_out = [d for d in external_debits if d.channel in RETURNABLE_CHANNELS and d.amount >= RETURN_MIN]
    paid_in = [c for c in credits if c.channel in RETURNABLE_CHANNELS]
    for debit in sent_out:
        for credit in paid_in:
            if credit.txn_id in used:
                continue
            gap = (credit.day - debit.day).days
            if 0 < gap <= RETURN_DAYS and RETURN_LOW * debit.amount <= credit.amount <= RETURN_HIGH * debit.amount:
                used.add(credit.txn_id)
                pairs.append((debit, credit))
                break
    ...
```

A **greedy matching** algorithm. For each outgoing payment, find the first incoming payment that could be it coming back: strictly later (`0 < gap`), within 15 days, and between 90% and 105% of the amount. Mark that credit used so it cannot match twice, record the pair, `break` to the next debit.

Three guards worth noticing:

- `used` set, so one credit cannot repay two debits.
- `0 < gap` is strict, so a same-day credit does not count as a return.
- `RETURNABLE_CHANNELS` excludes `cash`, `atm`, `salary` and `internal`. This was also a real bug: "False 'returned money' — ATM withdrawals and salary paired up". A ₹10,000 ATM withdrawal followed by a ₹10,000 salary credit looked like a round trip. Restricting to transfer channels fixed it, and there is a test named `test_cash_withdrawals_and_deposits_are_never_treated_as_returned_payments`.

Greedy matching is not optimal — a better global assignment might pair things differently — but it is simple, deterministic and good enough, and the generator plants returns that are easy to match.

`return_same_party` counts pairs where the money came back from the person it went to. That is the single number separating round-tripping (different parties) from `repay_friend` (same party).

---

## 5.5 `compute_features` — pulling it together

```python
def compute_features(raw: RawAlert) -> Features:
    credits = [t for t in raw.transactions if t.direction == "credit"]
    debits = [t for t in raw.transactions if t.direction == "debit"]
    external_debits = [d for d in debits if d.channel != "internal"]
    income = raw.customer.declared_monthly_income

    cash = cash_features(credits)
    large = large_credit_features(credits, external_debits)
    senders = sender_features(credits, external_debits)
    returns = return_features(credits, external_debits)
    credits_total = sum(c.amount for c in credits)

    return Features(
        occupation=raw.customer.occupation,
        income=income,
        account_age_months=raw.customer.account_age_months,
        just_under_ratio=ratio_to_income(cash["just_under_total"], income),
        quick_exit_ratio=ratio_to_income(large["quick_exit_amount"], income),
        sender_ratio=ratio_to_income(senders["sender_total"], income),
        return_ratio=ratio_to_income(returns["return_total"], income),
        top_payees=biggest_payees(debits),
        credits_total=credits_total,
        debits_total=sum(d.amount for d in debits),
        credits_ratio=ratio_to_income(credits_total, income),
        **cash, **large, **senders, **returns,
    )
```

### The `**` unpacking at the end

`**cash` spreads a dictionary into keyword arguments: `cash_features` returned `{"cash_count": 11, "cash_total": 498300, ...}` and `**cash` turns that into `cash_count=11, cash_total=498300, ...`.

This is why each helper returns a dict rather than a tuple or a small object: the keys are the field names, so merging is one line instead of twenty.

The cost of the trick: it is not obvious from reading `compute_features` which fields come from where, and a typo in a helper's key gives a `TypeError` about an unexpected keyword argument rather than a clear message. The gain is that adding a feature means touching one helper, not two places. For a file this size, the trade is worth it — but you should be able to name both sides.

**Duplicate keys would be an error.** `f(**a, **b)` where both have the same key raises `TypeError: got multiple values for keyword argument`. So the four helpers must return disjoint key sets, which they do.

### `biggest_payees`

```python
def biggest_payees(debits) -> List[Tuple[str, int]]:
    totals: Dict[str, int] = defaultdict(int)
    for debit in debits:
        totals[debit.counterparty] += debit.amount
    ranked = sorted(totals.items(), key=lambda item: (-item[1], item[0]))
    return ranked[:TOP_PAYEES]
```

`defaultdict(int)` creates a dictionary whose missing values default to `0`, so `totals[name] += amount` works on the first sighting without a `if name not in totals` check.

`key=lambda item: (-item[1], item[0])` sorts by amount **descending** (the minus sign) and breaks ties by name **ascending**. Negating the number is the standard way to mix descending and ascending in one key. The tie-break is what makes it deterministic.

`ranked[:TOP_PAYEES]` takes the first three; slicing beyond the end is safe in Python, so a customer with one payee returns a list of one.

---

## 5.6 Risk and the ground-truth reason

```python
def risk_level(typology: str, features: Features) -> str:
    if typology == NO_CONCERN:
        return "low"
    amount_ratio = {
        "STRUCTURING":        features.just_under_ratio,
        "RAPID_PASS_THROUGH": features.quick_exit_ratio,
        "MULE_ACCOUNT":       features.sender_ratio,
        "ROUND_TRIPPING":     features.return_ratio,
    }[typology]
    if amount_ratio >= HIGH_RATIO:
        return "high"
    if amount_ratio >= MEDIUM_RATIO:
        return "medium"
    return "low"
```

Each typology has its *own* amount-at-issue. For structuring it is the just-under total; for a mule it is what the senders paid in. Using one generic "total credits" number would make risk meaningless for patterns where most of the money is innocent.

Another dispatch table, this time mapping a label to a value rather than a function.

Normal activity is always low risk, regardless of amounts. A house sale of ₹60 lakh is a huge ratio but no concern at all.

### The reason sentences

```python
def reason_for(raw: RawAlert, features: Features) -> str:
    f = features
    if raw.typology == "STRUCTURING":
        return (f"{plural(f.just_under_count, 'cash deposit')} just under the {format_rupees(CASH_REPORTING_LIMIT)} limit "
                f"within {f.just_under_span_days} days, totalling {format_rupees(f.just_under_total)}.")
    ...
    return NO_CONCERN_REASONS[raw.hard_negative_kind].format(occupation=f.occupation)
```

These are the target answers the model is trained to reproduce. Every number comes from `features`, which is what makes the faithfulness check (Chapter 11) possible: if the reason only ever uses computed numbers, and those numbers are printed in the summary, then any number in a model's reason that is *not* in the summary must have been invented.

`NO_CONCERN_REASONS` is a dict keyed by hard-negative kind, with `None` as a valid key for ordinary benign alerts:

```python
NO_CONCERN_REASONS = {
    None: "Activity matches the declared {occupation} profile; no laundering pattern found.",
    "cash_heavy_shop": "Frequent cash deposits are steady, well below the limit and fit a {occupation}'s business.",
    "house_sale": "One large credit moved to the customer's own fixed deposit; nothing was sent on to other parties.",
    "salary_then_commitments": "Salary went to regular payees (rent, loan EMI, SIP) in line with income; no pass-through.",
    "repay_friend": "A small payment was returned in full by the same person; not a layering pattern.",
}
```

`None` as a dictionary key is perfectly legal — keys only need to be hashable.

**A limitation to notice.** The reasons are templated, so the model is learning a small number of sentence shapes with the numbers swapped. That is why it reaches 99.7% faithfulness: the task is narrow. A model trained this way cannot write a novel explanation of an unusual case. Saying this before an interviewer points it out is much stronger than defending it afterwards.

---

## 5.7 What makes a good feature here

Every feature satisfies three conditions:

1. **Computable from transactions alone.** No external data, no lookups.
2. **Explainable in one sentence.** "Cash deposits between 80% and 99% of the reporting limit." An analyst can check it by hand.
3. **Discriminating.** It separates at least one typology from at least one hard negative.

Condition 3 is why `return_same_party` exists, and why `external_debits` excludes `internal`. Each was added to separate a specific confusable pair.

---

## 5.8 Exercises

1. Build a `Ledger` with three cash credits of ₹45,000 on days 3, 4 and 6 and one of ₹5,000 on day 10. Predict `cash_count`, `just_under_count` and `just_under_span_days` before running `compute_features`.
2. Why does `percent` cap at 100? Construct a ledger where the uncapped value would exceed 100.
3. Rewrite `busiest_week` to be O(n log n) with two pointers. Does it give identical answers on the test suite?
4. Add a feature `night_transaction_count` for transactions between 11pm and 5am. What stops you? (Look at what `Transaction` stores.)
5. In `return_features`, remove the `used` set and find an input where the result becomes wrong.
6. Explain why `risk_level` uses a different ratio per typology, with a concrete example where using `credits_ratio` for everything would mislabel.
