# Chapter 20 — Interview questions on this codebase

Questions an interviewer asks after opening your repository. These are code-level and project-level; general fine-tuning theory is in Chapters 8 and 9.

Each has the answer, and where it matters, the trap.

---

## A. Opening

**1. Walk me through this project in two minutes.**

Problem, then what you built, then how you tested it.

> Banks raise far more AML alerts than analysts can read, and most are not suspicious. I generated 3,400 synthetic customers with planted laundering patterns, computed every number in Python, and rendered those numbers into a short English summary. I fine-tuned Qwen2.5-1.5B with QLoRA to read that summary and return JSON — typology, risk level, one-line reason. Every answer passes a checker before anyone sees it. A fixed six-step workflow then drafts a case note and waits for an analyst to approve or override, with every step in an append-only log. I compared it against threshold rules and the untuned base model on data split by customer, plus a held-out set with wording the model had never seen.

Then stop. Let them pick the thread.

*Trap: starting with the model architecture. Start with the problem.*

**2. Why synthetic data?**

> Three reasons. Privacy — I can publish it. Control — I know the ground truth exactly, so I can measure generalisation by changing only the wording. And availability — no bank was going to hand me transaction data. The cost is that labels are true by construction, so the model is learning my generator, not the world.

**3. Which part are you least happy with?**

Have a real answer. Candidates who say "nothing" are not believed.

> The held-out set changes three things at once — wording, names and income scale — so I can say there is a generalisation gap but not what caused it. I should have built three variants that each vary one thing.

---

## B. Data and features

**4. How do you know your splits do not leak?**

> Customers are assigned to a split before any alert is generated, and each customer has exactly one alert, so a customer cannot be in two splits. There is a test asserting it across all 3,400, and another asserting that held-out names never appear elsewhere. The held-out set also uses two wording templates reserved for it, with a test checking the separation in both directions.

**5. Why split by customer rather than randomly by row?**

> Because with one alert per customer here they are the same — but the discipline matters for real data, where a customer has many alerts. Random row splitting would put the same customer in train and test, so the model could recognise the customer rather than the pattern, and the score would be inflated.

**6. Your generator plants patterns and your features detect them. Isn't that circular?**

Concede immediately; it is the correct observation.

> Yes, and it is the project's deepest limitation. The patterns were planted in a form my features were designed to find. That circularity makes the rules baseline unusually strong — it is reading the same logic that created the labels. It is unavoidable in a synthetic project, and it is why I say the results show the pipeline works, not that the model would work in a bank.

**7. What is a hard negative and why do you have four?**

> Legitimate activity that looks suspicious. A cash-heavy shop looks like structuring; a house sale looks like pass-through; salary followed by rent and EMI looks like pass-through; repaying a friend looks like round-tripping. Without them, "no concern" just means "nothing happened" and a model scores well by flagging anything busy. With them, I can measure the false-positive rate per kind — and that is where both systems' real weaknesses showed up.

**8. Walk me through one feature computation.**

Pick the sender burst; it is the most interesting.

> `busiest_week` slides a 7-day window across the UPI and IMPS credits and keeps the span with the most distinct senders. I look at one burst rather than the whole month because a delivery driver gets four payouts from one platform all month, and counting across the month hid genuine mule bursts. That was a real bug and there is a test named after it.

---

## C. Fine-tuning

**9. Why QLoRA rather than full fine-tuning?**

> A free T4 has 16 GB. Full fine-tuning of 1.5B needs about 20 GB, mostly optimiser state — Adam keeps two fp32 values per trainable parameter. LoRA cuts trainable parameters to 18.5 million, 1.18% of the model, which collapses the optimiser cost. 4-bit NF4 then shrinks the frozen weights. Total about 3 GB.

**10. What do rank and alpha actually do?**

> Rank is the inner dimension of the two thin matrices whose product forms the weight update, so it sets how expressive that update can be. Alpha over rank scales the update before it is added — with alpha 32 and rank 16 the scale is 2, which is the usual convention. B is initialised to zeros so the update starts at exactly zero and the model begins as the unmodified pretrained model.

**11. What happens at rank 4?**

> I didn't test it, and I should have. The task is narrow and the model clearly latched onto wording — 1.000 on test, 0.936 on held-out — so I'd expect rank 4 to perform about the same and possibly generalise slightly better. It's the first experiment I'd run.

*Trap: guessing confidently. "I didn't test it, here's my prediction and why" is the stronger answer.*

**12. Which modules did you target?**

> PEFT's `all-linear`, which resolves to every linear layer — the attention projections and the MLP. I didn't hand-pick a subset. The original LoRA paper used query and value only; adapting everything is the common default now.

**13. Your eval loss was 0.0006. Is that not suspicious?**

> It is, and it should be. The output is JSON with five labels, three risk levels and a templated reason, and the loss is masked to the answer only, so a low number means the format was easy to learn. It told me training ran correctly and nothing more. The number I trusted was macro-F1 on held-out wording.

**14. Explain answer-only loss masking.**

> Prompt tokens get label −100, which PyTorch's cross-entropy ignores, so only the answer tokens produce gradients. Without it the model would also be trained to generate AML alert summaries, and since the prompt is about 190 tokens against 40 for the answer, most of the signal would go into reproducing inputs.

**15. Why learning rate 2e-4, when full fine-tuning uses 2e-5?**

> Because I'm training small, randomly initialised adapter matrices, not nudging carefully pretrained weights. The adapters can take larger steps safely, and the weights that a large step would damage are frozen.

---

## D. Guardrails

**16. How do you stop the model inventing numbers?**

> The model never writes a number into the case note — Python does, from the computed features. The one-line reason it does generate is checked: I extract every number from the reason and every number from the summary and take the set difference. A non-empty difference means the model produced a figure that wasn't in its input, and the answer is rejected. One retry, then the alert goes to manual review.

**17. What does that check not catch?**

Say this before they find it.

> It compares against the summary text, not the transactions, and it's a set comparison, so it ignores position and meaning. The model could use a number from the summary in the wrong place and pass. It's a cheap, high-recall check for invented figures, not semantic verification.

**18. Why only one retry?**

> Each retry costs a full generation, and with greedy decoding the second attempt is nearly the same computation — it differs only because the retry goes through the single-item path while the first came from a batch with left padding. If the model fails twice, something about the alert is unusual and a human should look. In AML, routing to manual review is an acceptable failure; a wrong verdict is not.

**19. Why not constrained decoding?**

> That's the better answer and I'd use it next time — restrict the sampler at each step so invalid JSON is impossible. I didn't because it adds a dependency and ties you to a serving stack, and my fallback was acceptable: an alert going to a human is fine.

---

## E. Evaluation

**20. Why macro-F1?**

> The test set is 160 no-concern alerts against 60 of each typology. Micro averaging would let the majority class hide failure on the rare patterns, and the rare patterns are the entire point. Macro gives each class equal weight.

**21. Your tuned rules beat your model. Why use the model?**

The most important question in the set. Concede, explain, then give the case.

> On held-out the rules scored 0.990 and the model 0.936, and I published that. But those rules read the exact computed features my generator used to create the labels — they're reading the same logic backwards, which is a home advantage that wouldn't survive real, messy statements. The model reads text and tolerated a complete rewording for 0.064. What it adds is a written reason an analyst can check, tolerance of new phrasing without anyone rewriting thresholds, and one pass producing typology, risk and explanation together. In production I'd use both: rules for the clear cases, the model for explanation and the ambiguous ones.

**22. You scored 1.000 on test. Do you believe it?**

> No. The summary prints the numbers that decide the label, test shares wording templates with training, and there are five classes. It means the model learned the mapping on familiar wording. That's exactly why the held-out set exists, and 0.936 is the number I quote.

**23. Where did the model fail?**

> Mule accounts, F1 0.83 on held-out, because the signal is a conjunction — many senders *and* a fast cash-out *and* a young account — and conjunctions are harder to spot through unfamiliar phrasing. And `salary_then_commitments`, which it flagged 53% of the time on held-out having got it perfect on test. That's the same hard negative the untuned rules got wrong 80% of the time, so it's the genuinely confusable case in the data.

**24. How did you stop yourself tuning on held-out?**

> Three ways. The evaluation script needs an explicit `--final` flag to score it. The held-out templates are fixed and the agents file forbids editing them after seeing a result. And there are tests asserting the template and customer separation, so a leak fails the build rather than depending on my memory.

---

## F. The workflow and the app

**25. Is this an agent?**

Be straight.

> No, and deliberately not. `run_investigation` calls five functions in a fixed order. There's no planner and no model choosing tools. A 1.5B model calls tools unreliably, and in a regulated process you want the same steps every time so an auditor can follow them. It has multi-step orchestration, per-case memory and guardrails — but the tool calling is Python calling Python.

*Trap: calling it autonomous because the job post asks for agents. It is checkable in thirty seconds.*

**26. What is "case memory"?**

> Per-alert state that survives a restart — steps, note, decision, in a JSON file per alert. It is not cross-alert customer history, because each synthetic customer has exactly one alert. On real data that history would be the most valuable feature in the system, and adding it would mean keying cases by customer rather than alert.

**27. What makes your audit log append-only?**

> There is no update function and no delete function in the module. The only operations are append and read, and the file is opened in append mode. The guarantee comes from what the module refuses to offer.

**28. What would an auditor still want that you don't have?**

> User identity on each decision, tamper-evidence — a hash chain so the log can be proved unaltered — the model version recorded against each verdict, and fairness testing across customer segments. I haven't done the last one at all, and since occupation correlates with typology in my generator by design, I'd expect differences.

**29. Does the demo run the model?**

> No. `predict.py` ran on Colab and saved the verdicts to files; the app reads them. That's why it deploys to a free host with no GPU. Live inference would need a GPU service behind an API, and that's the obvious next step.

---

## G. Engineering

**30. How is any of this testable without a GPU?**

> By defining the dependency as a type. `predict.py` declares `GenerateFunction = Callable[[str], str]`, so the checking and retry logic takes any function from string to string. The tests pass fakes — one that returns valid JSON, one that returns broken JSON, one that fails then succeeds. The heavy imports are inside the functions that need them, so the module imports fine on a laptop. Ten tests, instant, no torch.

**31. Why do your write functions take a folder parameter?**

> Dependency injection. Production uses the default, tests pass pytest's `tmp_path`, so no test touches the real data folder or leaves files behind. Hard-coding the paths would mean patching module globals, which is fragile.

**32. 143 tests on a portfolio project. Why?**

> Because the data pipeline is the product — a bug in the feature code corrupts the training data, the baseline and the case notes at once, and you'd see it as a mysteriously poor model. And because several of the tests check the methodology rather than the code: that held-out templates never leak, that no customer is in two splits, that every ground-truth reason only uses numbers from its summary. The discipline is in the test suite, not in my memory.

**33. Something in the code you'd change today?**

> The faithfulness problem string is duplicated as a literal between `schema.py` and `evaluate.py` — it should be a shared constant. Truncation in `tokenize_example` is right-side, so a very long summary would cut the answer rather than the prompt; it never fires with this data but it's wrong in principle. And `section_keys` inlines a literal 3 where there's already a `MIN_SENDERS` constant.

Naming three specific small flaws in your own code is a strong answer. It proves you read it.

---

## H. Scale and production

**34. What breaks at ten million transactions a day?**

> `busiest_week` is O(n²) per alert — fine at 30 transactions, hopeless at scale; it becomes a two-pointer sweep. Feature computation moves to Spark or a streaming job. Inference goes behind a batched GPU service with vLLM. Case files and the audit log move from JSON on disk to a database with retention and access control. And the model itself is the cheap part — the feature pipeline is what you'd have to engineer.

**35. How would you deploy this in a bank?**

> Inside their network, nothing leaving. One base model with a per-customer adapter, since adapters are tens of megabytes and vLLM supports multi-LoRA serving — that matters for a vendor with hundreds of banking customers across jurisdictions. Shadow mode first, running alongside the existing rules and deciding nothing. Then assistive mode where it orders the queue and drafts notes but the analyst decides. Model registry versioning the adapter with its prompt and data so any verdict is reproducible.

**36. How would you monitor it?**

> Input drift on the feature distributions, output drift on the label mix, guardrail failure rate — invalid JSON and ungrounded numbers, which is the earliest warning — and the analyst override rate. That last one is the strongest signal and I already record it: the audit log stores the model's verdict and the analyst's side by side for every decision. If overrides climb for one typology, I know where the model is degrading before any metric moves.

---

## Chapter 22 — the live run and evidence links

**37. Is the model actually running in this demo, or is it a recording?**

> It runs live on this laptop. Upload a transactions CSV and it classifies it in about fifteen seconds. The scores in the README are separate — those came from a batched GPU run on a held-out set, not from live calls. On the public link there's no GPU, so uploads there go to "needs review" and say so.

**38. Your README says the scores came from a 4-bit model. What is this one?**

> Half precision. `bitsandbytes` doesn't run on a Mac, so the local path loads the same base model and the same adapter at fp16 instead of NF4. Same weights, same prompt, but not the exact setup that was scored, and I say so rather than letting the numbers be assumed to transfer. Measuring how often the two disagree is on my list.

**39. How do I know the evidence links are right and not generated?**

> No model is involved in them. The findings are computed by Python from the transactions, so the link back to the rows is exact. Every threshold in the evidence code is imported from the feature code rather than restated, and the tests assert the two agree — the number of rows for each finding has to equal the matching feature count. If they ever drift, a test fails.

**40. Did anything come out of building that?**

> A data bug. Linking claims to rows made me check whether the shipped transactions actually reproduce the shipped features, and for 83 of 1,000 alerts they didn't — the raw files had been generated by an older state of the generator. Regenerating fixed all of them and changed no derived file, so no score moved. The general technique is worth stealing: derived data and its source should round-trip, and checking that is three lines.

**41. Why didn't you deploy the hosted model?**

> Modal needs a payment method before it will run a GPU, even inside its free credit, and for a demo given in person the local path is better anyway — no cold start, no network dependency, and it supports the claim that no customer data leaves the machine. The server code is written and in the repo; it's a deployment decision, not a missing capability.

---

## How to practise

Answer each one **out loud**, timed. Two minutes for question 1, under sixty seconds for the rest.

The ones to be perfect on: **21** (rules beat the model), **22** (do you believe 1.000), **25** (is it an agent), **16** (hallucinated numbers), **33** (what would you change).

If you can only prepare five, prepare those five. If you are demonstrating the app live, add **37** and **40** — the first is the question every reviewer asks within a minute of seeing a demo, and the second is the best story in the project.
