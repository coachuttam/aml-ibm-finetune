# Chapter 21 — Coding exercises

Graded from reading to building. **Never edit the original source** — work in a scratch file or a copy.

```bash
mkdir -p ~/scratch && cp -r src ~/scratch/src_copy
```

Solutions follow each set.

---

## Set 1 — Reading the code (no editing)

**1.1** Find every file that imports `schema.py`. What does that tell you about where to add a new typology?

**1.2** `patterns.py` has three dispatch tables. Name them and say what each maps.

**1.3** In `features.py`, list the four functions returning dicts and confirm their key sets are disjoint. Why must they be?

**1.4** Trace what happens when `python -m src.dataset` runs, naming every function called in order for one alert.

**1.5** Find three places using the `a or b` default idiom. For each, say what breaks if the value is legitimately `0`.

<details>
<summary>Solutions</summary>

**1.1** `generator.py`, `features.py`, `metrics.py`, `rules.py`, `prompt.py`, `predict.py`, `evaluate.py`, `review.py`, `case_note.py`, `investigator.py`. A new typology starts in `schema.TYPOLOGIES` and ripples to the generator (a planter), `features.py` (a feature and a risk ratio), `rules.py` (a rule), and retraining.

**1.2** `INCOME_ADDERS` (occupation → income function), `TYPOLOGY_PLANTERS` (typology → planter), `HARD_NEGATIVE_PLANTERS` (look-alike kind → planter).

**1.3** `cash_features`, `large_credit_features`, `sender_features`, `return_features`. They must be disjoint because `Features(..., **cash, **large, **senders, **returns)` raises `TypeError` on a duplicate keyword.

**1.4** `main` → `generate_all` → `generate_split` → `build_recipes` → `generate_alert` → `make_customer` → `add_everyday_activity` → planter → `ledger.finish` → then `build_dataset` → `build_example` → `compute_features` → `pick_template` → `render_summary` → `risk_level` → `reason_for` → `save_dataset`.

**1.5** `kind or "ordinary"` in `metrics.py`; `limit or 300` in `finetune.py`; `alert.window_end or 'not available'` in `investigator.py`. A legitimate `0` or `""` would be replaced by the fallback — harmless in all three, but the pattern is a trap in general.

</details>

---

## Set 2 — Small changes

**2.1** Add a `format_lakhs` function so 4,98,300 renders as "4.98 lakh". Write three tests first.

**2.2** Add a feature `weekend_credit_count` counting credits on Saturday or Sunday. What stops you? Fix it.

**2.3** Make `section_keys` use `MIN_SENDERS` instead of the inlined `3`.

**2.4** Add a rule R5 firing when `cash_out_percent >= 90` regardless of sender count. Measure the effect on macro-F1 and on false alarms.

<details>
<summary>Solutions</summary>

**2.1**

```python
def format_lakhs(amount: int) -> str:
    """₹4,98,300 as '4.98 lakh'. One lakh is 100,000."""
    return f"{amount / 100_000:.2f} lakh"

def test_format_lakhs():
    assert format_lakhs(498_300) == "4.98 lakh"
    assert format_lakhs(100_000) == "1.00 lakh"
    assert format_lakhs(0) == "0.00 lakh"
```

**2.2** `Transaction` stores `day` as a `date`, which does have `weekday()` — so nothing stops you:

```python
def weekend_features(credits):
    return {"weekend_credit_count": sum(1 for c in credits if c.day.weekday() >= 5)}
```

Add the field to `Features`, call it in `compute_features`, add `**weekend` to the constructor, and add a placeholder if you want it in the summary. Note that the generator does not vary behaviour by weekday, so the feature carries no signal — a good lesson that a feature is only useful if the data contains the pattern.

**2.3** In `templates.py`, import `MIN_SENDERS` from `src.features` and use `f.sender_count >= MIN_SENDERS`. The test suite should still pass.

**2.4** Insert before the `NO_CONCERN` return in `classify`, add `cash_out_only_min` to `RuleConfig` and the grid, re-run `python -m src.evaluate`. Expect mule recall to rise slightly and false alarms on `cash_heavy_shop` to rise more, because a shop moving its takings on also has a high cash-out percentage.

</details>

---

## Set 3 — The guardrails

**3.1** Write five answers that each trip exactly one check in `find_problems`, and verify with `check_answer`.

**3.2** `numbers_in` uses `r"\d[\d,]*"`. What happens to `26.2`? Write a test that exposes the behaviour, then decide whether it is a bug.

**3.3** Write a fake generate function failing once then succeeding, and confirm `classify_with_retry` returns a valid answer.

**3.4** Construct an answer that passes every check but is still wrong.

<details>
<summary>Solutions</summary>

**3.1**

```python
summary = "cash in: count 11, total ₹4,98,300; just under ₹50,000: 11"

cases = [
    '{"typology": "SUSPICIOUS", "risk": "high", "reason": "11 deposits."}',        # bad label
    '{"typology": "STRUCTURING", "risk": "severe", "reason": "11 deposits."}',     # bad risk
    '{"typology": "STRUCTURING", "risk": "high"}',                                 # missing reason
    '{"typology": "STRUCTURING", "risk": "high", "reason": "' + "x" * 250 + '"}',  # too long
    '{"typology": "STRUCTURING", "risk": "high", "reason": "11 deposits, fraud."}',# banned word
    '{"typology": "STRUCTURING", "risk": "high", "reason": "99 deposits."}',       # unfaithful
]
for raw in cases:
    print(check_answer(raw, summary).problems)
```

**3.2** The regex matches digits and commas but not a full stop, so `26.2` yields two matches, `"26"` and `"2"`. Both usually appear elsewhere in the summary, so it rarely fires — but a reason containing `26.2` where the summary has `26.2` is compared as `{"26", "2"}` on both sides, which passes. It is lenient rather than wrong, and worth knowing.

**3.3**

```python
class FailsOnce:
    def __init__(self):
        self.calls = 0
    def __call__(self, summary):
        self.calls += 1
        if self.calls == 1:
            return "not json at all"
        return '{"typology": "NO_CONCERN", "risk": "low", "reason": "Nothing found."}'

checked = classify_with_retry("summary with no numbers", FailsOnce())
assert checked.valid and checked.typology == "NO_CONCERN"
```

**3.4** `{"typology": "MULE_ACCOUNT", "risk": "high", "reason": "11 cash deposits just under ₹50,000."}` on a structuring alert. Every number is in the summary, the label and risk are valid, no banned words — but the typology is wrong and the reason describes structuring. The checker validates form, not correctness.

</details>

---

## Set 4 — Evaluation

**4.1** Compute macro-F1 for an all-`NO_CONCERN` classifier on the test set, by hand and in code.

**4.2** Write a confusion matrix for the fine-tuned model on held-out, from the saved answers.

**4.3** Score the model on held-out using **micro**-F1 and compare with macro. Explain the gap.

**4.4** Find the held-out `salary_then_commitments` alerts the model got wrong and read their summaries. What might it have latched onto?

<details>
<summary>Solutions</summary>

**4.1** 160 of 400 are `NO_CONCERN`. Precision 160/400 = 0.40, recall 1.0, F1 ≈ 0.571. The four typologies score 0. Macro-F1 = 0.571 / 5 ≈ **0.114**. Note that the base model's 0.135 is barely above this floor.

**4.2**

```python
import json
from collections import Counter
from src.dataset import load_split
from src.evaluate import load_predictions, typology_of

examples = load_split("data/heldout.jsonl")
answers = load_predictions("results/finetuned_heldout.jsonl")
pairs = Counter((e["label"]["typology"], typology_of(answers.get(e["alert_id"]))) for e in examples)
for (true, pred), n in sorted(pairs.items()):
    if true != pred:
        print(f"{true:<20} predicted as {pred:<20} {n}")
```

**4.3** Micro will be higher, because `NO_CONCERN` is the largest class and the model handles ordinary cases perfectly. The gap is the cost of the mule and pass-through errors, which macro refuses to let the majority class absorb.

**4.4**

```python
wrong = [e for e in examples
         if e["hard_negative_kind"] == "salary_then_commitments"
         and typology_of(answers.get(e["alert_id"])) != "NO_CONCERN"]
for e in wrong[:5]:
    print(e["template_id"], "→", typology_of(answers[e["alert_id"]]))
    print(e["summary"][:300], "\n")
```

Look at the `inflows` line. With incomes scaled 1.6×, more salaries exceed the ₹50,000 large-credit threshold, so these alerts show a large credit with a high quick-exit percentage — the pass-through signature. The held-out income scale made this hard negative genuinely harder, not just differently worded. That is a real finding and worth mentioning in an interview.

</details>

---

## Set 5 — The workflow

**5.1** Run a full investigation in a script, with no Streamlit, writing to a temporary folder.

**5.2** Try to export before deciding. Catch the exception and print its message.

**5.3** Add a `request_more_information` action. Which functions change?

**5.4** Write an end-to-end test: investigate, decide, assert the audit log has six lines with the last one carrying a before and after.

<details>
<summary>Solutions</summary>

**5.1**

```python
from pathlib import Path
from src.review import load_review_alerts, read_transactions, tuned_rules_config
from src.investigator import run_investigation, record_decision

folder = Path("/tmp/aml_demo"); folder.mkdir(exist_ok=True)
alerts = load_review_alerts("test", tuned_rules_config())
alert = alerts[0]
txns = read_transactions("test").get(alert.alert_id, [])
case = run_investigation(alert, txns, case_folder=folder, log_path=folder / "log.jsonl")
for step in case.steps:
    print(step.number, step.name, step.status, "-", step.summary)
print(case.note[:400])
```

**5.2**

```python
from src.investigator import export_markdown, ExportBlockedError
try:
    export_markdown(case)
except ExportBlockedError as problem:
    print("blocked:", problem)
```

**5.3** `ACTIONS` and `PAST_TENSE` in `investigator.py`; `check_decision` (should it require a note? probably yes); `record_decision`'s step-6 summary; a new case status; the radio options in `app.show_decision_panel`; `CASE_WORDS` in `app.py`. Six places — a good illustration of how a small product change touches a workflow, a store and a UI.

**5.4**

```python
def test_a_full_investigation_and_decision_lands_in_the_log(tmp_path):
    log = tmp_path / "log.jsonl"
    alerts = load_review_alerts("test", tuned_rules_config())
    alert = next(a for a in alerts if a.model_typology != NEEDS_REVIEW)
    case = run_investigation(alert, [], case_folder=tmp_path, log_path=log)
    record_decision(alert, case, "approve", alert.model_typology, alert.model_risk, "",
                    case_folder=tmp_path, log_path=log)
    events = read_events(log)
    assert len(events) == 6
    assert events[-1].action == "decision: approve"
    assert events[-1].before and events[-1].after
```

</details>

---

## Set 6 — The projects worth building

These take hours, not minutes, and each closes a gap on your CV.

**6.1 — Rank sweep.** Train at ranks 4, 8, 16 and 32, score each on test and held-out, plot the two curves. One Colab session. This turns "I used rank 16" into "here is the curve", and it is the single highest-value experiment available to you.

**6.2 — Isolate the generalisation gap.** Build three held-out variants that vary one thing each — wording only, names only, income scale only. Score the existing model on all three. You will finally know what caused the 0.064 drop.

**6.3 — A REST API.** FastAPI over the saved answers: `GET /alerts`, `GET /alerts/{id}`, `POST /classify`. Closes "REST API" on your CV, and takes a day.

**6.4 — Semantic search.** Embed the 3,400 summaries with `sentence-transformers`, store them in Chroma or FAISS, add `GET /alerts/{id}/similar`. Closes "vector database" and "semantic search", and "find alerts like this one" is a genuinely useful analyst feature.

**6.5 — Containerise and deploy.** Docker image for the API, deployed to a free host. Turns "Docker" from a Dockerfile you wrote into a service that runs.

**6.6 — System D.** Run a prompted frontier model over the test set with a careful few-shot prompt and score it with the same code. This answers the question your evaluation currently cannot: is fine-tuning better than a good prompt? Expect it to be close, and publish whatever you find.

**6.7 — Error analysis write-up.** Read every held-out alert the model got wrong, categorise the failures, and write a page. Unglamorous, and it is what a senior engineer would do first.

---

## A suggested order

If you have a weekend: **6.1** then **6.2**. They are cheap, they use what exists, and they give you answers to the two questions an interviewer is most likely to ask.

If you have a week: add **6.3**, **6.4** and **6.5**, which between them close four keyword gaps on your CV with one small service.

**6.6** is the most intellectually honest thing left undone in the project, and the one an interviewer is most likely to notice is missing.
