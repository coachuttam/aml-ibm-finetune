# Chapter 2 — Repository map

## 2.1 The whole tree

```
aml-alert-investigator/
├─ app.py                      285 lines   Streamlit review screen
├─ upload_view.py               85         the Live run tab (upload → verdict)
├─ evidence_view.py             62         computed findings and the evidence table
├─ model_server.py              43         hosts the model on a Modal GPU
├─ README.md                   114         Project front page, results table
├─ PRD.md                      124         What it must do, and the targets
├─ ARCHITECTURE.md             117         How it fits together
├─ AGENTS.md                    57         Rules for AI coding assistants
├─ DESIGN_SYSTEM.md             63         UI wording and layout rules
├─ LICENSE                                 MIT
├─ requirements.txt              3         pytest, streamlit, pandas
├─ requirements-train.txt        6         transformers, peft, bitsandbytes, accelerate, datasets
├─ requirements-local.txt        4         torch, transformers, peft, accelerate (live run on this computer)
│
├─ src/
│   ├─ __init__.py             0          makes src a package
│   ├─ models.py               47         Transaction, Customer, RawAlert
│   ├─ money.py                23         rupee formatting, plurals
│   ├─ names.py                52         two pools of invented names
│   ├─ schema.py               88         label lists + the output checker
│   ├─ patterns.py            285         builds one customer's 30 days
│   ├─ generator.py           231         split plans, 3,400 alerts, save/load
│   ├─ features.py            286         counts everything; risk and reason
│   ├─ templates.py           167         five wordings for the summary
│   ├─ dataset.py              85         raw alerts → training examples
│   ├─ metrics.py              67         precision, recall, F1, false alarms
│   ├─ rules.py                77         threshold baseline + grid tuning
│   ├─ prompt.py               32         system prompt and answer format
│   ├─ finetune.py            133         QLoRA training (Colab)
│   ├─ predict.py             136         batched generation + checking
│   ├─ evaluate.py            131         scoring and the report
│   ├─ review.py              161         joins data for the app
│   ├─ review_scores.py        55         the Evaluation tab numbers
│   ├─ audit.py                51         append-only log
│   ├─ case_store.py           66         case memory (one JSON per alert)
│   ├─ case_note.py           111         findings + draft note, with row ids
│   ├─ investigator.py        160         the six-step workflow
│   ├─ upload.py               98         reads an uploaded transactions CSV
│   ├─ live.py                 68         one uploaded alert through the pipeline
│   ├─ local_model.py          74         the model, running on this computer
│   ├─ remote_model.py         56         the model, on a hosted GPU
│   ├─ evidence.py            105         links each finding to its transaction rows
│   ├─ publish.py              65         upload to Hugging Face
│   └─ build_space.py         127         build a Hugging Face Space folder
│
├─ tests/                      14 files, 143 tests
├─ data/
│   ├─ train.jsonl  validation.jsonl  test.jsonl  heldout.jsonl   (committed)
│   └─ raw/   same four names, the full transaction lists
├─ results/   base_*.jsonl and finetuned_*.jsonl   saved model answers
├─ docs/      architecture.mmd and architecture.png
├─ huggingface/  MODEL_CARD.md, DATASET_CARD.md
├─ notebooks/  finetune_qlora.ipynb   thin Colab wrapper
└─ audit/      cases/ and audit_log.jsonl   (git-ignored, created at runtime)
```

Total: about 3,500 lines of source and 1,500 lines of tests. Chapter 22 covers the files added on 13 November 2026.

## 2.2 Why the files are this small

`AGENTS.md` sets the rule: every file under about 300 lines, every function about twenty lines or fewer, one job per function, no abbreviations, named constants instead of magic numbers. The largest file is `patterns.py` at 285 lines, and it is mostly a series of short, independent planting functions.

This is a deliberate choice with an interview answer attached: **"I wrote it to be read. I knew I would have to explain every line of it to someone, so I optimised for that rather than for cleverness."** That is a legitimate engineering stance and a good one for a portfolio project.

## 2.3 The five documents, and who they are for

| File | Audience | What it answers |
| --- | --- | --- |
| `README.md` | A visitor | What is this, what did it score, how do I run it |
| `PRD.md` | You, planning | What must it do, what are the targets, what is out of scope |
| `ARCHITECTURE.md` | A technical reader | How do the parts fit, what is the data model, where do I extend it |
| `AGENTS.md` | An AI coding assistant | The hard rules it must not break |
| `DESIGN_SYSTEM.md` | Whoever writes UI text | Wording and layout conventions |

`AGENTS.md` is worth reading in full, because it is where the project's discipline is written down. Its eight hard rules include *never tune on the held-out set*, *the model labels and explains, Python counts*, *split before generating*, *say "refer for review", never "fraud"*, and *report honestly — if the fine-tuned model does not beat the baselines, the README says so*.

That last rule is why the README contains a line admitting the model lost. The rule was written before the result was known.

## 2.4 Running everything

```bash
# one-time setup
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# regenerate the data (deterministic, about a second)
python -m src.generator        # writes data/raw/*.jsonl
python -m src.dataset          # writes data/*.jsonl

# checks
python -m pytest -q            # 143 tests, about 4 seconds
python -m src.evaluate         # scores rules + any saved model answers
python -m src.evaluate --final # also scores held-out

# the app
streamlit run app.py
```

Training and prediction are not in this list because they need a GPU. They run on Colab through `notebooks/finetune_qlora.ipynb`, which clones the repo, installs `requirements-train.txt`, runs a two-minute smoke test on 64 examples, then runs the full job.

## 2.5 What is committed and what is not

`.gitignore` excludes `.venv`, caches, `.env`, `audit/` and `space_build/`. It also excludes `data/raw/train.jsonl` — the biggest file — while the other raw splits *are* committed, because the demo needs transaction rows to show in the evidence table.

The pattern worth noticing: **anything reproducible from a seed does not need to be in Git**, but anything the deployed app needs at runtime does. `data/raw/train.jsonl` is regenerable and unused by the app, so it goes. The three other raw files are used by the app, so they stay.

`audit/` is excluded because it is created at runtime and differs per user. On the public demo that folder lives on the host and resets when the app restarts, which is why the app shows a "shared demo" notice.

## 2.6 The data files, and what one line looks like

**`data/raw/test.jsonl`** — one alert with everything:

```json
{"alert_id": "A-test-0308", "split": "test", "template_group": "shared",
 "typology": "STRUCTURING", "hard_negative_kind": null,
 "window_start": "2026-04-24", "window_end": "2026-05-23",
 "customer": {"customer_id": "C-test-0308", "occupation": "homemaker",
              "declared_monthly_income": 19000, "account_age_months": 16},
 "transactions": [{"txn_id": "A-test-0308-T001", "day": "2026-04-24", "amount": 10000,
                   "direction": "debit", "channel": "atm", "counterparty": "ATM withdrawal"}, ...]}
```

**`data/test.jsonl`** — the same alert as a training example:

```json
{"alert_id": "A-test-0308", "customer_id": "C-test-0308", "split": "test",
 "template_id": "terse", "hard_negative_kind": null,
 "summary": "homemaker | income ₹19,000/month | account 16 months | cash in: count 11, ...",
 "label": {"typology": "STRUCTURING", "risk": "high",
           "reason": "11 cash deposits just under the ₹50,000 limit within 5 days, totalling ₹4,98,300."},
 "features": {"cash_count": 11, "just_under_count": 11, "just_under_total": 498300, ...}}
```

**`results/finetuned_test.jsonl`** — what the model said:

```json
{"alert_id": "A-test-0308", "valid": true, "typology": "STRUCTURING", "risk": "high",
 "reason": "11 cash deposits just under the ₹50,000 limit within 5 days, totalling ₹4,98,300.",
 "problems": []}
```

Three files, three stages, joined by `alert_id`. The app's `review.py` does exactly that join.

### Why JSONL and not JSON or CSV?

JSON Lines means one JSON object per line. It has three advantages here:

- You can read it line by line without loading the whole file into memory.
- You can append to it, which is what the audit log needs.
- A broken line damages one record, not the whole file.

CSV would not work because the records are nested (a customer object, a list of transactions). A single JSON array would mean parsing everything at once. JSONL is the standard choice for datasets of this shape, and both Hugging Face Datasets and most training libraries read it directly.

## 2.7 Exercises

1. Run `wc -l src/*.py` and find the three largest files. Does each one still do a single job?
2. Open `.gitignore` and explain, for each entry, whether it is excluded because it is regenerable, private, or runtime state.
3. Read `AGENTS.md` and pick the rule you think was hardest to keep. Find the code that enforces it.
4. Take one line from `data/test.jsonl` with `head -1 data/test.jsonl | python -m json.tool` and name every top-level key.
