# Chapter 12 — Evaluation and an honest reading of the results

The chapter that makes the project credible. Every number here was re-produced by running `python -m src.evaluate --final` on 12 November 2026.

---

## 12.1 The evaluation protocol

Four systems, four splits, one rule: **the held-out set is scored once, at the end.**

| System | What it is |
| --- | --- |
| A1 | Threshold rules with default thresholds, written before seeing any results |
| A2 | The same rules, thresholds tuned by grid search on the **training set only** |
| B | Qwen2.5-1.5B-Instruct, prompted, no training |
| C | The same model after QLoRA fine-tuning |
| D | Prompted Claude — **specified but never run** |

Four splits: train (2,400), validation (300), test (400), held-out (300).

### The `--final` flag

```python
DEFAULT_SPLITS = ("validation", "test")

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--final", action="store_true", help="also score the held-out set")
    splits = list(DEFAULT_SPLITS) + (["heldout"] if parser.parse_args().final else [])
    score_rules(splits)
    score_models(splits)
```

Held-out scoring requires an explicit flag. You cannot look at it by accident while iterating. The discipline is enforced by the interface, not by willpower — which is the right way to enforce discipline.

This pairs with the rule in `AGENTS.md`:

> **Never tune on the held-out set.** Do not read its summaries to write rules, templates or prompts. Run it once at the end. ... If held-out results change, say why.

---

## 12.2 How the scoring works

### Rules are scored directly

```python
def score_rules(splits: List[str]) -> None:
    train = load_split(DATA_FOLDER / "train.jsonl")
    systems = {"A1 rules (default)": DEFAULT_CONFIG,
               "A2 rules (tuned on train)": tune_on_training_set(train)}
    for name, config in systems.items():
        print(f"\n{name}: {describe(config)}")
        for split in splits:
            examples = load_split(DATA_FOLDER / f"{split}.jsonl")
            print_report(name, split, evaluate_predictions(examples, predict_all(examples, config)))
```

The tuning is re-run every time rather than hard-coded, so the printed thresholds always match the code that produced them. `describe(config)` prints them on the header line, so the report is self-documenting.

### Models are scored from files

```python
def score_models(splits, results_folder=RESULTS_FOLDER) -> None:
    for name, file_prefix in MODEL_SYSTEMS.items():
        for split in splits:
            path = results_folder / f"{file_prefix}_{split}.jsonl"
            if not path.exists():
                print(f"\n{name} on {split}: no answers yet ({path.name})")
                continue
            ...
```

Model answers were produced on Colab and saved. `evaluate.py` reads them. A missing file prints a line and moves on rather than crashing — so you can score the rules on a laptop before the model has ever run.

This separation is what makes the whole pipeline work across two machines.

### Invalid answers become a label

```python
INVALID = "INVALID"

def typology_of(row: Optional[dict]) -> str:
    """The typology a model gave, or INVALID when it gave none usable."""
    if row and row.get("typology") in ALL_LABELS:
        return row["typology"]
    return INVALID
```

An unusable answer is scored as the label `INVALID`, which matches nothing. So it counts as a **miss** for the true class and never as a correct prediction.

This is the honest choice. The alternatives would be to drop invalid answers (which would flatter the model by removing its worst cases) or to count them as `NO_CONCERN` (which would be a silent, dangerous default). Scoring them as wrong is right.

It also means the base model's 0.135 includes the cost of its 11.5% unusable outputs, which is exactly as it should be.

### The model-only extras

```python
def model_extras(examples, answers) -> dict:
    rows = [answers.get(example["alert_id"]) for example in examples]
    valid = sum(1 for row in rows if row and row["valid"])
    unfaithful = sum(1 for row in rows if row and UNFAITHFUL_PROBLEM in row["problems"])
    right_risk = sum(1 for example, row in zip(examples, rows)
                     if row and row.get("risk") == example["label"]["risk"])
    return {
        "valid_answers": share(valid, len(examples)),
        "faithful_reasons": 1 - share(unfaithful, len(examples)),
        "risk_accuracy": share(right_risk, len(examples)),
    }
```

Three metrics that only apply to models, because rules cannot fail to produce valid output and never produce a risk level or a reason.

`UNFAITHFUL_PROBLEM = "reason uses a number that is not in the summary"` — matching the exact string that `schema.py` appends. A brittle coupling between two files via a literal; a shared constant would be better. Worth noticing as a small flaw you can name.

---

## 12.3 The results

### Headline

| System | Macro-F1 test | Macro-F1 held-out | False alarms test / held-out | Valid JSON test / held-out | Risk accuracy test / held-out |
| --- | --- | --- | --- | --- | --- |
| A1 rules, default | 0.962 | 0.948 | 8.1% / 14.2% | n/a | n/a |
| A2 rules, tuned on train | 0.990 | 0.990 | 0.0% / 1.7% | n/a | n/a |
| B base model | 0.135 | 0.181 | 100% / 100% | 88.5% / 72.0% | 23.8% / 23.3% |
| **C fine-tuned** | **1.000** | **0.936** | 0.0% / 8.3% | 100% / 99.7% | 99.8% / 99.7% |

### Per-label, fine-tuned model on held-out

| Label | Precision | Recall | F1 |
| --- | --- | --- | --- |
| STRUCTURING | 1.00 | 1.00 | **1.00** |
| ROUND_TRIPPING | 0.96 | 1.00 | 0.98 |
| NO_CONCERN | 1.00 | 0.92 | 0.96 |
| RAPID_PASS_THROUGH | 0.88 | 0.96 | 0.91 |
| MULE_ACCOUNT | 0.80 | 0.87 | **0.83** |

### False alarms by kind, fine-tuned on held-out

| Kind | Rate |
| --- | --- |
| ordinary | 0.0% |
| cash_heavy_shop | 0.0% |
| house_sale | 0.0% |
| repay_friend | 13.3% |
| **salary_then_commitments** | **53.3%** |
| all `NO_CONCERN` | 8.3% |

---

## 12.4 Reading the results honestly

### What fine-tuning achieved

From 0.135 to 1.000 on test. The base model never once answered `NO_CONCERN` — its false-alarm rate is 100% on both splits — so it flagged every innocent customer. Valid JSON went from 88.5% to 100%, risk accuracy from 23.8% to 99.8%.

Risk accuracy is the cleanest demonstration. Risk is a deterministic function of a ratio printed in the summary: below 5 low, 5–15 medium, 15+ high. The base model got it right 23.8% of the time, barely above the 33% you would get by guessing one level constantly. The fine-tuned model got 99.8%. It learned a rule from examples without ever being told the rule.

**36 minutes on a free GPU turned a useless model into an accurate one.** That is the headline, and it is real.

### What fine-tuning did not achieve

It did not beat the tuned rules on held-out: **0.936 against 0.990**. It did not even beat the *default* rules there (0.948).

The PRD set the target explicitly:

| Metric | Target |
| --- | --- |
| Macro-F1 on held-out, fine-tuned vs rules baseline | fine-tuned higher |

And the README says plainly: *"The target in the PRD was for it to win; it did not."*

Writing the target down first and then reporting the miss is the single most credible thing in the repository. Most portfolio projects quietly redefine success afterwards.

### Why the test score is 1.000 and why you should distrust it

A perfect score should make you suspicious, and there are three reasons for it:

1. **The task is easy by design.** The summary prints the exact numbers that determine the label. "11 cash deposits just under ₹50,000" is in the text; the answer is STRUCTURING. There is no inference required, only recognition.
2. **Test shares wording templates with training.** Same three templates, same name pool, same income scale. The only new thing is the customers.
3. **The label space is tiny.** Five options, generated by deterministic rules.

So 1.000 means "the model learned the mapping on familiar wording". It does not mean the problem is solved. **This is exactly why the held-out set exists**, and why the honest number to quote is 0.936.

### Why the model lost on held-out

The held-out set changed three things at once: new wording templates, a new name pool, and incomes scaled by 1.6.

The rules were unaffected, scoring 0.990 on both test and held-out — identical. Of course: they read computed numbers, and numbers do not care how the sentence is worded.

The model dropped 0.064. It reads text, and the text was new.

Look at which classes broke:

- **Structuring survived perfectly** (F1 1.00). Its signal is the most distinctive — a count of just-under deposits — and it is phrased similarly across templates.
- **Mule accounts broke worst** (F1 0.83, precision 0.80). The mule signal is a conjunction: many senders **and** a quick cash-out **and** a young account. Compound conditions are harder to recognise through unfamiliar phrasing. The held-out templates say "remitters" and "distinct remitters" where training said "different senders".
- **`salary_then_commitments` went from 0% to 53.3% false alarms.** On test the model never confused it. On held-out it called it a pass-through more than half the time. This is the same hard negative that the default rules got wrong 80% of the time — it is the genuinely confusable case in the dataset, and the model's grip on it turned out to be shallow.

### The confound worth admitting

Three variables changed between test and held-out simultaneously. So you can say *that* the model generalised worse, but not *why*: was it the wording, the names, or the income scale?

An honest answer when asked:

> "I changed three things at once, which tells me there is a gap but not what caused it. To separate them I would build three held-out variants — new wording only, new names only, new income scale only — and score each. My guess is wording dominates, because the rules were completely unaffected and they are the only system that ignores wording. But it is a guess, and the experiment is cheap."

Saying this before being asked is much stronger than conceding it afterwards.

### The 1.6 income scale, specifically

Scaling incomes changes the ratios that drive risk. A ratio of 26.2× on test might become 16.4× on held-out for the same underlying behaviour. Risk accuracy held at 99.7%, so this did not break risk classification — but it means held-out amounts are outside the range seen in training, which is a second kind of distribution shift stacked on the wording shift.

---

## 12.5 The deepest limitation: synthetic data

Everything above is measured on data the project generated itself.

**Labels are true by construction.** `plant_structuring` was called, therefore the label is STRUCTURING. The model is learning to recover the generator's intent, which is a well-posed problem with a guaranteed answer.

Real AML has nothing like this. Ground truth is scarce, delayed and ambiguous: a suspicious-activity report is an opinion, a conviction takes years, and most alerts are simply closed with no definitive answer. A real model is trained on analyst dispositions, which are themselves noisy and inconsistent between analysts.

**Real data is messier** in ways this dataset cannot simulate: missing fields, free-text descriptions, customers who change behaviour innocently, seasonality, joint accounts, businesses that genuinely handle large cash volumes, and adversaries who deliberately adapt to whatever rules they can infer.

**And the generator and the features were written by the same person.** The patterns were planted in a form that `features.py` was designed to detect. That circularity is unavoidable in a synthetic project and should be stated.

What synthetic data bought in exchange: a shareable, reproducible, privacy-safe project with a controlled test of generalisation — none of which would have been possible with real transaction data.

**The one-sentence version:** *"The labels are true by construction, so the model is learning the generator, not the world. The results demonstrate that the pipeline works, not that the model would work in a bank."*

---

## 12.6 So why use the model at all?

The question you will be asked. Four honest answers, in order of strength.

**1. The rules have a home advantage that would not survive real data.** They read the exact computed features that produced the labels. On real statements — inconsistent descriptions, missing fields, behaviour that does not fit a template — hand-tuned thresholds degrade badly, and every bank and jurisdiction needs its own set. The model reads text and tolerated a complete rewording for 0.064.

**2. The model explains itself in words an analyst can check.** The rules give you "R1". The model gives you "11 cash deposits just under the ₹50,000 limit within 5 days, totalling ₹4,98,300" — a sentence that goes straight into a case note and can be verified against the evidence table. The explanation is the product, not a by-product.

**3. One pass produces three things.** Typology, risk and reason together. The rules produce one, and risk had to be computed separately.

**4. It adapts without an engineer.** A new wording, a new report format, a new jurisdiction's phrasing — the model needs more examples; the rules need someone to rewrite thresholds and redeploy.

**And the counter-argument you should concede:** rules are auditable, deterministic, instant, free to run, and fail in ways you can see and fix. In a regulated environment that is worth a great deal. The sensible production answer is both — rules for the clear cases, the model for explanation and for the ambiguous ones, with a human deciding.

---

## 12.7 What a v2 would do

The README states it as a labelled v2, not a tweak of these numbers:

> add more wording styles and income scales to the training data, retrain, and score on a **new** held-out set.

That last phrase is the important one. Once you have looked at held-out results, that set is contaminated as an unbiased measure — you now know where the model fails and any fix you make is informed by it. The only clean path is a fresh held-out set.

Beyond that, the experiments that would most improve the project:

1. **Vary one thing at a time** across three held-out variants, to isolate the cause of the gap.
2. **Rank sweep** — 4, 8, 16, 32 — to see whether less capacity generalises better.
3. **Run system D**, a prompted frontier model, to answer "is fine-tuning better than a good prompt?" This is the most obvious missing comparison and an interviewer may well ask why it was left out.
4. **More wording diversity in training** — the direct fix for the measured failure.
5. **Error analysis on the 53.3%** — read the actual held-out `salary_then_commitments` alerts the model got wrong and find out what it latched onto.

---

## 12.8 How to present this in an interview

Three beats, in this order:

1. "The base model scored 0.135 and never said no concern."
2. "After 36 minutes of QLoRA on a free T4, 1.000 on test with 100% valid JSON."
3. "On held-out wording it scored 0.936, and tuned rules scored 0.990. I report that because the point was a fair test, not a flattering one."

Give the third beat **without being asked**. It is the beat that makes the first two believable.

Then, if they push, you have: why the rules win on this data, what a v2 would change, and what three variables you confounded. That depth is what separates someone who ran a tutorial from someone who ran an experiment.

---

## 12.9 A note on the data these numbers describe

> **Added 13 November 2026.** On the day evidence links were added, the committed `data/raw/` files were found to be stale: for 83 of 1,000 alerts the shipped transactions did not reproduce the shipped features. Regenerating them fixed every case and changed **no** file in `data/*.jsonl` — the summaries, labels and features the model was trained and scored on. So every number in this chapter stands unchanged; what was wrong was the transaction lists the app displayed beside them. Chapter 22 tells the story, which is worth having ready: finding a data bug and being able to show it changed no result is a better answer than never having looked.

## 12.10 Exercises

1. A system labels everything `NO_CONCERN`. Compute its macro-F1 on a test set of 160 no-concern and 60 of each typology. What does this tell you about the floor of the metric?
2. Why does `typology_of` return `INVALID` rather than dropping the row? Work out how the base model's score would change under each choice.
3. The model scored 1.00 on structuring and 0.83 on mule accounts on held-out. Explain the difference using the structure of each pattern's signal.
4. Design three held-out variants that vary one thing each. What would you conclude from each possible outcome?
5. `UNFAITHFUL_PROBLEM` is a string literal duplicated between `evaluate.py` and `schema.py`. Write the fix and explain the bug it prevents.
6. Write and say out loud, in under sixty seconds, the answer to "your rules beat your model, so why did you fine-tune anything?"
