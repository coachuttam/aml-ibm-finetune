# Chapter 9 — LoRA, QLoRA, PEFT and NF4

The chapter an interviewer will dig into hardest. Every idea is tied to your actual configuration.

**Your configuration, for reference.**

```python
BASE_MODEL = "Qwen/Qwen2.5-1.5B-Instruct"
LORA_RANK = 16
LORA_ALPHA = 32               # usually twice the rank
LORA_DROPOUT = 0.05
LEARNING_RATE = 2e-4
EPOCHS = 2
BATCH_SIZE = 4
ACCUMULATION_STEPS = 4        # effective batch of 16
MAX_SEQ_LENGTH = 512
target_modules = "all-linear"
quantisation = 4-bit NF4, double quant, fp16 compute
```

Result: 18,464,768 trainable parameters, 1.18% of the model, 300 steps, 36 minutes on a free Colab T4.

---

## 9.1 The memory problem that forces all of this

Fine-tuning a model means storing four things on the GPU:

| | 1.5B parameters, fp16 |
| --- | --- |
| Weights | ~3 GB |
| Gradients (one per trainable weight) | ~3 GB |
| Adam optimiser state (two per trainable weight) | ~12 GB |
| Activations for the backward pass | 1–3 GB |
| **Total** | **~20 GB** |

A free Colab T4 has **16 GB**. Full fine-tuning does not fit, and not by a small margin.

Notice where the weight is: the optimiser. AdamW keeps a running mean and variance per trainable parameter, in fp32, which is four times the model's own size. So the lever with the biggest effect is not compressing the weights — it is **training fewer parameters**.

That is LoRA. Quantisation then handles the weights.

---

## 9.2 LoRA

### The idea

Freeze the pretrained weight matrix **W**. Learn a small update beside it, factored into two thin matrices.

```latex
W' = W + \frac{\alpha}{r} BA
```

where **A** is r × k, **B** is d × r, and r is much smaller than d or k.

A concrete case from your model. Qwen2.5-1.5B has a hidden size of 1536, so a square projection is 1536 × 1536 = **2,359,296** parameters. At rank 16:

- A is 16 × 1536 = 24,576
- B is 1536 × 16 = 24,576
- Total 49,152 — about **2%** of the full matrix

Multiply that saving across every linear layer in 28 blocks and you get 18.5M trainable instead of 1.5B.

### Why it starts as a no-op

**B is initialised to zeros, A to small random values.** So `BA = 0` at step 0, the update is exactly zero, and the model begins as the unmodified pretrained model.

This matters more than it sounds. If both were random, the first forward pass would be the pretrained model plus random noise, and you would spend early training recovering from damage you caused. Starting at zero means training only ever moves away from a good starting point.

### Why low rank is enough

The intuition: the pretrained weights already encode language, grammar, number formats and instruction-following. What fine-tuning adds is narrow — "when you see many cash deposits just under a limit, say STRUCTURING". That change does not need the expressive power of a full 1536 × 1536 matrix.

The empirical claim from the LoRA paper is that the weight *update* during adaptation has low intrinsic rank. Rank 8 to 64 typically matches full fine-tuning on narrow tasks.

### Rank: what changes when you move it

| Rank | Trainable params | Behaviour |
| --- | --- | --- |
| 4 | ~4.6M | May underfit a complex task; fine for narrow ones |
| 16 (yours) | 18.5M | Standard default |
| 64 | ~74M | More capacity, more memory, overfits faster on small data |

Expect the follow-up: *"What would happen at rank 4?"*

Your honest answer: **"I did not test it, and I should have. Given the task is narrow and the model clearly latched onto wording — 1.000 on test, 0.936 on held-out — I would expect rank 4 to perform about the same and possibly generalise slightly better, because there is less capacity to memorise phrasing. It is the first experiment I would run."**

That answer is better than a confident guess, because it names the evidence and the prediction.

### Alpha

`alpha / r` scales the update before it is added. With alpha 32 and rank 16, the scale is **2**.

The convention of alpha = 2 × rank exists so that changing rank does not also change the effective update magnitude — the scaling compensates. Think of alpha as a second learning-rate knob on the adapter alone.

Your code's comment says it plainly: `LORA_ALPHA = 32  # usually twice the rank`. That is an honest statement that you followed the convention, which is the right thing to do and the right thing to say.

### Dropout

`LORA_DROPOUT = 0.05` randomly zeroes 5% of activations inside the adapter during training. Standard regularisation: it stops the adapter relying too heavily on particular paths. Disabled automatically at inference.

### Target modules

```python
target_modules="all-linear"
```

PEFT resolves this string to every linear layer in the model: the attention projections (q, k, v, o) and the feed-forward layers (gate, up, down). The original paper adapted only q and v; adapting everything is now the common default and usually performs better.

Note this is a **string**, not an explicit list. If asked "which modules did you target?", the precise answer is: *"I used PEFT's `all-linear`, which resolves to every linear layer — attention projections and MLP. I did not hand-pick a subset."*

---

## 9.3 Quantisation and NF4

LoRA solved the optimiser problem. The 3 GB of frozen weights still has to sit in memory. Quantisation shrinks it.

### The basic idea

A weight stored in fp16 uses 16 bits. At 4 bits, it uses a quarter of that: 3 GB becomes about 0.8 GB.

Weights are grouped into blocks (64 by default). Each block gets a scaling constant. Within a block, each weight is mapped to one of 16 levels. To use a weight you read its 4-bit code and multiply by the block's constant.

### What NF4 adds

Ordinary 4-bit integer quantisation spaces its 16 levels evenly. But neural network weights are not uniformly distributed — they are roughly **normal**, clustered near zero.

With even spacing, most levels sit in the sparse tails where almost no weights live, and the dense region near zero is represented coarsely. Precision is wasted.

**NF4 (4-bit NormalFloat)** places its 16 levels at the quantiles of a normal distribution, so each level accounts for roughly the same number of weights. For normally distributed data this is information-theoretically optimal. In practice it loses noticeably less accuracy than int4 at the same size.

That is the whole answer to "what is NF4?": *"4-bit NormalFloat. The levels are placed by quantiles of a normal distribution instead of evenly, because weights are roughly normal, so the precision goes where the weights actually are."*

### Double quantisation

```python
bnb_4bit_use_double_quant=True
```

Each block of 64 weights carries a scaling constant, typically fp32. That is 32 bits per 64 weights — half a bit per weight — which is not nothing when the weights themselves are 4 bits.

Double quantisation quantises those constants too. The saving is roughly half a bit per parameter, with negligible quality cost. Pure memory optimisation.

### Compute dtype

```python
bnb_4bit_compute_dtype=torch.float16    # a T4 cannot do bfloat16
```

**Storage and compute are different.** Weights live in memory as NF4 and are dequantised to fp16 when a layer actually runs. The arithmetic is 16-bit; only storage is 4-bit.

Three consequences:

1. QLoRA saves **memory**, not time. The dequantisation step means 4-bit inference is often *slower* than fp16.
2. Gradients flow through in fp16 and update the fp16 adapters. The 4-bit weights are frozen and never updated.
3. Numerical behaviour is fp16's, not int4's.

The comment `# a T4 cannot do bfloat16` is a real hardware fact worth knowing. bf16 has the same exponent range as fp32 with less mantissa, making it more robust to overflow in training. It needs Ampere (A100, RTX 30xx) or newer; the T4 is Turing, so fp16 it is — which is also why `fp16=True` appears in the training arguments.

### Paged optimisers

Not used in your config, but you will be asked. Optimiser state spikes can push memory over the edge mid-run. Paged optimisers use NVIDIA unified memory to move optimiser state between GPU and CPU automatically when that happens, like operating-system paging. They trade a little speed for not crashing.

---

## 9.4 Putting it together: what QLoRA actually is

Three techniques stacked:

1. **4-bit NF4 quantisation** of the frozen base → weights fit in memory
2. **LoRA adapters** in fp16 on top → few trainable parameters, small optimiser state
3. **fp16 compute** → arithmetic stays stable

```
       ┌──────────────────────────────┐
       │  Frozen base weights (NF4)   │   ~0.8 GB, never updated
       └──────────────┬───────────────┘
                      │ dequantise to fp16 per layer
                      ▼
       ┌──────────────────────────────┐
       │  + LoRA adapters (fp16)      │   18.5M params, trained
       └──────────────────────────────┘
```

Your memory budget, roughly:

| | |
| --- | --- |
| Base weights in NF4 | ~0.9 GB |
| LoRA adapters fp16 | ~0.04 GB |
| Gradients for adapters | ~0.04 GB |
| Adam state for adapters | ~0.15 GB |
| Activations, batch 4, length 512 | 1–2 GB |
| **Total** | **~3 GB** |

Against 20 GB for full fine-tuning. That is how it fits on a free GPU — and why the evaluation batch size had to drop to 2 anyway, as §9.6 explains.

---

## 9.5 The code that does it

```python
def load_model_and_tokenizer(base_model: str):
    """Load the base model in 4-bit and attach small trainable LoRA layers."""
    import torch
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

    quantisation = BitsAndBytesConfig(
        load_in_4bit=True, bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,       # a T4 cannot do bfloat16
        bnb_4bit_use_double_quant=True)
    tokenizer = AutoTokenizer.from_pretrained(base_model)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        base_model, quantization_config=quantisation, device_map={"": 0})
    model = prepare_model_for_kbit_training(model)
    lora = LoraConfig(r=LORA_RANK, lora_alpha=LORA_ALPHA, lora_dropout=LORA_DROPOUT,
                      target_modules="all-linear", task_type="CAUSAL_LM")
    model = get_peft_model(model, lora)
    model.print_trainable_parameters()
    return model, tokenizer
```

Line by line:

**`import torch` inside the function.** Deliberate. The heavy libraries are only installed on Colab, so importing them at module level would break every test on the laptop. This is **lazy importing**, and it is why `tests/test_predict.py` can test the checking logic with a fake model and no GPU. A genuinely good design decision worth pointing out.

**`BitsAndBytesConfig`** — the four quantisation settings discussed above.

**`tokenizer.pad_token = tokenizer.eos_token`** — many causal models define no padding token, because generation never needs one. Batched training does. Reusing the end-of-sequence token is the standard workaround, and it is safe here because the attention mask marks padding as ignorable.

**`device_map={"": 0}`** — put the whole model on GPU 0. The empty string means "the root module, all of it". With multiple GPUs you would pass `"auto"` and let Accelerate shard it.

**`prepare_model_for_kbit_training(model)`** — the step people forget. It casts layer norms to fp32 for stability, enables gradient checkpointing, and makes input embeddings require gradients so the backward pass can flow through the frozen quantised layers. Without it, training a 4-bit model is unstable or silently produces no gradients.

**`task_type="CAUSAL_LM"`** — tells PEFT this is next-token prediction, which determines how the model is wrapped.

**`model.print_trainable_parameters()`** — prints the line that produced your headline number:

```
trainable params: 18,464,768 || all params: 1,562,179,072 || trainable%: 1.1820
```

That figure comes from PEFT at runtime; it is not hard-coded anywhere in the repo. Useful to know if someone asks where it came from.

---

## 9.6 Gradient accumulation and the batch size

```python
BATCH_SIZE = 4
ACCUMULATION_STEPS = 4        # effective batch of 16 without needing more memory
EVAL_BATCH_SIZE = 2           # the model scores 150,000 word pieces per position
```

**Gradient accumulation** runs four batches of 4, adding up the gradients, then performs one optimiser update. The optimiser sees the gradient of 16 examples; memory only ever holds 4.

Large batches give smoother gradient estimates and more stable training. Accumulation buys that stability without the memory.

The arithmetic checks out against your run:

```
2,400 examples ÷ 16 effective batch = 150 steps per epoch
150 × 2 epochs = 300 steps          ← matches the reported 300
```

And warmup:

```python
def count_warmup_steps(example_count: int, epochs: int) -> int:
    steps_per_epoch = -(-example_count // (BATCH_SIZE * ACCUMULATION_STEPS))   # round up
    return max(1, int(steps_per_epoch * epochs * WARMUP_SHARE))
```

With `WARMUP_SHARE = 0.05`: 150 × 2 × 0.05 = **15 warmup steps**.

`-(-a // b)` is the ceiling-division idiom: floor-divide the negative, then negate. For 2400 and 16 it gives exactly 150; for 2401 it would give 151, whereas plain `//` would give 150 and lose the last partial batch.

The docstring explains why the function exists at all: *"Counted by hand because libraries rename the ratio option."* A newer Transformers release dropped `warmup_ratio`, so the project computes steps itself and pins the behaviour with a test. A small, real engineering story.

**Why eval batch size is 2.** The comment gives the reason: the model produces a score for every one of roughly 150,000 vocabulary entries at every position. For a batch of 8 at length 512 that logits tensor alone is `8 × 512 × 150000 × 2 bytes ≈ 1.2 GB`, and evaluation keeps it. Dropping to 2 avoids an out-of-memory crash. This is in the README's problems table as a bug that actually happened.

---

## 9.7 Comparison with the alternatives

| Method | Trains | Inference cost | Notes |
| --- | --- | --- | --- |
| Full fine-tuning | all weights | none added | Best quality on large data; 20 GB+ here |
| **LoRA / QLoRA** | low-rank adapters | none once merged | The default choice |
| Adapter layers | inserted blocks | adds latency | Pre-LoRA approach |
| Prefix / prompt tuning | soft input vectors | tiny | Cheapest, weakest |
| IA3 | activation rescalings | tiny | Very few parameters |
| DoRA | magnitude + direction | none once merged | Often beats LoRA at similar cost |

LoRA won because it adds **no inference latency once merged** — the update can be folded into the original weights — and because the tooling is mature.

---

## 9.8 Merging, and the honest limit

You can merge the adapter into the base weights and save a normal model. Then nothing at inference knows LoRA was ever involved.

The trade-offs:

- You lose adapter swapping — the merged model is one variant, fixed.
- You need a full model copy per variant, gigabytes each.
- Merging into a **4-bit** base needs care: the normal route is dequantise to fp16, merge, re-quantise, and that round trip can shift quality.

**Your project never did this.** The README's limitations say CPU inference is slow and the demo uses precomputed verdicts. So if asked whether you merged: *"No. I published the adapter only. Merging into a quantised base needs a dequantise-merge-requantise cycle I did not validate, and the demo runs on saved answers so it never needed a merged model."*

### The multi-adapter architecture — your best product argument

Because adapters are small (tens of megabytes) and swappable, one base model in memory can serve many adapters, one per customer or jurisdiction. vLLM supports multi-LoRA serving for exactly this.

For an employer with hundreds of banking customers across many countries — different typologies, thresholds, languages and regulators — that is a genuinely strong architecture: one base model, one small adapter per customer, no duplicated infrastructure.

This is the point in an interview where your project stops being a demo and becomes a proposal.

---

## 9.9 Exercises

1. Compute the LoRA parameter count for one 1536 × 1536 projection at ranks 4, 16 and 64. What percentage of the full matrix is each?
2. Why is B initialised to zeros rather than randomly? What would the first forward pass look like otherwise?
3. Explain NF4 to someone who understands histograms but not deep learning.
4. If storage is 4-bit but compute is fp16, why is 4-bit inference often slower than fp16?
5. Your effective batch is 16 with per-device batch 4. What changes if you set batch 16 and accumulation 1? What stays the same?
6. Work out the warmup steps for 5,000 examples and 3 epochs with the same constants.
7. Write the one-paragraph case for serving one base model with per-customer adapters, aimed at a bank with 800 customers.
