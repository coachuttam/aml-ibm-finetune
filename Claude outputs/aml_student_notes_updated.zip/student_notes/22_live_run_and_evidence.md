# Chapter 22 — The live run and evidence links

Added 13 November 2026. Everything in chapters 1 to 21 describes the project as it stood when the app showed **saved** model answers. This chapter covers the three changes made after that: an uploaded alert can now be classified live, each computed finding links to the transaction rows behind it, and a data bug the second change exposed.

New source files: `src/upload.py`, `src/live.py`, `src/local_model.py`, `src/remote_model.py`, `src/evidence.py`, `model_server.py`, `upload_view.py`, `evidence_view.py`. New tests: `tests/test_live.py` (17) and `tests/test_evidence.py` (10).

---

## 22.1 Why this mattered

The honest description of the old app was: it shows answers a GPU produced earlier. Chapter 11 called the model "the classifier", but nothing in the running app called it. For a demo that is a real weakness — a reviewer can reasonably ask whether the model works at all, or only worked once.

The fix is not a new model. It is a path from an uploaded file to a checked verdict, using **the same** features, the same wording templates, the same prompt and the same output checker as the training data. If any of those differed, a live answer would not be comparable with the scored ones.

```
upload.py        CSV + typed profile  →  RawAlert
live.py          RawAlert → features → summary → model → check → ReviewAlert
local_model.py   the model, on this computer
remote_model.py  the model, on a hosted GPU (model_server.py)
```

---

## 22.2 `upload.py` — the input contract

The file is a CSV with five required columns:

```
day,amount,direction,channel,counterparty
2026-09-01,48000,credit,cash,Cash deposit
```

`txn_id` is optional and generated when missing. The customer profile (occupation, declared income, account age) is typed into the form, not read from the file, because a bank's own system would supply it.

Every field is validated, and **the error names the row**:

```python
def read_amount(text: str, row_number: int) -> int:
    cleaned = text.replace(",", "").strip()
    if not cleaned.isdigit() or int(cleaned) == 0:
        raise UploadError(f"Row {row_number}: amount must be a positive whole number, got '{text}'.")
    return int(cleaned)
```

Row numbers start at 2, so they match what the person sees in a spreadsheet — the header is row 1. That detail is worth noticing: an error message that says "row 7" and means the eighth line is worse than no message at all.

Other defences: a `MAX_ROWS` cap of 2,000 so a huge file cannot freeze the app, `utf-8-sig` decoding so a file exported from Excel does not fail on its byte-order mark, column names lower-cased so `Day` works as well as `day`, and amounts with thousands separators accepted.

The result is a `RawAlert` — the same dataclass the generator produces — with `typology = "NOT_KNOWN"`, because an uploaded alert has no ground truth. That one substitution is what lets every downstream function treat it identically to a generated alert.

**Known limit, worth saying out loud:** the file must already use the eight channel names the generator uses (`cash`, `upi`, `imps`, `neft`, `rtgs`, `atm`, `salary`, `internal`). A real bank export would need a mapping step first.

---

## 22.3 `live.py` — one alert through the pipeline

```python
def build_live_alert(raw, generate, tuned_config) -> ReviewAlert:
    example = build_live_example(raw)
    checked = ask_model(example["summary"], generate)
    answer = {"valid": checked.valid, "typology": checked.typology, "risk": checked.risk,
              "reason": checked.reason, "problems": checked.problems}
    return build_review_alert(example, tuned_config, answer, None, raw.window_end.isoformat())
```

Four things to note:

1. `build_live_example` is `dataset.build_example` without the label — the same `compute_features`, the same `pick_template`, the same `render_summary`. The model sees a summary indistinguishable in form from a training one.
2. `ask_model` runs `check_answer` and retries once on failure, exactly as `classify_with_retry` does in `predict.py`.
3. `build_review_alert` is the app's existing joiner, so the screen cannot tell a live alert from a saved one.
4. `generate` is passed in, not imported. That is why the tests can run the whole live path with a three-line fake model and no GPU.

---

## 22.4 Where the model actually runs

Two options, chosen by environment variable, with a fallback if neither is available.

**On this computer** (`local_model.py`, `AML_LOCAL_MODEL=1`): loads `Qwen2.5-1.5B-Instruct` plus the published adapter, picks the fastest device available (`mps` on an Apple machine, `cuda`, else `cpu`), and caches the loaded model with `functools.lru_cache` so it is built once per process.

```python
precision = torch.float32 if device == "cpu" else torch.float16
```

**An honest caveat you must volunteer, not hide:** the published scores came from the **4-bit** (NF4) copy of the base model on a T4, as chapter 9 describes. `bitsandbytes` does not run on a Mac, so this path loads the model at **half precision** instead. Same weights, same adapter, same prompt — but not the exact numerical setup that was scored. On a laptop one alert takes roughly 15 to 20 seconds, and the first load a few minutes.

**On a hosted GPU** (`remote_model.py` + `model_server.py`): a Modal endpoint that loads the model with `src/predict.py` — so the hosted path is bit-for-bit the scored setup — sleeps when idle, and requires a proxy auth token. Only the standard library is used on the client side:

```python
headers = {"Content-Type": "application/json", "Modal-Key": key, "Modal-Secret": secret}
```

The address and token come from the environment, never from a file in the repo. `live_generate` returns `None` unless the address starts with `https://`, so a misconfigured deployment fails closed rather than sending an alert over plain HTTP.

**Deliberately not deployed.** Modal requires a payment method before it will run any GPU, even inside its free monthly credit. For a demo given in person, the local path is better anyway: no cold start, no network, and it supports the claim that no customer data leaves the machine.

---

## 22.5 Failing safe

If no model is connected, or the hosted one times out, the alert does not error and does not get a guessed verdict. It goes to **needs review**, with the reason shown:

```python
def ask_model(summary, generate) -> CheckedAnswer:
    if generate is None:
        return failed_answer(MODEL_NOT_CONNECTED)
    try:
        checked = check_answer(generate(summary), summary)
        return checked if checked.valid else check_answer(generate(summary), summary)
    except ModelUnavailable as problem:
        return failed_answer(str(problem))
```

The computed findings and both rules baselines still run, so the analyst is not left with nothing. This is the same failure mode as an answer that fails the output checks — one state, not two, which is why no new UI was needed for it. The public Streamlit demo runs in exactly this state, since Community Cloud has no GPU.

---

## 22.6 `evidence.py` — a claim and its receipts

A finding says "6 cash deposits just under the reporting limit within 6 days, totalling ₹2,53,600". The question an analyst asks next is *which six*.

Answering it is pure Python. The model is not involved and must not be: the findings were computed from the transactions, so the link can be **exact** rather than generated. This is the strongest version of the project's design rule.

```python
def just_under_rows(credits):
    low = JUST_UNDER_LOW * CASH_REPORTING_LIMIT
    high = JUST_UNDER_HIGH * CASH_REPORTING_LIMIT
    return [c.txn_id for c in credits if c.channel == "cash" and low <= c.amount <= high]
```

Four kinds: `just_under`, `large_credits`, `senders`, `returns`. Every threshold is imported from `features.py` or `patterns.py` — none is restated. `features.py` gained one small refactor for this: the pairing loop inside `return_features` became `find_returned_pairs`, so the evidence code reuses the rule instead of copying it.

`build_findings_with_rows` pairs each finding with its rows by calling `case_note.build_findings` for the text, so wording and order can never drift from the case note. Findings that are not about specific rows — the money-in/out line, "none of the four patterns showed up" — get an empty list.

**The drift guard.** The obvious risk is that the evidence rules slowly diverge from the feature rules, and the links quietly become wrong. The tests assert the two agree:

- the number of `just_under` rows equals `just_under_count`
- the credit rows in `large_credits` equal `large_count`
- the distinct senders in `senders` equal `sender_count`
- the `returns` rows equal `return_count`
- every returned id exists in the alert
- row lists are empty whenever the matching feature count is zero

Three places where the spec and reality differed, all resolved in favour of reality: `returns` uses every returned pair rather than same-party only, because `return_same_party` is a subset; `senders` rows are payments, so their count can exceed the distinct-sender count; and an ordinary alert can legitimately contain one large credit, so the "nothing planted" test uses a hand-built ledger.

**Where it shows up.** A "Computed findings" block above the evidence table, each finding expanding to its rows; a ● against any cited row in the evidence table; and the row ids appended to each finding in the exported case note:

> 6 cash deposits just under the reporting limit within 6 days, totalling ₹2,53,600. (rows: U-20261113-144337-T004, …)

That last one is what makes the note auditable on paper, which is what the README's audit-store section promises.

`review.supports_verdict` was deleted. It only marked structuring and pass-through rows, and chapter 14 praised it for admitting that limit honestly — but the evidence mapping covers all four typologies, so the limit no longer exists.

---

## 22.7 The bug this found

Adding evidence links raised a question nobody had asked: do the transactions shipped in `data/raw/` actually reproduce the features in `data/*.jsonl`?

For **83 of 1,000 alerts, they did not** — 20 in validation, 38 in test, 25 in held-out. The mismatches were in `debits_total`, `top_payees` and the return counts. The committed raw files had been generated by an earlier state of the generator and never refreshed, while the derived files had been. So for those alerts the app's evidence table showed rows that did not add up to the summary beside them.

Regenerating `data/raw/` fixed all 83, and `data/*.jsonl` did not change by a single byte — which is the important part, because it means **no published score moved**. The model was always trained and scored on the derived files; only the shipped transaction lists were stale.

The check is worth remembering as a technique: *derived data and its source must round-trip*. Rebuild the inputs, recompute, compare. It is three lines of code and it catches a class of bug that tests passing green will not.

Interview framing: "Adding evidence links surfaced a data-integrity bug — 8% of shipped alerts had transactions that didn't match their summaries. I found it because linking a claim to its source forces you to check that the source supports the claim."

---

## 22.8 What changed in the app

`app.py` stayed under the 300-line limit by moving the findings and evidence drawing into `evidence_view.py` (62 lines), with `upload_view.py` (85 lines) holding the Live run tab. There are now five tabs:

```python
queue_tab, detail_tab, live_tab, evaluation_tab, audit_tab = st.tabs(
    [f"Alerts ({len(alerts)})", "Alert detail", "Live run", "Evaluation", f"Audit log ({event_count})"])
```

`upload_view` draws its result by calling the same `show_alert` the saved alerts use, so an uploaded alert gets the verdict panel, the comparison table, the findings, the evidence table and the six-step investigation without a line of duplicated UI code. The comparison table drops the base-model and true-label rows for uploads, since neither exists.

---

## 22.9 Questions you should be ready for

**"Is the model actually running, or is this a recording?"**
> It runs live on this laptop. Upload a file and it classifies it in about 15 seconds. The scores in the README came from a GPU run on a held-out set, not from live calls.

**"How do I know the reason isn't made up?"**
> Two layers. The model only ever sees a summary of numbers Python computed, and a check rejects any answer containing a number that isn't in that summary. Separately, the findings in the case note are written by Python, not the model, and each one lists the transaction ids it was computed from.

**"Why not just use rules, if the rules won?"**
> On held-out wording the tuned rules did win, and the README says so. The model's value is the explanation and the generalisation to wording it hasn't seen; the rules' value is exactness. Running both and flagging disagreement is better than either alone, which is what the screen does.

**"Could this run inside our bank?"**
> The classifier is open weights with a 74 MB adapter, so it runs on your hardware with nothing leaving the building. What's missing is listed in the README: an audit store with retention, validation documentation, drift monitoring, PII masking and STR drafting.

---

## 22.10 Exercises

1. Add a "Customer reference" field to the Live run form so the uploaded alert carries a real customer id instead of `C-upload`.
2. Write a test that an uploaded CSV whose channel names are unknown fails with a message naming the row, then add a mapping step that accepts common bank export names (`NEFT Cr`, `UPI/P2M`) and maps them to the eight known channels.
3. The `senders` evidence currently returns the busiest-week payments. Extend it to return one row per distinct sender instead, and decide which is more useful to an analyst.
4. Write the round-trip check from 22.7 as a committed test so the raw files can never go stale again. Think about whether it belongs in the test suite or in a separate data-integrity script, and why.
5. `local_model.py` loads at half precision while the scored setup was 4-bit. Measure how often the two disagree on the test split, and add the number to the README.
