# Chapter 3 — Data containers and small helpers

Four files with no dependencies of their own: `models.py`, `money.py`, `names.py` and `schema.py`. Everything else in the project imports from them.

---

## 3.1 `src/models.py` — the shapes everything agrees on

```python
@dataclass(frozen=True)
class Transaction:
    """One money movement on the customer's account."""

    txn_id: str
    day: date
    amount: int         # whole rupees, always positive
    direction: str      # "credit" (money in) or "debit" (money out)
    channel: str        # cash, upi, imps, neft, rtgs, atm, salary or internal
    counterparty: str   # who sent or received the money
```

### What a dataclass is

Without `@dataclass` you would write this by hand:

```python
class Transaction:
    def __init__(self, txn_id, day, amount, direction, channel, counterparty):
        self.txn_id = txn_id
        self.day = day
        # ... six more lines
    def __repr__(self):
        return f"Transaction(txn_id={self.txn_id!r}, ...)"
    def __eq__(self, other):
        return (self.txn_id, self.day, ...) == (other.txn_id, other.day, ...)
```

`@dataclass` writes `__init__`, `__repr__` and `__eq__` for you from the field annotations. Thirty lines become six.

### What `frozen=True` adds

It makes instances immutable. After creation you cannot do `txn.amount = 999` — Python raises `FrozenInstanceError`.

Why that matters here: transactions and customers are *facts*. Once the generator has produced an alert, nothing downstream should be able to change it quietly. A bug that modifies a transaction inside `compute_features` would be very hard to find. `frozen=True` turns that bug into an immediate, loud error.

A second benefit: frozen dataclasses are hashable, so you can put them in a `set` or use them as dictionary keys.

### Why `amount` is an `int`

Money is stored as whole rupees in an integer, never a float. Floats cannot represent decimal fractions exactly:

```python
>>> 0.1 + 0.2
0.30000000000000004
```

In a system that sums thousands of amounts and compares them against thresholds, that error accumulates. The rule across finance software is: store money as an integer in the smallest unit, or use `Decimal`. This project uses whole rupees, which is simpler and exact.

### The three containers

| Class | Frozen? | Why |
| --- | --- | --- |
| `Transaction` | yes | A historical fact |
| `Customer` | yes | A profile that does not change inside the window |
| `RawAlert` | **no** | Built up in stages, so it needs to be mutable |

`RawAlert` holds the alert id, the split, the template group, the customer, the window dates, the transaction list, the true typology, and the hard-negative kind if there is one.

```python
@dataclass
class RawAlert:
    alert_id: str
    split: str
    template_group: str
    customer: Customer
    window_start: date
    window_end: date
    transactions: List[Transaction]
    typology: str
    hard_negative_kind: Optional[str] = None
```

`Optional[str]` means "a string or `None`". It is the same as `Union[str, None]`. On Python 3.10+ you could write `str | None`, but this project targets 3.9, so `Optional` it is — see the `from __future__ import annotations` line at the top of every file, explained in Chapter 18.

**Note the field with a default comes last.** Python requires that: fields without defaults must precede fields with them, exactly like function arguments.

---

## 3.2 `src/money.py` — 23 lines that make the output readable

```python
def plural(count: int, noun: str) -> str:
    """'1 deposit' or '4 deposits'."""
    return f"{count} {noun}" if count == 1 else f"{count} {noun}s"
```

Trivial, but it exists because of a real bug. An earlier version produced summaries saying "1 payments", and the fix was this helper plus reworded templates. It is in the README's problems table.

Why it matters more than it looks: the model is learning from this text. Inconsistent grammar is noise in the training signal, and in the worst case it is a shortcut — if only genuine patterns ever said "payments" and benign ones said "payment", the model could learn the plural instead of the pattern.

### Indian digit grouping

```python
def format_rupees(amount: int) -> str:
    """Format with Indian digit grouping: 102000 becomes '₹1,02,000'."""
    digits = str(abs(int(amount)))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        digits = ",".join(groups + [tail])
    sign = "-" if amount < 0 else ""
    return f"{sign}₹{digits}"
```

Western grouping is every three digits: `1,020,000`. Indian grouping is three digits, then **twos**: `10,20,000`. Python's built-in `f"{n:,}"` only does the Western form, so this has to be written by hand.

Walking through `format_rupees(102000)`:

| Step | `head` | `tail` | `groups` |
| --- | --- | --- | --- |
| start | `"102"` | `"000"` | `[]` |
| `len(head) > 2` → take last two | `"1"` | `"000"` | `["02"]` |
| loop ends (`len("1")` is 1) | `"1"` | `"000"` | `["02"]` |
| `if head` → prepend remainder | | | `["1", "02"]` |
| join `groups + [tail]` | | | `"1,02,000"` |

Result: `₹1,02,000`.

Test cases from `tests/test_features.py` show the edges:

```python
assert format_rupees(0)          == "₹0"
assert format_rupees(999)        == "₹999"
assert format_rupees(1_000)      == "₹1,000"
assert format_rupees(102_000)    == "₹1,02,000"
assert format_rupees(12_345_678) == "₹1,23,45,678"
assert format_rupees(-1_500)     == "-₹1,500"
```

**Python detail:** `1_000` is just `1000`. Underscores in numeric literals are ignored by Python and exist purely for human readability. Used throughout this codebase for large numbers.

**Why handle the sign separately?** Because `abs()` is applied first to get clean digits, then the minus sign is put back *before* the rupee symbol. `-₹1,500` reads correctly; `₹-1,500` does not.

---

## 3.3 `src/names.py` — two pools, and why there are two

```python
@dataclass(frozen=True)
class NamePool:
    first_names: Tuple[str, ...]
    last_names: Tuple[str, ...]
    business_endings: Tuple[str, ...]

    def all_people(self) -> List[str]:
        return [f"{first} {last}" for first in self.first_names for last in self.last_names]
```

`Tuple[str, ...]` means "a tuple of any length, all strings". Tuples rather than lists because the pool is fixed and a frozen dataclass needs hashable fields.

`all_people` is a **nested list comprehension**. Read it as:

```python
result = []
for first in self.first_names:
    for last in self.last_names:
        result.append(f"{first} {last}")
```

The outer loop comes first in the comprehension, exactly as it does when written out. With 16 first names and 10 last names, that is 160 distinct people per pool.

### The point of the second pool

```python
STANDARD_NAMES = NamePool(
    first_names=("Ravi", "Sunita", "Manoj", ...),
    last_names=("Kumar", "Sharma", "Patel", ...),
    business_endings=("Traders", "Enterprises", "Stores", "Agencies"))

# Used only for the held-out set: no first name, last name or ending is shared.
HELDOUT_NAMES = NamePool(
    first_names=("Farhan", "Gayatri", "Harish", ...),
    last_names=("Banerjee", "Chawla", "Desai", ...),
    business_endings=("Logistics", "Ventures", "Distributors", "Services"))
```

The held-out set exists to test whether the model learned the *pattern* or the *surface text*. If "Sharma Traders" appeared in both training and held-out data, the model could latch onto familiar names. Different names remove that path. The two pools share nothing — no first name, no surname, no business ending — and a test enforces it.

This is one of several independent changes that make held-out harder: different names, different wording templates, and incomes scaled by 1.6. Chapter 12 discusses whether changing three things at once was wise.

### `rng.sample` versus `rng.choice`

```python
def person(self, rng): return rng.choice(self.all_people())
def people(self, rng, count): return rng.sample(self.all_people(), count)
```

`choice` picks one item and can repeat across calls. `sample` picks `count` **distinct** items. The mule-account pattern needs many *different* senders, so it uses `sample` — with `choice` in a loop, the same person could pay in twice and the sender count would be wrong.

---

## 3.4 `src/schema.py` — the vocabulary, and the gate

This file does two jobs: it holds the label lists, and it checks model output. The checker is covered fully in Chapter 11; here is the vocabulary half.

```python
TYPOLOGIES = (
    "STRUCTURING",         # cash split into deposits just under a reporting limit
    "RAPID_PASS_THROUGH",  # large money in, almost all of it out again within days
    "MULE_ACCOUNT",        # many unrelated senders, then a quick cash-out
    "ROUND_TRIPPING",      # money sent out comes back through other parties
)

NO_CONCERN = "NO_CONCERN"
ALL_LABELS = TYPOLOGIES + (NO_CONCERN,)
RISK_LEVELS = ("low", "medium", "high")
SPLITS = ("train", "validation", "test", "heldout")

MAX_REASON_LENGTH = 200
BANNED_WORDS = ("fraud", "criminal", "guilty")   # we refer for review, we never accuse
```

### Why tuples, not lists

Tuples are immutable. A stray `ALL_LABELS.append("SOMETHING")` anywhere in the codebase would be an error rather than a silent corruption of the label space. For constants that must never change at runtime, a tuple is the right container.

`ALL_LABELS = TYPOLOGIES + (NO_CONCERN,)` concatenates two tuples. Note the trailing comma in `(NO_CONCERN,)` — without it, `(NO_CONCERN)` is just a string in brackets, and `TYPOLOGIES + "NO_CONCERN"` raises a `TypeError`. This is one of Python's sharpest edges for beginners.

### Why `NO_CONCERN` is separated from `TYPOLOGIES`

Because they mean different things. `TYPOLOGIES` is "the four laundering patterns"; `ALL_LABELS` is "everything the model may answer". The generator loops over `TYPOLOGIES` when planting patterns. The checker validates against `ALL_LABELS`. Keeping them distinct means neither loop needs a special case.

### The banned words

Three words the system never uses about a customer: *fraud*, *criminal*, *guilty*. This is not squeamishness. In real compliance work, an unproven accusation recorded against a customer is a legal problem, and the correct language is "refer for review". The constant is enforced in three places:

- `schema.find_problems` rejects model output containing them.
- `case_note.assert_clean_wording` refuses to build a note containing them, and rejects an analyst's note too.
- `tests/test_review.py` reads `app.py` as text and asserts none of the words appear in the UI source.

That last one is unusual and worth mentioning in an interview: a test that greps your own user interface for forbidden language.

---

## 3.5 Exercises

1. Make a `Transaction` and try to change its `amount`. What exception do you get, and from which decorator?
2. Write `format_rupees` yourself, without looking, then test it against `0`, `999`, `1000`, `102000` and `-1500`.
3. Why does `plural(0, "deposit")` return "0 deposits" and not "0 deposit"? Check the condition.
4. In a REPL, build a `NamePool` with 3 first names and 2 last names and call `all_people()`. How many names? Now call `people(rng, 10)` and explain the error.
5. Remove the trailing comma from `(NO_CONCERN,)` in a scratch copy and see what `ALL_LABELS` becomes.
