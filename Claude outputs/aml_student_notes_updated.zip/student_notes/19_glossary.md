# Chapter 19 — Glossary

Every term in the project, in one place. Chapter references point to where each is explained properly.

---

## Machine learning and language models

**Adapter** — The small set of trained weights produced by LoRA, separate from the frozen base model. Yours is tens of megabytes against the base model's 3 GB. (Ch. 9)

**Attention** — The mechanism by which each token weighs every earlier token when forming its representation. Queries, keys and values. (Ch. 8)

**Base model** — A model trained to continue text, with no instruction tuning. Here, also used to mean "the untuned Qwen", system B. (Ch. 8)

**Batch size** — How many examples are processed together. Yours: 4 per device, 16 effective after accumulation. (Ch. 9)

**bitsandbytes** — The library providing 4-bit quantisation (`BitsAndBytesConfig`). (Ch. 9)

**Catastrophic forgetting** — When training on a narrow task degrades general ability. Reduced by PEFT, because the base weights are frozen. (Ch. 9)

**Chat template** — The model-specific markers for system, user and assistant turns. Qwen uses ChatML. Applied via `tokenizer.apply_chat_template`. (Ch. 8)

**Checkpoint** — A saved snapshot during training, so a disconnect loses little. Saved every 100 steps to Google Drive. (Ch. 10)

**Cross-entropy loss** — How surprised the model was by the correct next token. The training objective. (Ch. 8)

**Decoding** — Turning the model's probabilities into tokens. **Greedy** always takes the most likely; **sampling** draws from the distribution. This project uses greedy (`do_sample=False`). (Ch. 8, 11)

**Double quantisation** — Quantising the quantisation constants as well as the weights. Saves roughly half a bit per parameter. (Ch. 9)

**Effective batch size** — Per-device batch × gradient accumulation steps. Yours: 4 × 4 = 16. (Ch. 9)

**Epoch** — One pass over the training set. Yours: 2. (Ch. 9)

**Fine-tuning** — Continuing training on a task-specific dataset. (Ch. 8)

**fp16 / bf16** — 16-bit float formats. A T4 supports fp16 but not bf16, which is why `fp16=True`. (Ch. 9)

**Gradient accumulation** — Summing gradients over several small batches before one update, to get a large effective batch within a small memory budget. (Ch. 9)

**Gradient checkpointing** — Recomputing activations during the backward pass instead of storing them, trading compute for memory. Enabled by `prepare_model_for_kbit_training`. (Ch. 9)

**Hallucination** — Output not grounded in the input. Here, specifically, a number in the reason that is not in the summary. (Ch. 11)

**IGNORE_INDEX (−100)** — The label value PyTorch's cross-entropy ignores. Used to mask prompt tokens so loss is computed on the answer only. (Ch. 10)

**Instruction tuning** — Training a base model on instruction–response pairs so it answers rather than continues. Qwen2.5-1.5B-**Instruct** has had it. (Ch. 8)

**KV cache** — Stored keys and values from previous positions so generation does not recompute them. (Ch. 8)

**Learning rate** — Step size for weight updates. Yours: 2e-4, roughly ten times a typical full fine-tuning rate, because LoRA adapters start from scratch. (Ch. 9, 10)

**LoRA** — Low-Rank Adaptation. Freeze W, learn `W + (α/r)·BA` with thin matrices A and B. (Ch. 9)

**Loss masking** — Setting labels to −100 so those positions contribute no loss. See answer-only loss masking. (Ch. 10)

**NF4** — 4-bit NormalFloat. Quantisation levels placed at the quantiles of a normal distribution rather than evenly. (Ch. 9)

**PEFT** — Parameter-Efficient Fine-Tuning. Both the family of methods and Hugging Face's library. (Ch. 9)

**Quantisation** — Storing weights at lower precision. 4-bit here, with fp16 compute. (Ch. 9)

**QLoRA** — 4-bit quantised frozen base + LoRA adapters in fp16. (Ch. 9)

**Rank (r)** — The inner dimension of the LoRA matrices; how expressive the update can be. Yours: 16. (Ch. 9)

**Alpha (α)** — LoRA scaling; the update is multiplied by α/r. Yours: 32, giving a scale of 2. (Ch. 9)

**Step** — One optimiser update. Yours: 300 (150 per epoch × 2). (Ch. 9)

**Token** — A subword unit from the model's vocabulary. Roughly four characters of English. (Ch. 8)

**Warmup** — Ramping the learning rate up over the first steps. Yours: 15 steps, 5% of 300. (Ch. 9, 10)

---

## Evaluation

**Baseline** — A simpler system your model must beat to justify itself. Here, threshold rules — which won on held-out. (Ch. 7, 12)

**Confusion** — Mistaking one class for another. The project's hardest confusion is `salary_then_commitments` against rapid pass-through. (Ch. 12)

**F1** — Harmonic mean of precision and recall. Punishes imbalance between them. (Ch. 7)

**Faithfulness** — Here: the share of answers whose reason contains only numbers present in the summary. 99.7% on held-out. (Ch. 11)

**False positive / false negative** — Flagging an innocent alert / missing a real one. (Ch. 7, 17)

**Hard negative** — A legitimate case that resembles a suspicious one. Four kinds here. (Ch. 4)

**Held-out set** — Data reserved for a single final score, built to be harder. 300 alerts, new wording, new names, incomes × 1.6. (Ch. 6, 12)

**Leakage** — Information from evaluation data reaching training. Prevented by splitting by customer and reserving templates. (Ch. 12)

**Macro-F1** — F1 per class, averaged with equal weight, so rare classes count as much as common ones. The project's headline metric. (Ch. 7)

**Micro-F1** — Pooled across all predictions, so frequent classes dominate. Not used here, deliberately. (Ch. 7)

**Overfitting** — Learning the training data rather than the pattern. Signalled by validation loss rising while training loss falls. (Ch. 8)

**Precision** — Of what I flagged as X, how much really was X. (Ch. 7)

**Recall** — Of everything that really was X, how much did I catch. (Ch. 7)

**Split** — A partition of the data: train 2,400, validation 300, test 400, held-out 300. (Ch. 4)

**Validity rate** — The share of model answers that passed every check. 100% test, 99.7% held-out. (Ch. 11)

---

## Project-specific

**Alert** — One customer's 30-day window with a planted pattern. The unit of everything. 3,400 in total.

**Alert id** — `A-<split>-<number>`, for example `A-test-0308`. The customer is `C-test-0308`. One alert per customer. (Ch. 2)

**Case** — The workflow's state for one alert: steps, note, decision. Stored as JSON in `audit/cases/`. (Ch. 13)

**Case memory** — That per-alert state persisting between sessions. **Not** cross-alert customer history, which does not exist here. (Ch. 13)

**Case note** — The Markdown summary written by Python from computed findings. No model writes it. (Ch. 13)

**Dispatch table** — A dict mapping a key to a function, called instead of an `if/elif` chain. (Ch. 4, 18)

**Feature** — One computed number about an alert. About thirty per alert. (Ch. 5)

**Hard negative kind** — Which look-alike an alert is: `cash_heavy_shop`, `house_sale`, `salary_then_commitments`, `repay_friend`, or `None`. (Ch. 4)

**Ledger** — The object collecting one alert's transactions and numbering them in date order. (Ch. 4)

**Output checker** — `schema.check_answer`: valid JSON, known labels, reason ≤ 200 characters, no banned words, no invented numbers. (Ch. 11)

**Rule id** — `R1` to `R4`, or `R0` for no concern. Travels with the rules' verdict so an analyst sees which rule fired. (Ch. 7)

**Summary** — The English text rendered from the features. The only thing the model reads. (Ch. 6)

**Template** — One of five wordings for the summary. Three shared, two reserved for held-out. (Ch. 6)

**Template group** — `shared` or `heldout`; decides which templates an alert may use. (Ch. 6)

**Typology** — A laundering pattern: `STRUCTURING`, `RAPID_PASS_THROUGH`, `MULE_ACCOUNT`, `ROUND_TRIPPING`, plus `NO_CONCERN`. (Ch. 17)

**System A / B / C / D** — Rules (A1 default, A2 tuned), base model, fine-tuned model, prompted Claude (never run). (Ch. 12)

---

## AML and compliance

**CDD / EDD** — Customer Due Diligence and its enhanced form. (Ch. 17)

**FATF** — The Financial Action Task Force, international standard-setter. (Ch. 17)

**FIU** — Financial Intelligence Unit; India's is FIU-IND, under the PMLA. (Ch. 17)

**KYC** — Know Your Customer. (Ch. 17)

**Layering** — The second laundering stage: obscuring origin through transactions. (Ch. 17)

**Mule account** — An account used to receive and forward others' money. (Ch. 17)

**Placement** — The first stage: getting cash into the system. (Ch. 17)

**Round-tripping** — Money leaving and returning through other parties. (Ch. 17)

**Structuring (smurfing)** — Splitting cash into deposits below a reporting threshold. (Ch. 17)

**STR / SAR** — Suspicious Transaction / Activity Report. (Ch. 17)

**Tipping off** — Telling a customer they are under suspicion; an offence in most regimes, and the reason for the banned-words rule. (Ch. 17)

**Transaction monitoring** — The rules or models that raise alerts in the first place. This project consumes their output. (Ch. 17)

---

## Engineering

**Append-only** — A log that is only ever added to. Guaranteed here by the absence of update and delete functions. (Ch. 13)

**Collator** — The function turning a list of examples into a padded batch. (Ch. 10)

**Dependency injection** — Passing a dependency (a path, a function) as a parameter rather than hard-coding it. Why the tests need no mocking. (Ch. 13, 15)

**Determinism** — Same input, same output. Achieved with a per-alert seed, sorted JSON keys and greedy decoding. (Ch. 4)

**Fixture** — Reusable pytest setup, requested by parameter name. (Ch. 15)

**Guardrail** — A rule in code that blocks a bad outcome: banned words, number grounding, export blocking, mandatory override notes. (Ch. 11, 13)

**Human in the loop** — A person decides; the system never acts alone. (Ch. 17)

**JSONL** — One JSON object per line. Appendable, streamable, damage-local. (Ch. 2)

**Left padding** — Padding before the prompt, required for batched generation so every sequence ends at its real last token. (Ch. 11)

**Smoke test** — A tiny run proving the path works before a long one. `--limit 64 --epochs 1`, about two minutes. (Ch. 10)

**Stable sort** — Equal keys keep their order; what makes the two-pass queue sort work. (Ch. 14, 18)

---

## The numbers worth memorising

| | |
| --- | --- |
| Base model | Qwen2.5-1.5B-Instruct |
| LoRA | rank 16, alpha 32, dropout 0.05, all linear layers |
| Quantisation | 4-bit NF4, double quant, fp16 compute |
| Trainable | 18,464,768 params — 1.18% |
| Training | lr 2e-4, 2 epochs, 300 steps, 15 warmup, cosine |
| Batch | 4 × 4 accumulation = 16 effective |
| Time | 36 minutes, free Colab T4 |
| Data | 3,400 customers, 102,112 transactions |
| Splits | 2,400 / 300 / 400 / 300 |
| Macro-F1 test | 1.000 model, 0.990 tuned rules, 0.135 base |
| Macro-F1 held-out | 0.936 model, 0.990 tuned rules, 0.181 base |
| Valid JSON | 100% test, 99.7% held-out |
| Risk accuracy | 99.8% test, 99.7% held-out |
| Weakest held-out class | MULE_ACCOUNT, F1 0.83 |
| Worst false alarm | salary_then_commitments, 53.3% |
| Tests | 143, under 5 seconds |
