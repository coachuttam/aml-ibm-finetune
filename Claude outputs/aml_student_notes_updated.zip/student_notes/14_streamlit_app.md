# Chapter 14 — The review app (`app.py`, `review.py`, `review_scores.py`)

296 lines of Streamlit, plus two modules that prepare its data and import no UI library at all.

---

## 14.1 The separation that makes this work

```
review.py          joins alerts + rules + saved model answers   → no Streamlit
review_scores.py   builds the evaluation table                  → no Streamlit
app.py             draws it                                     → all the Streamlit
```

Check the imports at the top of `review.py`: `json`, `os`, `dataclasses`, `pathlib`, `typing`, and six project modules. No `streamlit`.

That is why `tests/test_review.py` can run ten tests against the app's data layer in a fraction of a second, with no browser. UI code is awkward to test; data preparation is not. Keeping them apart means the hard logic lives in the testable half.

---

## 14.2 `review.py` — one object per alert

```python
@dataclass(frozen=True)
class ReviewAlert:
    """Everything the screen shows about one alert."""
    alert_id: str
    split: str
    customer_id: str
    summary: str
    features: dict
    true_typology: str
    true_risk: str
    look_alike_kind: Optional[str]
    model_typology: str          # NEEDS_REVIEW when the answer was not valid
    model_risk: str
    model_reason: str
    model_problems: List[str]
    rules_default: str
    rules_tuned: str
    rules_tuned_rule_id: str
    base_typology: str
    window_end: str
```

One flat object holding **five opinions** about the same alert: the fine-tuned model, the tuned rules, the default rules, the base model, and the truth. That is the comparison table on screen, and it is assembled here rather than in the UI.

### The join

```python
def build_review_alert(example: dict, tuned_config, fine_tuned: Optional[dict],
                       base: Optional[dict], window_end: str) -> ReviewAlert:
    """Join one dataset example with the rules' labels and the saved model answers."""
    default_label, _ = classify(example["features"], DEFAULT_CONFIG)
    tuned_label, tuned_rule = classify(example["features"], tuned_config)
    usable = bool(fine_tuned and fine_tuned.get("valid"))
    return ReviewAlert(
        ...
        model_typology=fine_tuned["typology"] if usable else NEEDS_REVIEW,
        model_risk=fine_tuned["risk"] if usable else "unknown",
        model_reason=(fine_tuned.get("reason") or "") if usable else "",
        model_problems=list(fine_tuned["problems"]) if fine_tuned else ["no saved answer"],
        ...
    )
```

The rules are computed **live** — `classify` runs on the stored features every time the app loads. The model answers are **read from files**. Three sources, one object.

`usable = bool(fine_tuned and fine_tuned.get("valid"))` handles three cases in one line: no saved answer at all, a saved answer marked invalid, and a good answer. The first two both become `NEEDS_REVIEW` with risk `unknown`, which is how an invalid answer reaches the screen as a warning rather than a verdict.

### The queue order

```python
RISK_ORDER = {"high": 0, "medium": 1, "low": 2, "unknown": 3}

def sort_for_queue(alerts: List[ReviewAlert]) -> List[ReviewAlert]:
    """Highest risk first, then the most recent window first."""
    by_date = sorted(alerts, key=lambda alert: alert.window_end, reverse=True)
    return sorted(by_date, key=lambda alert: RISK_ORDER.get(alert.model_risk, 3))
```

Two sorts, not one compound key. This relies on Python's sort being **stable**: equal keys keep their existing relative order. So sorting by date first, then by risk, gives risk-major, date-minor ordering.

The single-sort equivalent would be `key=lambda a: (RISK_ORDER[a.model_risk], ...)` — but the date needs reversing while risk does not, and you cannot negate a string. Two stable sorts is the clean way to mix directions.

`RISK_ORDER.get(alert.model_risk, 3)` defaults unknown risks to last, so a `NEEDS_REVIEW` alert sinks to the bottom of the queue rather than disappearing.

### Marking evidence

```python
def supports_verdict(transaction: dict, typology: str) -> bool:
    """True for rows we can point to as evidence for structuring or pass-through verdicts.

    Mule and round-trip evidence needs several rows together, so those rows are not marked.
    """
    if transaction["direction"] != "credit":
        return False
    if typology == "STRUCTURING":
        just_under = CASH_REPORTING_LIMIT * JUST_UNDER_LOW <= transaction["amount"] <= CASH_REPORTING_LIMIT * JUST_UNDER_HIGH
        return transaction["channel"] == "cash" and just_under
    if typology == "RAPID_PASS_THROUGH":
        return transaction["amount"] >= LARGE_AMOUNT
    return False
```

This is what used to put the ● in the evidence table, and it marked only two typologies, because only those have **single rows** that constitute evidence. A mule pattern is "many senders in a week" — no individual row is evidence of it, and marking one would have been misleading. The UI said so explicitly, and admitting what an interface cannot show is a sign of a careful product.

**This function was deleted on 13 November 2026.** `src/evidence.py` now maps every computed finding to the rows it was computed from, covering all four typologies, so the limitation it was being honest about no longer exists. The ● comes from `evidence.cited_ids` instead, and the caption now reads "● marks rows that a computed finding above points at." Chapter 22 explains the replacement. The reasoning above is still worth knowing: it is why the old marks were narrow, and why the new ones had to be derived from the findings rather than from the verdict.

### The agreement line

```python
def agreement_label(alert: ReviewAlert) -> str:
    """One plain line on whether the model and the tuned rules agree."""
    if alert.model_typology == NEEDS_REVIEW:
        return "Model answer could not be validated: review by hand."
    if alert.model_typology == alert.rules_tuned:
        return "The model and the tuned rules agree."
    return "The model and the tuned rules disagree: look closely."
```

A second opinion, surfaced as a sentence. Disagreement between two independent systems is where an analyst's attention is worth most, and the app shows it on every alert and as an "Agree" column in the queue.

This is a genuinely good product idea and it is cheap: you already have both systems.

### Shared-demo detection

```python
STREAMLIT_CLOUD_FOLDER = Path("/mount/src")       # where Streamlit Community Cloud puts the repo

def is_shared_demo(environment=None, cloud_folder: Path = STREAMLIT_CLOUD_FOLDER) -> bool:
    """True when the app runs on a public host (a Hugging Face Space or Streamlit Community Cloud)."""
    environment = os.environ if environment is None else environment
    return bool(environment.get("SPACE_ID")) or cloud_folder.exists()
```

Two signals: the `SPACE_ID` variable that Hugging Face sets, or the existence of the folder Streamlit Cloud clones into. Either means "this is public".

The app then shows:

> Shared demo: saved decisions are visible to other visitors and reset when the app restarts. Please do not type personal information.

Both parameters have defaults, so the function is testable:

```python
def test_a_public_host_is_recognised_so_the_shared_demo_notice_can_show(tmp_path):
    assert is_shared_demo({"SPACE_ID": "someone/space"}, tmp_path / "missing")
    assert is_shared_demo({}, tmp_path)                       # the cloud folder exists
    assert not is_shared_demo({}, tmp_path / "missing")       # a laptop
```

Injecting the environment dictionary rather than reading `os.environ` directly is the same dependency-injection idea as Chapter 13, applied to configuration.

---

## 14.3 `review_scores.py` — one source of truth for the numbers

```python
"""The numbers for the Evaluation tab: one row per system, test and held-out side by side.

It reuses the scoring code in evaluate.py, so the screen can never disagree with
the README table.
"""
from src.evaluate import (evaluate_predictions, load_predictions, model_extras, typology_of)
```

The docstring states the principle: the app imports the same scoring functions as the command-line report. There is no second implementation of macro-F1.

This matters more than it sounds. A dashboard that computes its own version of a metric will eventually disagree with the report, and nobody will know which is right. Importing the same functions makes that impossible.

```python
def model_scores(file_prefix: str, examples_by_split) -> dict:
    scores = {}
    for split, examples in examples_by_split.items():
        path = RESULTS_FOLDER / f"{file_prefix}_{split}.jsonl"
        if not path.exists():
            continue
        ...
```

Missing files are skipped, so the app works before any model has been run — it simply shows fewer rows.

---

## 14.4 `app.py` — the UI

### Caching

```python
@st.cache_data(show_spinner="Loading alerts...")
def get_alerts(split: str) -> List[ReviewAlert]:
    return load_review_alerts(split, get_tuned_config())

@st.cache_data(show_spinner="Tuning the rules on the training set (about 5 seconds)...")
def get_tuned_config():
    return tuned_rules_config()
```

**Streamlit re-runs the entire script on every interaction.** Click a button, move a slider, pick from a dropdown — `app.py` executes from the top again. This is the single most important thing to understand about Streamlit, and it surprises everyone.

Without caching, every click would re-run the 1,920-configuration grid search. `@st.cache_data` stores the return value keyed by the function's arguments; subsequent calls with the same arguments return the stored value instantly.

`show_spinner="..."` sets the message shown during the first, slow call. Telling the user *why* they are waiting ("Tuning the rules on the training set (about 5 seconds)") is better interface design than a bare spinner.

Four cached functions: alerts, tuned config, transactions, scores. These are exactly the four expensive operations.

### Compatibility shim

```python
def show_table(table: pd.DataFrame, **options) -> None:
    """A full-width table. Newer Streamlit says width="stretch"; older versions say use_container_width."""
    try:
        st.dataframe(table, width="stretch", hide_index=True, **options)
    except (TypeError, ValueError):
        st.dataframe(table, use_container_width=True, hide_index=True, **options)
```

Streamlit deprecated `use_container_width` in favour of `width="stretch"`. The laptop and the deployment host could have different versions. Rather than pinning one and breaking the other, this tries the new API and falls back.

`**options` passes extra keyword arguments through, so `show_table(df, height=320)` works.

Writing a four-line shim instead of a version pin is a pragmatic choice. The alternative view is that pinning is cleaner and this hides a real dependency problem — both are defensible, and having the opinion is what matters.

### Layout

```python
def main() -> None:
    st.title("AML Alert Investigator")
    st.caption(SYNTHETIC_NOTE)
    if is_shared_demo():
        st.info("Shared demo: saved decisions are visible to other visitors ...")
    split = st.sidebar.selectbox("Alerts", list(SPLIT_CHOICES), index=1, format_func=SPLIT_CHOICES.get)
    alerts = pick_filters(get_alerts(split))
    st.sidebar.caption(SYNTHETIC_NOTE)
    event_count = len(read_events())
    queue_tab, detail_tab, live_tab, evaluation_tab, audit_tab = st.tabs(
        [f"Alerts ({len(alerts)})", "Alert detail", "Live run", "Evaluation", f"Audit log ({event_count})"])
    with queue_tab:
        show_queue(alerts)
    with detail_tab:
        show_detail(alerts, split)
    with live_tab:
        show_upload(get_tuned_config(), show_alert)
    with evaluation_tab:
        show_evaluation()
    with audit_tab:
        show_audit_log()

main()
```

Four tabs, each a function. `index=1` defaults the split selector to `test` rather than `validation`.

`format_func=SPLIT_CHOICES.get` displays `"held-out (run once)"` while the underlying value stays `"heldout"` — the label reminds the viewer of the protocol without changing the code's vocabulary.

Tab titles carry counts: `Alerts (400)`, `Audit log (10)`. Live numbers in navigation, which is a small thing that makes an interface feel real.

**`main()` is called at module level**, with no `if __name__ == "__main__"` guard, because `streamlit run app.py` executes the file as a script.

### The detail view

```python
def show_detail(alerts: List[ReviewAlert], split: str) -> None:
    if not alerts:
        st.info("No alerts match the filters.")
        return
    chosen_id = st.selectbox("Alert", [alert.alert_id for alert in alerts])
    alert = next(a for a in alerts if a.alert_id == chosen_id)
    transactions = get_transactions(split).get(alert.alert_id, [])
    show_header(alert, len(transactions))
    left, right = st.columns([3, 2])
    with left:
        st.markdown("**What the model read**")
        st.text(alert.summary)
        show_evidence(alert, transactions)
    with right:
        show_verdict(alert)
        show_comparison(alert)
    show_investigation(alert, transactions)
```

`st.columns([3, 2])` splits the width in a 3:2 ratio. Evidence on the left because it is wide; verdict and comparison on the right.

**"What the model read"** displays the exact summary text. Showing the model's actual input is a transparency decision most dashboards skip — and it is what lets a viewer check the faithfulness claim themselves, by comparing the numbers in the reason against the numbers in the summary.

`next(a for a in alerts if a.alert_id == chosen_id)` takes the first match from a generator — the idiomatic "find one" in Python.

### The decision panel

```python
def show_decision_panel(alert: ReviewAlert, case: Case) -> None:
    st.markdown("**Step 6: analyst decision**")
    st.caption(f"Model said: {words_for(alert.model_typology)}, risk {alert.model_risk}. "
               "The original alert and verdict are never changed; your decision is saved beside them.")
    if case.decision:
        d = case.decision
        st.success(f"Latest decision: {d['action']}, {words_for(d['typology'])}, risk {d['risk']} ({d['time']}).")
    action = st.radio("Decision", ["Approve", "Override"], horizontal=True, key=f"action_{alert.alert_id}")
    typology, risk = alert.model_typology, alert.model_risk
    if action == "Override" or alert.model_typology == NEEDS_REVIEW:
        start_typology = ALL_LABELS.index(alert.model_typology) if alert.model_typology in ALL_LABELS else 0
        start_risk = RISK_LEVELS.index(alert.model_risk) if alert.model_risk in RISK_LEVELS else 0
        typology = st.selectbox("Typology", list(ALL_LABELS), index=start_typology, format_func=words_for, ...)
        risk = st.selectbox("Risk", list(RISK_LEVELS), index=start_risk, ...)
    note = st.text_input("Note (required for an override)", ...)
    if st.button("Save decision", ...):
        try:
            record_decision(alert, case, action.lower(), typology, risk, note)
            st.rerun()
        except DecisionError as problem:
            st.error(str(problem))
```

Three details worth noticing.

**The dropdowns only appear for an override.** Approving means accepting the model's verdict, so there is nothing to pick. This makes the default path one click and the disagreement path deliberate — the interface encodes the policy.

**They are pre-filled with the model's answer.** `index=start_typology` starts the dropdown at what the model said, so an analyst changing only the risk level does not have to re-enter the typology. A small kindness that reduces errors.

**`key=f"action_{alert.alert_id}"`** — Streamlit identifies widgets by key. Without a unique key per alert, switching alerts would carry the previous alert's radio selection across, because Streamlit would think it was the same widget. Including the alert id is the fix, and forgetting it is one of the most common Streamlit bugs.

`st.rerun()` after a successful decision forces an immediate re-run so the saved state appears. `DecisionError` is caught and shown with `st.error` — the guardrail's message, written for a human, is displayed verbatim.

### The evaluation tab

```python
def show_evaluation() -> None:
    scores = get_scores()
    tuned, finetuned = scores["A2 rules (tuned on train)"], scores["C fine-tuned"]
    columns = st.columns(3)
    with columns[0]:
        kpi_card("Macro-F1, fine-tuned",
                 f"{finetuned['test']['macro_f1']:.3f} / {finetuned['heldout']['macro_f1']:.3f}",
                 f"test / held-out. Tuned rules: {tuned['test']['macro_f1']:.3f} / {tuned['heldout']['macro_f1']:.3f}")
    ...
    st.caption("On held-out wording the fine-tuned model did not beat the tuned rules. "
               "That result is reported as it is; the held-out set was scored once.")
```

The first KPI card shows the model's score **and the rules' score underneath it**. The comparison is unavoidable; you cannot read the headline without reading what beat it.

The caption at the bottom states the loss in plain words, on the live demo, for anyone to see.

A dashboard that volunteers its own bad news is unusual. It is also the single most persuasive thing on the screen, and it is worth saying so when demonstrating: *"That line is there on purpose."*

---

## 14.5 Exercises

1. Add a `st.write(1)` at the top of `app.py`, run it, and click a tab. What does the re-run model mean for where you may put side effects?
2. Remove `@st.cache_data` from `get_tuned_config` and interact with the app. Time the difference.
3. Why two sorts in `sort_for_queue` instead of one compound key? Write the single-key version and explain why it is awkward.
4. Remove the `key=` arguments from the decision widgets, switch between alerts, and describe the bug.
5. `supports_verdict` marks nothing for mule accounts. Design an honest way to show mule evidence in the table.
6. The Evaluation tab shows the rules' score next to the model's. Argue for and against that choice from a product perspective.
