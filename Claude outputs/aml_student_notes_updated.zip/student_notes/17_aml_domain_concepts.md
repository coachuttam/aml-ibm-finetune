# Chapter 17 — AML and financial crime concepts

The domain background behind the code. You will be talking to people who do this for a living, so the vocabulary matters more than the depth.

**A caution before you quote anything.** Regulatory thresholds and statistics differ by country and change over time. Verify any specific figure against a current primary source before stating it in an interview. Where this chapter gives a number, it is marked as needing checking.

---

## 17.1 What money laundering is

Turning money from crime into money that appears legitimate. The textbook model has three stages:

| Stage | What happens | Example |
| --- | --- | --- |
| **Placement** | Dirty cash enters the financial system | Depositing cash at a bank |
| **Layering** | Transactions obscure the origin | Moving it through several accounts and businesses |
| **Integration** | It re-emerges as apparently clean wealth | Buying property, paying a "salary" |

Your four typologies sit in the first two stages. Structuring is placement. Rapid pass-through, mule accounts and round-tripping are layering.

Saying which stage a typology belongs to is a cheap way to show you understand the domain rather than only the dataset.

---

## 17.2 The four typologies in the project

### Structuring

Splitting cash into deposits below a reporting threshold so no single deposit triggers a report. Also called smurfing.

In the code: 6–14 cash deposits between 80% and 99% of ₹50,000, within 3–8 days, often followed by a transfer out.

What makes it detectable: the deposits cluster just below a round number, and the pattern repeats. A legitimate cash business deposits varied amounts spread across the month — which is exactly the `cash_heavy_shop` hard negative.

**On the ₹50,000 figure.** The code is explicit that this is illustrative:

```python
# Illustrative per-deposit limit for this demo. Not a regulatory figure.
CASH_REPORTING_LIMIT = 50_000
```

India has several thresholds that are sometimes confused: a requirement to quote a PAN for cash deposits at or above a certain amount, and a separate cash transaction reporting threshold that is much higher. **Check both before quoting either.** If asked why ₹50,000, the safe answer is: *"It stands in for a reporting threshold in a synthetic dataset. Real thresholds differ by jurisdiction and are configurable — the constant is named and has one comment explaining it."*

### Rapid pass-through

Money arrives and leaves almost immediately. The account is a conduit, not a destination.

In the code: 2–4 credits of ₹1.5–6 lakh, with 90–99% sent out within one or two days.

The innocent look-alikes are the interesting part: a salaried person paying rent, EMI and a SIP within two days of payday looks identical on a velocity measure. That is the `salary_then_commitments` hard negative, and it was the hardest case for both the rules (80% false alarms before tuning) and the model (53.3% on held-out).

What actually separates them, and what a real system would use: **who the money goes to.** Regular, named, recurring payees versus new counterparties. This project does not use payee history as a feature, and that is a fair answer to "how would you improve the model?"

### Mule account

Someone lets their account be used to receive and forward other people's money — sometimes knowingly, often recruited through a fake job advert.

In the code: 10–25 different senders paying small amounts over 2–5 days, then 90–98% withdrawn or transferred out.

Three signals combine: many unrelated senders, speed of exit, and a young account. The generator makes mules 1–6 months old against 12–120 for everyone else, mirroring the real pattern of freshly opened accounts.

This is the class the model struggled with most on held-out data (F1 0.83). The signal is a **conjunction**, and conjunctions are harder to recognise through unfamiliar wording than a single distinctive count.

### Round-tripping

Money leaves and comes back through other parties, creating a paper trail that makes it look like business revenue.

In the code: 2–3 payments of ₹1–4 lakh out to a business, returning at 95–100% from a *different* business within 3–6 days.

The innocent look-alike is `repay_friend` — money lent and returned in full. The distinguishing feature is **who returned it**, captured by `return_same_party`. Same person returning your loan is innocent; a different party returning nearly the same amount is layering.

---

## 17.3 The compliance vocabulary

Learn these well enough to use them without hesitating.

| Term | Meaning |
| --- | --- |
| **KYC** | Know Your Customer — verifying identity at onboarding |
| **CDD / EDD** | Customer Due Diligence, and the Enhanced version for higher-risk customers |
| **Transaction monitoring** | Rules or models running over transactions to raise alerts |
| **Alert** | A flagged pattern needing human review — the input to this project |
| **Disposition** | What the analyst decided: closed, escalated, or reported |
| **STR / SAR** | Suspicious Transaction Report / Suspicious Activity Report, filed when suspicion survives review |
| **FIU** | Financial Intelligence Unit — the national body that receives such reports. India's is FIU-IND; reports are filed under the Prevention of Money Laundering Act |
| **FATF** | The Financial Action Task Force, the international standard-setter most national regimes follow |
| **Typology** | A named laundering pattern |
| **Tipping off** | Telling a customer they are under suspicion — an offence in most regimes |
| **False positive** | An alert that turns out to be innocent |
| **Model risk management** | Independent validation, documentation and monitoring of models used in decisions |

**Tipping off is the one to understand**, because it explains the project's language rules. If a system said "fraud detected" in a note that a customer could later see through a subject access request, that is a serious problem. The project's answer:

```python
BANNED_WORDS = ("fraud", "criminal", "guilty")   # we refer for review, we never accuse
```

and

```python
return "Refer for review by a senior analyst before any action. Nothing has been filed or sent."
```

Being able to connect a constant in the code to a legal concept is exactly the kind of thing that distinguishes someone who read about the domain from someone who only built a classifier.

---

## 17.4 Why false positives dominate the problem

The widely repeated claim is that the great majority of AML alerts are false positives, often quoted above 90%. **Find a source you trust before using a number**, but the direction is not disputed: rule-based transaction monitoring generates far more alerts than are genuinely suspicious, and analyst time is the bottleneck.

That is what makes this project's framing right. From the PRD:

> Banks generate large numbers of anti-money-laundering (AML) alerts. Most are false positives, and analysts spend hours reading transaction summaries to decide which few deserve a closer look.

And it is why the false-positive rate is measured **per hard-negative kind** rather than as one number:

| Kind | A1 rules, test | C fine-tuned, held-out |
| --- | --- | --- |
| cash_heavy_shop | 0.0% | 0.0% |
| house_sale | 0.0% | 0.0% |
| repay_friend | 6.7% | 13.3% |
| salary_then_commitments | 80.0% | 53.3% |

A single "8% false alarms" figure would hide the fact that almost all the errors come from one confusable pattern. Breaking it down turns a score into something actionable: fix the salary case and the metric moves.

In a real bank, the two errors cost very different things. A false positive wastes an analyst's hour. A false negative lets laundering through and may bring a regulatory penalty. A production system would weight them explicitly; this project reports both separately, which keeps the trade-off visible.

---

## 17.5 Why "human in the loop" is not optional here

In most machine-learning products, automation is the goal. In AML it is not, for three reasons:

**Legal.** A decision to report a customer has consequences and needs an accountable person behind it.

**Regulatory.** Models used in regulated decisions fall under model risk management: independent validation before deployment, ongoing monitoring, documented limitations, and the ability to explain any individual output.

**Practical.** No model is good enough. An 8% false-alarm rate on synthetic data would be unusable without review.

The project encodes this in code rather than in prose:

- Exports blocked until a decision (`ExportBlockedError`)
- Overrides require a written note
- The model's verdict is never altered — the decision is an overlay
- Every step and decision appended to a log that has no update or delete

**The design rule to quote:** *"The AI labels and explains, Python counts, a person decides."*

---

## 17.6 What an auditor or validator would ask

Useful to have ready, because it turns a demo into a conversation about production.

| Question | What this project has | What is missing |
| --- | --- | --- |
| Who decided, and can you prove it? | Append-only log with before/after and the analyst's note | No user identity; no tamper-evidence (hash chain) |
| Which model version produced this? | Adapter published and versioned on Hugging Face | Not recorded per verdict |
| Can you reproduce an output? | Deterministic data, greedy decoding, fixed prompt | Library versions not pinned; no seed recorded |
| How was it validated before use? | Four-system benchmark, held-out scored once, model card states limits | No independent validation; synthetic data only |
| How do you monitor it? | Override rate recordable from the audit log | No monitoring implemented |
| Does it perform equally across customer segments? | — | **Not tested at all** |

That last row is a real gap and the honest answer is to say so: *"I have not tested for performance differences across occupation or income groups. Occupation is correlated with typology by design in the generator, so I would expect differences and I would measure them before anyone relied on it."*

Volunteering a fairness gap before being asked is a strong move. Inventing an answer for it is a weak one.

---

## 17.7 What this project is not

Say all of these plainly:

- **Not a compliance tool.** It is a prototype on synthetic data, not certified for any regulator's requirements.
- **Not tested on real data.** No real transaction has ever been through it.
- **Not a detector.** It triages alerts that something else raised; it does not monitor transactions.
- **Not autonomous.** Nothing is filed, frozen or sent without a person.
- **Not using real thresholds.** They are illustrative and configurable.

The README, the model card, the dataset card, the case note footer and the app header all carry some version of this. That consistency is deliberate and is worth pointing at.

---

## 17.8 Exercises

1. Place each of the four typologies in the placement / layering / integration model, and justify the borderline one.
2. `salary_then_commitments` and rapid pass-through look identical on velocity. Name three features that would separate them, none of which this project uses.
3. Explain tipping off, then point to the exact lines of code shaped by it.
4. Write the three-sentence answer to "what would a model validator want from this system?"
5. Look up India's PAN-quoting threshold for cash deposits and the cash transaction reporting threshold. Which is closer to ₹50,000?
6. Design a fifth typology — trade-based laundering, say — and specify the generator pattern, the feature, the rule and the hard negative you would need.
