# Chapter 10 — The prompt and the training code

`prompt.py` (32 lines) and `finetune.py` (133 lines), line by line.

---

## 10.1 `src/prompt.py` — small, and load-bearing

```python
"""The prompt the model sees. Training and inference both use this file,
so the wording can never drift apart.
"""
from src.schema import ALL_LABELS, RISK_LEVELS

SYSTEM_PROMPT = (
    "You are an anti-money-laundering assistant. Read the alert summary and reply "
    "with JSON only, in this form: "
    '{"typology": ..., "risk": ..., "reason": ...}. '
    f"typology is one of: {', '.join(ALL_LABELS)}. "
    f"risk is one of: {', '.join(RISK_LEVELS)}. "
    "reason is one short sentence that uses only numbers found in the summary."
)


def build_messages(summary: str) -> List[Dict[str, str]]:
    """The conversation up to the point where the model should answer."""
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": summary},
    ]


def answer_text(label: Dict[str, str]) -> str:
    """The exact answer the model is trained to produce."""
    ordered = {key: label[key] for key in ("typology", "risk", "reason")}
    return json.dumps(ordered, ensure_ascii=False)
```

### Why this file exists at all

The docstring says it: *"Training and inference both use this file, so the wording can never drift apart."*

This is the single most common silent failure in fine-tuning. You train with one prompt, deploy with a slightly different one — an extra sentence, a reordered instruction, a different label list — and quality drops for no visible reason. There is no error; the model simply sees something it was never trained on.

Putting the prompt in one module that both `finetune.py` and `predict.py` import makes the bug impossible. It is 32 lines of insurance.

### The label lists are built from the constants

```python
f"typology is one of: {', '.join(ALL_LABELS)}. "
```

Not typed out by hand. If a sixth typology were added to `schema.py`, the prompt would update itself. Hard-coding the list would create a second place to forget.

### Why the prompt is short

Five instructions: who you are, reply with JSON only, the shape, the allowed values, the constraint on the reason. No examples, no explanation of what structuring means, no chain-of-thought.

That is correct for a **fine-tuned** model. The knowledge is in the weights; the prompt only needs to establish the output contract. Long prompts cost tokens on every call and, after fine-tuning, add nothing.

It is also why the base-model comparison is fair in one direction and not the other, and the README says so:

> The base model was told only the label names, with no definitions or examples, so it shows what training added, not what the best prompt could do.

That is a genuinely important caveat and you should offer it before anyone asks. System B measures *what fine-tuning contributed over a minimal prompt*, not *fine-tuning versus the best possible prompt*. A carefully engineered few-shot prompt would score far above 0.135. The missing system D — prompted Claude — was meant to answer that and was never run.

### `answer_text` and key order

```python
ordered = {key: label[key] for key in ("typology", "risk", "reason")}
return json.dumps(ordered, ensure_ascii=False)
```

Dictionaries preserve insertion order in Python 3.7+, so rebuilding the dict in a fixed order guarantees the JSON keys always appear as typology, risk, reason.

Why that matters: the model is learning to produce a **token sequence**. If key order varied between examples, the model would have to learn several orderings, which is wasted capacity on a task where the order carries no meaning. Fixing it makes the target maximally predictable.

`ensure_ascii=False` keeps `₹` as itself rather than `₹`, so training targets match the summaries they came from — which the faithfulness check depends on.

---

## 10.2 `finetune.py` — tokenising with loss masking

```python
def tokenize_example(example: dict, tokenizer, max_length: int = MAX_SEQ_LENGTH) -> Dict[str, List[int]]:
    """Token ids for one example, with the loss switched on for the answer only.

    The prompt part gets IGNORE_INDEX, so the model learns to answer, not to repeat the question.
    """
    prompt_text = tokenizer.apply_chat_template(
        build_messages(example["summary"]), tokenize=False, add_generation_prompt=True)
    answer = answer_text(example["label"]) + tokenizer.eos_token
    prompt_ids = tokenizer(prompt_text, add_special_tokens=False)["input_ids"]
    answer_ids = tokenizer(answer, add_special_tokens=False)["input_ids"]
    input_ids = (prompt_ids + answer_ids)[:max_length]
    labels = ([IGNORE_INDEX] * len(prompt_ids) + answer_ids)[:max_length]
    return {"input_ids": input_ids, "attention_mask": [1] * len(input_ids), "labels": labels}
```

This is the most important function in the file. Four lines of real work.

### What the three returned lists mean

| Key | Contents | Purpose |
| --- | --- | --- |
| `input_ids` | prompt tokens + answer tokens | what the model reads |
| `labels` | −100 for the prompt, then the answer tokens | what the loss is computed on |
| `attention_mask` | 1 for every real token | which positions are real, not padding |

### Answer-only loss masking

```python
IGNORE_INDEX = -100           # tells the loss to skip these positions
```

`-100` is not arbitrary. PyTorch's `CrossEntropyLoss` has a parameter `ignore_index` whose default is exactly `-100`. Any position whose label is `-100` contributes nothing to the loss and produces no gradient. It is a convention baked into the framework, and Hugging Face follows it.

So the labels array looks like:

```
input_ids:  [<|im_start|>, system, You, are, ..., <|im_start|>, assistant]  +  [{, "typology", ...]
labels:     [   -100,      -100,  -100, -100, ...,    -100,       -100   ]  +  [{, "typology", ...]
            └──────────── prompt: ignored ────────────────────────────────┘     └── answer: learned ──┘
```

**Why mask the prompt?** Without masking, the model is also trained to predict the alert summary — to generate AML alerts. That is not the task. Worse, the prompt is far longer than the answer (roughly 190 tokens against 40), so most of the gradient signal would go into learning to reproduce inputs.

Masking focuses everything on the forty tokens you care about. It is standard for instruction fine-tuning, and it is also *why your eval loss is so low*: the loss is only ever measured on a short, highly constrained JSON string.

There is a test for it that needs no GPU:

```python
# tests/test_predict.py / test_prompt.py use a fake tokenizer
```

Testing loss masking with a stub tokenizer, so it runs on a laptop, is a nice detail to mention.

### The EOS token

```python
answer = answer_text(example["label"]) + tokenizer.eos_token
```

Without an explicit end-of-sequence token, the model never learns to **stop**. It would produce the JSON and then keep generating — another JSON object, or commentary — until it hit `max_new_tokens`.

The parser in `schema.py` tolerates trailing text (it finds the first `{` and the last `}`), so this would not have been fatal, but it would waste tokens and risk a malformed second object confusing the `rfind("}")`. Appending EOS is the correct fix.

### `add_special_tokens=False`

The chat template has already inserted every special token the model expects. Letting the tokenizer add its own on top would produce a doubled BOS or similar — a subtle corruption that degrades quality without any error. Turning it off is correct and easy to get wrong.

### Truncation

```python
input_ids = (prompt_ids + answer_ids)[:max_length]
```

Slicing to 512. Summaries run under about 190 tokens, so this never fires in practice — but if it ever did, it would cut the **answer**, not the prompt, because the answer is at the end. Training on a truncated answer would teach the model to produce invalid JSON.

A more defensive version would truncate the prompt from the left and always keep the answer intact. Worth saying if asked what you would harden: *"Truncation is right-side, so a long summary would cut the target rather than the input. It never fires with this data, but on real alerts of variable length I would truncate the prompt instead."*

---

## 10.3 Padding a batch

```python
def pad_batch(batch: List[Dict[str, List[int]]], pad_token_id: int) -> dict:
    """Make every example in a batch the same length."""
    import torch

    longest = max(len(item["input_ids"]) for item in batch)
    padded = {"input_ids": [], "attention_mask": [], "labels": []}
    fill = {"input_ids": pad_token_id, "attention_mask": 0, "labels": IGNORE_INDEX}
    for item in batch:
        for key, fill_value in fill.items():
            padded[key].append(item[key] + [fill_value] * (longest - len(item[key])))
    return {key: torch.tensor(values) for key, values in padded.items()}
```

A tensor must be rectangular, so every row in a batch must be the same length. Examples are padded up to the longest one in **that** batch — not to 512 — which is called dynamic padding and wastes much less compute.

The three fill values are each different and each correct:

| Field | Fill | Why |
| --- | --- | --- |
| `input_ids` | `pad_token_id` | a real token id, so the embedding lookup works |
| `attention_mask` | `0` | tells attention to ignore these positions |
| `labels` | `IGNORE_INDEX` | no loss on padding |

Getting any one of these wrong produces a model that trains without error and performs slightly worse than it should. Padding bugs are notoriously hard to find.

The nested loop over `fill.items()` is a neat way to apply three different fills with one piece of logic.

This function is passed to the Trainer as `data_collator`:

```python
data_collator=lambda batch: pad_batch(batch, tokenizer.pad_token_id)
```

A **collator** turns a list of examples into a batch. The lambda captures `tokenizer.pad_token_id` so the collator itself takes only the batch.

---

## 10.4 The training arguments

```python
arguments = TrainingArguments(
    output_dir=str(output_dir),
    num_train_epochs=epochs,
    learning_rate=LEARNING_RATE,                      # 2e-4
    per_device_train_batch_size=BATCH_SIZE,           # 4
    per_device_eval_batch_size=EVAL_BATCH_SIZE,       # 2
    gradient_accumulation_steps=ACCUMULATION_STEPS,   # 4
    fp16=True,
    logging_steps=10,
    save_steps=SAVE_EVERY_STEPS,                      # 100
    eval_steps=SAVE_EVERY_STEPS,                      # 100
    eval_strategy="steps",
    save_total_limit=2,
    report_to="none",
    lr_scheduler_type="cosine",
    warmup_steps=count_warmup_steps(len(train_data), epochs),   # 15
    remove_unused_columns=False)
```

The ones worth being able to justify:

**`learning_rate=2e-4`** — roughly ten times a typical full fine-tuning rate (2e-5). Justified because the adapters are small and randomly initialised, so they can take larger steps safely, while the pretrained weights that would be damaged by a large step are frozen.

**`lr_scheduler_type="cosine"`** — the rate follows a cosine curve from its peak down towards zero. Large steps early to move fast, small steps late to settle. The common alternative is linear decay; cosine is a reasonable default and the difference is usually small.

**`warmup_steps=15`** — the rate ramps from near zero over the first 15 steps. Early gradients are noisy, especially with freshly initialised adapters, and a full-size step on a noisy gradient can do damage that takes many steps to undo.

**`fp16=True`** — mixed-precision training. Forward and backward in fp16, master weights and updates in fp32, with loss scaling to stop small gradients underflowing. Roughly halves memory and speeds things up on tensor cores. Required here because a T4 cannot do bf16.

**`eval_strategy="steps"` with `eval_steps=100`** — evaluate on validation every 100 steps. With 300 total steps that is three evaluations. Enough to see the trend, cheap enough not to dominate the run.

**`save_total_limit=2`** — keep only the two newest checkpoints. Each is tens of megabytes of adapter, and Google Drive fills up.

**`report_to="none"`** — do not try to log to Weights & Biases or TensorBoard. Without it, the Trainer may prompt for a W&B key mid-run in Colab and hang.

**`remove_unused_columns=False`** — the Trainer normally drops dataset columns that do not match the model's forward signature. Here the dataset is a plain list of dicts already in the right shape, and that cleanup would break it.

---

## 10.5 Resuming from a checkpoint

```python
def last_checkpoint(output_dir: Path) -> Optional[str]:
    """The newest saved checkpoint, so a Colab disconnect can be resumed."""
    checkpoints = sorted(output_dir.glob("checkpoint-*"), key=lambda p: int(p.name.split("-")[1]))
    return str(checkpoints[-1]) if checkpoints else None

...
trainer.train(resume_from_checkpoint=last_checkpoint(output_dir))
```

Free Colab disconnects. With `--output-dir` pointing at Google Drive and a save every 100 steps, a disconnect costs at most 100 steps of work.

The sort key is the interesting part. `sorted()` on paths would sort **alphabetically**, putting `checkpoint-1000` before `checkpoint-200`. Extracting the number with `int(p.name.split("-")[1])` sorts numerically. A classic bug, avoided.

`resume_from_checkpoint=None` means "start fresh", so the same line works on a first run and a resumed one.

---

## 10.6 The training function end to end

```python
def train(output_dir: Path, base_model: str, epochs: int, limit: Optional[int]) -> None:
    from transformers import Trainer, TrainingArguments

    model, tokenizer = load_model_and_tokenizer(base_model)
    train_examples = load_split(DATA_FOLDER / "train.jsonl")[:limit]
    validation_examples = load_split(DATA_FOLDER / "validation.jsonl")[: (limit or 300)]
    train_data = [tokenize_example(e, tokenizer) for e in train_examples]
    validation_data = [tokenize_example(e, tokenizer) for e in validation_examples]
    arguments = TrainingArguments(...)
    trainer = Trainer(model=model, args=arguments, train_dataset=train_data,
                      eval_dataset=validation_data,
                      data_collator=lambda batch: pad_batch(batch, tokenizer.pad_token_id))
    trainer.train(resume_from_checkpoint=last_checkpoint(output_dir))
    model.save_pretrained(str(output_dir / "adapter"))
    tokenizer.save_pretrained(str(output_dir / "adapter"))
    print(f"Adapter saved to {output_dir / 'adapter'}")
```

**Only two splits are ever opened.** `train.jsonl` and `validation.jsonl`. Test and held-out are not read anywhere in this file — the docstring states it and the code keeps the promise.

**`[:limit]`** supports the smoke test. `--limit 64` trains on 64 examples for two minutes to prove the whole path works before committing to a long run. The notebook does exactly this first.

**`limit or 300`** — if `limit` is `None` (falsy), use 300. Another use of the `or` idiom.

**`model.save_pretrained`** saves the **adapter only** — a few tens of megabytes, not the 3 GB base. That is the artefact published to Hugging Face. The tokenizer is saved alongside so the adapter folder is self-contained.

---

## 10.7 The Colab notebook

`notebooks/finetune_qlora.ipynb` is twelve cells and deliberately thin:

1. `!nvidia-smi` — confirm a GPU is attached
2. Mount Google Drive — so checkpoints survive a disconnect
3. Clone the repo and `pip install -r requirements-train.txt`
4. **Smoke test:** `--limit 64 --epochs 1`, about two minutes
5. **Full run:** `python -m src.finetune --output-dir /content/drive/MyDrive/aml-alert-investigator`
6. List the adapter folder

The notebook contains no logic. All the code lives in `src/finetune.py`, which is version-controlled, importable and testable. Notebooks are terrible for review — cells run out of order, diffs are unreadable, and state is invisible. Keeping them as thin wrappers is the right pattern and a good thing to say out loud.

One guidance note in cell 8 is worth quoting in an interview:

> Watch `loss` fall and `eval_loss` follow it. If `eval_loss` rises while `loss` keeps falling, stop: the model is memorising.

That is the overfitting signal, written down before the run.

---

## 10.8 What you would change

Be ready with these. Having a list is better than defending every choice.

1. **Try rank 4 and rank 8.** The task is narrow and the generalisation gap suggests memorisation; less capacity might generalise better.
2. **Truncate from the left**, so a long summary never cuts the answer.
3. **Log the learning-rate curve and per-class validation scores**, not just loss. Loss told you almost nothing.
4. **Add a seed and pin library versions** in the training config for stricter reproducibility.
5. **Run one epoch as a comparison.** Two was chosen by convention, not measured.

---

## 10.9 Exercises

1. Write out `labels` by hand for a tiny example with a 5-token prompt and a 3-token answer.
2. Why `-100` specifically? Find it in PyTorch's `CrossEntropyLoss` documentation.
3. Remove `+ tokenizer.eos_token` and predict what generation looks like.
4. Each of the three fill values in `pad_batch` is different. For each, describe the bug you would get from using `0` instead.
5. Compute steps per epoch, total steps and warmup steps for 10,000 examples, 3 epochs, batch 8, accumulation 2.
6. `last_checkpoint` sorts with `int(p.name.split("-")[1])`. Show an ordering that breaks without it.
7. The prompt lists labels via `', '.join(ALL_LABELS)`. What would break if it were typed by hand and a sixth label were added?
