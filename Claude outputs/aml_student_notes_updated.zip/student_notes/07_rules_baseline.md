# Chapter 7 — The rules baseline (`rules.py`, `metrics.py`)

This chapter covers the system that **beat the fine-tuned model**. Understanding why is the most valuable thing in the project.

---

## 7.1 Why have a baseline at all

A macro-F1 of 0.936 means nothing on its own. Is that good? Compared with what?

A baseline answers that. Three rules of thumb:

- **No baseline** → your number is unreadable.
- **A weak baseline** → your number is flattering and dishonest.
- **A strong baseline** → your number is meaningful, and it might lose.

This project built a strong one and reported losing. That is the part that makes a technical reader trust everything else on the page.

---

## 7.2 The rules

```python
@dataclass(frozen=True)
class RuleConfig:
    """The thresholds. Each one is "fire when the number is at least this"."""
    just_under_min: int = 3          # cash deposits just under the reporting limit
    sender_min: int = 5              # different senders in the busiest week
    cash_out_min: int = 50           # percent of that burst sent on within days
    return_min: int = 2              # transfers that came back
    large_min: int = 1               # credits of Rs 50,000 or more
    quick_exit_min: int = 70         # percent of large credits sent on within 2 days


DEFAULT_CONFIG = RuleConfig()
```

```python
def classify(features: dict, config: RuleConfig = DEFAULT_CONFIG) -> Tuple[str, str]:
    """Return (typology, rule_id). Order: R1 structuring, R2 mule, R3 round trip, R4 pass-through."""
    if features["just_under_count"] >= config.just_under_min:
        return "STRUCTURING", "R1"
    if features["sender_count"] >= config.sender_min and features["cash_out_percent"] >= config.cash_out_min:
        return "MULE_ACCOUNT", "R2"
    if features["return_count"] >= config.return_min:
        return "ROUND_TRIPPING", "R3"
    if features["large_count"] >= config.large_min and features["quick_exit_percent"] >= config.quick_exit_min:
        return "RAPID_PASS_THROUGH", "R4"
    return NO_CONCERN, "R0"
```

Twelve lines. No learning, no model, no training data at inference time — just four thresholded comparisons over numbers `features.py` already computed.

### Three design points

**First match wins.** The rules run in a fixed order and return immediately. An alert with both many just-under deposits and many senders is labelled structuring, because R1 comes first. This makes the classifier deterministic and total (every input gets exactly one label) but it bakes in a priority that was never tuned. Reordering R1 and R2 could change results, and nobody tested that. Worth saying if asked what you would improve.

**Each rule returns its id.** `("STRUCTURING", "R1")` — the id travels with the verdict and is shown in the app's comparison table as "Rules, tuned on train (rule R1)". An analyst can see *which* rule fired, not just the answer. That is explainability for free, and it is the thing the language model cannot offer in the same form.

**Rules never output a risk level.** The function returns a typology only. Risk is a function of amount-over-income, and `risk_level` in `features.py` computes it from the true typology. So the rules baseline is compared on typology alone, and the risk-accuracy column in the results table says `n/a` for both rules rows. That is the honest thing to do rather than inventing a risk for them.

**A `dict`, not a `Features` object.** `classify` takes `features: dict` because by the time the rules run, the features have been through JSON. The app and `evaluate.py` both pass `example["features"]` straight from the loaded file.

---

## 7.3 Tuning by grid search

```python
GRID = {
    "just_under_min": (3, 4, 5, 6, 8),
    "sender_min":     (5, 8, 10, 12),
    "cash_out_min":   (30, 50, 70, 85),
    "return_min":     (1, 2, 3),
    "large_min":      (1, 2),
    "quick_exit_min": (50, 70, 80, 90),
}


def all_configs() -> List[RuleConfig]:
    """Every combination of the grid values."""
    names = list(GRID)
    return [replace(DEFAULT_CONFIG, **dict(zip(names, values)))
            for values in product(*(GRID[name] for name in names))]


def tune_on_training_set(train_examples: List[dict]) -> RuleConfig:
    """Pick the thresholds with the best macro-F1 on the training set. Never sees held-out."""
    true_labels = [example["label"]["typology"] for example in train_examples]
    best_config, best_score = DEFAULT_CONFIG, -1.0
    for config in all_configs():
        score = macro_f1(true_labels, predict_all(train_examples, config))
        if score > best_score:
            best_config, best_score = config, score
    return best_config
```

5 × 4 × 4 × 3 × 2 × 4 = **1,920 configurations**, each scored on all 2,400 training examples. About five seconds.

### Unpacking `all_configs`

Three unfamiliar pieces in one expression:

**`itertools.product`** is the Cartesian product — nested loops as an iterator:

```python
>>> list(product((1, 2), ("a", "b")))
[(1, 'a'), (1, 'b'), (2, 'a'), (2, 'b')]
```

`product(*(GRID[name] for name in names))` unpacks six sequences as six arguments, giving every six-tuple of threshold values.

**`zip(names, values)`** pairs field names with that combination's values: `[("just_under_min", 3), ("sender_min", 5), ...]`, and `dict(...)` turns those pairs into a dictionary.

**`dataclasses.replace`** makes a *copy* of a frozen dataclass with some fields changed:

```python
replace(DEFAULT_CONFIG, just_under_min=5, sender_min=8)
```

You cannot assign to a frozen instance, so `replace` is the supported way to derive a variant. It is the dataclass equivalent of "copy with changes".

### The result

```
A1 rules (default):        just_under_min=3, sender_min=5, cash_out_min=50, return_min=2, large_min=1, quick_exit_min=70
A2 rules (tuned on train): just_under_min=3, sender_min=5, cash_out_min=30, return_min=2, large_min=2, quick_exit_min=50
```

Three thresholds changed: `cash_out_min` 50→30, `large_min` 1→2, `quick_exit_min` 70→50.

### The `large_min` change is the whole story

Look at the default rules' false-alarm rate per hard-negative kind on test:

```
cash_heavy_shop               0.0%
house_sale                    0.0%
repay_friend                  6.7%
salary_then_commitments      80.0%     ← eight times in ten
```

Why? A salaried employee earning over ₹50,000 gets one salary credit that counts as "large". Rent, EMI and SIP then leave within two days, so `quick_exit_percent` is high. With `large_min = 1` and `quick_exit_min = 70`, rule R4 fires and labels an ordinary salaried person a pass-through.

Tuning moved `large_min` to **2**: now two or more large credits are needed, and a single salary no longer triggers it. Real pass-through alerts have 2–4 large credits by construction, so they still fire. The false-alarm rate for that hard negative drops from 80% to 0%.

**One threshold, one hard negative, a 2.8-point jump in macro-F1.** This is the clearest example in the project of why hard negatives are worth building: without `salary_then_commitments` in the data, nobody would have discovered that the default rule was broken, because the error would have been invisible.

### Why tuning on the training set is the honest choice

`tune_on_training_set` is given only `data/train.jsonl`. It never sees validation, test or held-out. If thresholds had been tuned on test, the test score would be meaningless — you would be fitting the thing you are measuring with.

A test enforces it:

```python
def test_tuning_uses_only_the_training_examples_it_is_given():
```

And the app re-runs the tuning at startup rather than hard-coding the result, so the displayed numbers always match the code.

---

## 7.4 `metrics.py` — the scoring

### Precision, recall, F1

```python
def score_label(true_labels, predicted, label) -> ClassScore:
    pairs = list(zip(true_labels, predicted))
    true_positive  = sum(1 for t, p in pairs if t == label and p == label)
    false_positive = sum(1 for t, p in pairs if t != label and p == label)
    false_negative = sum(1 for t, p in pairs if t == label and p != label)
    precision = safe_divide(true_positive, true_positive + false_positive)
    recall    = safe_divide(true_positive, true_positive + false_negative)
    f1        = safe_divide(2 * precision * recall, precision + recall)
    return ClassScore(precision, recall, f1)
```

For one label at a time:

- **True positive** — said this label, and it was.
- **False positive** — said this label, and it was not. (A false alarm.)
- **False negative** — did not say it, but it was. (A miss.)

**Precision** = of everything I flagged as this, how much really was. Low precision means crying wolf.

**Recall** = of everything that really was this, how much did I catch. Low recall means missing real cases.

**F1** is their harmonic mean. The harmonic mean punishes imbalance: with precision 1.0 and recall 0.0, the arithmetic mean is 0.5 but F1 is 0. You cannot score well by being excellent at one and useless at the other.

In AML the two errors cost different things: a false positive wastes an analyst's hour, a false negative lets laundering through. A real system would weight them, perhaps with an F-beta score. This project uses plain F1 and reports the false-alarm rate separately, which keeps both visible.

`sum(1 for ... if ...)` is the idiomatic way to count matches in Python — a generator yielding `1` per match, summed.

### Macro-F1

```python
def macro_f1(true_labels, predicted) -> float:
    scores = score_all_labels(true_labels, predicted)
    return sum(score.f1 for score in scores.values()) / len(scores)
```

F1 for each of the five labels, averaged with equal weight.

**Macro versus micro.** Micro averaging pools every prediction, so a label with 160 examples counts four times as much as one with 40. Macro gives each label the same weight regardless of size.

Why macro is right here: the test set is 160 `NO_CONCERN`, 60 of each typology. Under micro averaging, a model that handled normal alerts perfectly and mule accounts badly would still look strong. Under macro, mule accounts are 20% of the score. Since the whole point is catching rare patterns, macro is the honest metric.

This is a near-certain interview question. The one-line answer: **"Macro, because the rare classes are the ones that matter and micro would let the majority class hide failures on them."**

### False-positive rates per hard negative

```python
def false_positive_rates(true_labels, predicted, kinds) -> Dict[str, float]:
    flagged: Dict[str, int] = defaultdict(int)
    total: Dict[str, int] = defaultdict(int)
    for true, guess, kind in zip(true_labels, predicted, kinds):
        if true != NO_CONCERN:
            continue
        for group in ("all_no_concern", kind or "ordinary"):
            total[group] += 1
            if guess != NO_CONCERN:
                flagged[group] += 1
    return {group: safe_divide(flagged[group], total[group]) for group in total}
```

This is the project's most distinctive metric. It looks only at alerts that truly are `NO_CONCERN` and asks how often each system wrongly flagged them — broken down by *kind* of innocent alert.

`kind or "ordinary"` uses the `or` trick: when `kind` is `None` (falsy), the expression evaluates to `"ordinary"`. Every alert is counted twice, once in its own group and once in `all_no_concern`.

The output is what exposes both systems' weak spots:

| | A1 rules, test | C fine-tuned, held-out |
| --- | --- | --- |
| ordinary | 0.0% | 0.0% |
| cash_heavy_shop | 0.0% | 0.0% |
| house_sale | 0.0% | 0.0% |
| repay_friend | 6.7% | 13.3% |
| salary_then_commitments | **80.0%** | **53.3%** |
| all_no_concern | 8.1% | 8.3% |

A single headline number would say "8% false alarms" and hide the fact that almost all of them come from one confusable kind. Breaking it down turns a score into a diagnosis.

Notice that `salary_then_commitments` is the hardest case for *both* systems, for different reasons: the rules because of a threshold, the model because the held-out wording described the same pattern in unfamiliar words.

---

## 7.5 Results and the honest reading

| System | Macro-F1 test | Macro-F1 held-out | False alarms test / held-out |
| --- | --- | --- | --- |
| A1 rules, default | 0.962 | 0.948 | 8.1% / 14.2% |
| A2 rules, tuned | 0.990 | 0.990 | 0.0% / 1.7% |
| B base model | 0.135 | 0.181 | 100% / 100% |
| C fine-tuned | 1.000 | 0.936 | 0.0% / 8.3% |

### Why the rules do so well

Because of how the data was made. The generator plants a pattern; `features.py` computes numbers that describe it; the rules read those exact numbers. The rules are reading the output of the same logic that created the labels. They are, in effect, a slightly noisy copy of the generator.

The model's path is longer: numbers → English summary → tokens → learned weights → JSON. It is solving a harder version of the same problem.

**This is the answer to "why use the model at all?"** Say it like this:

> "The tuned rules read the exact computed features that the generator used to create the labels, so they have a home advantage that would not exist on real, messy data. The model is reading text. On this dataset the rules deserve to win, and they do. What the model adds is an explanation in words, tolerance of new phrasing without anyone rewriting thresholds, and a single pass that produces typology, risk and reason together."

Do not oversell it. The honest version is far more convincing than a claim the repository contradicts.

### Why the rules are *not* obviously better in general

Three things the rules cannot do:

- Produce a written reason. R1 gives you "R1", not a sentence an analyst can check.
- Survive a change in the input format. Rules need the exact feature keys; the model reads English and tolerated a complete rewording at a cost of 0.064.
- Handle a pattern nobody wrote a rule for. Both would fail, but the model at least produces something inspectable.

And one thing they do better that is easy to miss: **rules degrade predictably**. If a threshold is wrong you can see it, change it, and know exactly what changed. A model's failure is diffuse.

---

## 7.6 Exercises

1. Compute by hand: 100 alerts, 20 are STRUCTURING, a system flags 25 as STRUCTURING of which 18 are right. Precision? Recall? F1?
2. Build a system that labels everything `NO_CONCERN`. What is its macro-F1 on test? (Four labels score 0, one scores well.) What does that tell you about the floor?
3. Change `large_min` back to 1 in a scratch copy and re-run `python -m src.evaluate`. Confirm the `salary_then_commitments` false-alarm jump.
4. Reorder R1 and R2 in `classify`. Which alerts change label, and does macro-F1 move?
5. Add `quick_exit_min: (40, 50, 60, 70, 80, 90)` to the grid. How many configurations now, and how much slower is tuning?
6. Write the two-sentence answer to "your rules beat your model, so why did you fine-tune anything?" and say it out loud.
