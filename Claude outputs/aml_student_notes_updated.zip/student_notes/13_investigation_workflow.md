# Chapter 13 — The investigation workflow

Four files: `investigator.py` (the six steps), `case_store.py` (case memory), `case_note.py` (the written note), `audit.py` (the log).

---

## 13.1 What this layer is for

The model produces a verdict. That is not a product. A product is: an analyst opens an alert, sees the evidence, sees what the model and the rules each said, reads a drafted note, and records a decision that someone can later audit.

This layer is the difference between a notebook and something a bank could look at.

---

## 13.2 The six steps

```python
"""The fixed six-step investigation workflow, with guardrails.

    1 Load the alert           4 Classify (saved model answer, checked)
    2 Fetch the transactions   5 Draft the case note
    3 Compute the findings     6 Analyst decision (the only step a person does)

The steps always run in this order. No model plans anything; a small model calls
tools unreliably, so the order is fixed (see PRD.md). Steps 1 to 5 only read and
write local files. Nothing is filed, frozen or sent, and nothing can be exported,
before the analyst records a decision in step 6.
"""
```

Read that docstring carefully — it is the design rationale in six lines, and it is the honest version.

### This is not an agent, and the code says so

```python
def run_investigation(alert, transactions, case_folder=CASE_FOLDER, log_path=AUDIT_LOG) -> Case:
    """Run steps 1 to 5, log each one, save the case file and wait for the analyst."""
    steps = [load_alert_step(alert), fetch_transactions_step(transactions),
             compute_findings_step(alert), classify_step(alert)]
    note_step, note = draft_note_step(alert, steps[2].details)
    steps += [note_step, waiting_step()]
    for step in steps[:5]:
        append_event(alert.alert_id, f"step {step.number}: {step.name.lower()}",
                     after=f"{step.status}: {step.summary}", log_path=log_path)
    needs_review = any(step.status == "needs_review" for step in steps)
    case = Case(alert.alert_id, NEEDS_REVIEW_STATUS if needs_review else AWAITING_ANALYST, steps, note)
    save_case(case, case_folder)
    return case
```

Five function calls in a list, in order. No planner, no tool-calling loop, no model deciding what to do next.

**Why that was the right call**, and how to say it:

> "A 1.5B model calls tools unreliably. Letting it plan adds failure modes with no benefit when the steps are already known. In a regulated process you want the same steps in the same order every time, so an auditor can follow them. A planner earns its place when the task is genuinely open-ended across many systems — this one is not, so the workflow is deterministic and the model is used where it is good: labelling and explaining."

**What not to say:** do not call this an autonomous agent. The LinkedIn job post asks for "multi-step AI agents with tool calling, memory, and guardrails". This workflow has multi-step orchestration, memory and guardrails — but the tool calling is Python calling Python, not a model choosing tools. Claiming otherwise is checkable in thirty seconds.

### The step record

```python
@dataclass
class StepRecord:
    """What one workflow step did. 'details' are short plain-English lines."""
    number: int
    name: str
    status: str                      # done, needs_review, unavailable or waiting
    summary: str
    details: List[str] = field(default_factory=list)
```

`field(default_factory=list)` is required, and this is a Python trap worth knowing. You cannot write `details: List[str] = []` — a mutable default is created **once** at class definition and shared by every instance, so appending to one step's details would append to all of them. `default_factory=list` calls `list()` fresh for each instance.

Four statuses, each meaning something different:

| Status | Meaning |
| --- | --- |
| `done` | worked |
| `needs_review` | something failed a check; a human must look |
| `unavailable` | the data was not there (transactions missing) |
| `waiting` | step 6, before the analyst has acted |

Distinguishing `unavailable` from `needs_review` matters: a missing raw file is an operational problem, not a suspicious alert.

### The individual steps

```python
def load_alert_step(alert: ReviewAlert) -> StepRecord:
    """Step 1: say which alert is being investigated."""
    return StepRecord(1, "Load alert", "done", f"Loaded {alert.alert_id} for {alert.customer_id}.",
                      [f"Set: {alert.split}", f"Window ends: {alert.window_end or 'not available'}"])


def fetch_transactions_step(transactions: List[dict]) -> StepRecord:
    """Step 2: count the transactions, or say plainly that they are not available."""
    if not transactions:
        return StepRecord(2, "Fetch transactions", "unavailable",
                          "Transactions are not available here.",
                          ["The raw file is made by `python -m src.generator`."])
    days = sorted(txn["day"] for txn in transactions)
    return StepRecord(2, "Fetch transactions", "done", f"Fetched {len(transactions)} transactions.",
                      [f"From {days[0]} to {days[-1]}."])


def compute_findings_step(alert: ReviewAlert) -> StepRecord:
    """Step 3: velocity and profile comparison, computed by Python from the features."""
    findings = build_findings(alert.features)
    return StepRecord(3, "Compute findings", "done", f"Computed {len(findings)} findings.", findings)
```

Each is tiny and returns the same type. Step 2 degrades gracefully with a message that tells you how to fix it, rather than raising.

Step 4 is the one that reads the model:

```python
def classify_step(alert: ReviewAlert) -> StepRecord:
    """Step 4: show the model's saved answer. An answer that failed the checks goes to review."""
    if alert.model_typology == NEEDS_REVIEW:
        return StepRecord(4, "Classify", "needs_review", "The model's answer could not be validated.",
                          alert.model_problems)
    details = [f"Reason: {alert.model_reason}", agreement_label(alert),
               f"Tuned rules said: {words_for(alert.rules_tuned)} (rule {alert.rules_tuned_rule_id})."]
    return StepRecord(4, "Classify", "done",
                      f"{words_for(alert.model_typology)}, risk {alert.model_risk}.", details)
```

Note the docstring: *"show the model's saved answer"*. No generation happens here. The verdict was produced on Colab and stored in `results/`; `review.py` loaded it. The step displays it, records the cross-check against the rules, and routes a failed answer to review.

Step 5 can refuse to produce its output:

```python
def draft_note_step(alert, findings) -> tuple:
    """Step 5: returns (step record, note text). A failed wording check withholds the note."""
    try:
        note = draft_case_note(alert, findings)
    except GuardrailError as problem:
        return StepRecord(5, "Draft case note", "needs_review", str(problem), []), WITHHELD_NOTE
    return StepRecord(5, "Draft case note", "done", "Drafted the case note from the computed findings.", []), note
```

`WITHHELD_NOTE = "Note withheld: the wording check failed. Review by hand."` — the guardrail does not crash the workflow, it replaces the output with an explanation. The case is marked `needs_review` and the analyst sees why.

---

## 13.3 `case_note.py` — written by Python, not by a model

> **Later change (chapter 22):** each finding in the drafted note now ends with the transaction ids it was computed from — "… totalling ₹2,53,600. (rows: A-test-0005-T004, A-test-0005-T007, …)". The findings themselves are unchanged, and `draft_case_note` now takes (text, row ids) pairs instead of plain strings. Step 3's summary line is deliberately unchanged; the ids are added only when the note is drafted.

```python
def build_findings(features: dict) -> List[str]:
    """Every computed finding about the alert, as short sentences."""
    lines = [money_line(features)]
    for make_lines in (cash_line, pass_through_line, sender_line, return_line):
        lines.extend(make_lines(features))
    if len(lines) == 1:
        lines.append("None of the four patterns showed up in the computed numbers.")
    return lines
```

Each helper returns a list — empty when its pattern is absent:

```python
def cash_line(features: dict) -> List[str]:
    if features["just_under_count"] == 0:
        return []
    return [f"{plural(features['just_under_count'], 'cash deposit')} just under the reporting limit within "
            f"{plural(features['just_under_span_days'], 'day')}, totalling {format_rupees(features['just_under_total'])}."]
```

Returning a list rather than `None` is what lets the caller use `lines.extend(...)` uniformly with no `if` per helper. A small, clean pattern.

Iterating over a tuple of functions — `for make_lines in (cash_line, pass_through_line, ...)` — is the dispatch idea again, this time as a sequence.

### The note itself

```python
def draft_case_note(alert: ReviewAlert, findings: List[str]) -> str:
    """The draft case note as Markdown. Raises GuardrailError if the wording check fails."""
    lines = [
        f"# Case note: {alert.alert_id}",
        "",
        f"**Customer:** {alert.customer_id}  ·  **Window ends:** {alert.window_end or 'not available'}",
        f"**Model verdict:** {words_for(alert.model_typology)}, risk {alert.model_risk}",
    ]
    if alert.model_reason:
        lines.append(f"**Model reason:** {alert.model_reason}")
    lines += ["", "## Computed findings"] + [f"- {finding}" for finding in findings]
    lines += ["", "## Cross-check", agreement_label(alert), "", "## Suggested next step", next_step_for(alert),
              "", f"_{SYNTHETIC_NOTE}_"]
    note = "\n".join(lines)
    assert_clean_wording(note)
    return note
```

**Every number in this note came from `features`.** No model wrote any part of it except the quoted `model_reason`, which was already checked. This is the strongest guarantee in the project: the case note cannot contain an invented figure, because no generative model touched it.

It is also the sentence to say during a demo: *"Python wrote this note from the computed numbers, so it can't invent a figure."*

The note ends with `_Synthetic data. Prototype, not certified for compliance._` — the disclaimer travels with the exported document, not just the screen.

### Careful language

```python
def next_step_for(alert: ReviewAlert) -> str:
    """What the analyst should do, in calm words. Nothing is filed or sent."""
    if alert.model_typology == NEEDS_REVIEW:
        return "Review the transactions by hand: the model's answer could not be validated."
    if alert.model_typology == NO_CONCERN:
        return "No further action suggested. The analyst confirms or overrides."
    return "Refer for review by a senior analyst before any action. Nothing has been filed or sent."
```

"Refer for review", never "this customer is laundering money". In real compliance work an unproven accusation recorded against a customer is a legal problem. The phrasing is a domain requirement, not politeness.

```python
def assert_clean_wording(text: str) -> None:
    """Refuse text that accuses anyone. We refer for review; we never say fraud."""
    lowered = text.lower()
    for word in BANNED_WORDS:
        if word in lowered:
            raise GuardrailError(f"The wording check refused the word '{word}'.")
```

Raising rather than silently stripping. A note containing "fraud" is not quietly cleaned — it is refused, loudly, and the case is flagged. The same function checks the **analyst's** note too, so a human cannot write it either.

---

## 13.4 `case_store.py` — case memory

```python
@dataclass
class Case:
    """Everything the workflow knows about one alert."""
    alert_id: str
    status: str
    steps: List[StepRecord]
    note: str
    decision: Optional[dict] = None   # set once, by the analyst


def save_case(case: Case, folder: Path = CASE_FOLDER) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    case_path(case.alert_id, folder).write_text(
        json.dumps(asdict(case), ensure_ascii=False, indent=2), encoding="utf-8")


def load_case(alert_id: str, folder: Path = CASE_FOLDER) -> Optional[Case]:
    path = case_path(alert_id, folder)
    if not path.exists():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    steps = [StepRecord(**step) for step in data.pop("steps")]
    return Case(steps=steps, **data)
```

One JSON file per alert in `audit/cases/`. Close the browser, come back, the case is there.

### The reconstruction detail

```python
steps = [StepRecord(**step) for step in data.pop("steps")]
return Case(steps=steps, **data)
```

`asdict` flattens nested dataclasses into nested dicts, so loading has to rebuild them. `data.pop("steps")` removes the steps from the dictionary **and** returns them, so the remaining `**data` can be unpacked without a duplicate `steps` argument. Neat, and a little subtle — `pop` doing both jobs is what makes the two lines work.

`indent=2` makes the file human-readable, which matters for something called an audit artefact. You can open a case file in any editor and read it.

### What "memory" means here, precisely

The common phrase is "case memory", and it is accurate but narrow. It means: **the workflow's state for one alert persists between sessions.** Reopening loads the steps, the note and any decision.

It does **not** mean cross-alert history — "this customer was flagged three months ago" — because each synthetic customer has exactly one alert. There is nothing to remember across alerts.

Say it precisely: *"Case memory is per-alert state that survives a restart. There is no cross-alert customer history, because each synthetic customer has one alert. On real data that history would be the most valuable feature in the system, and adding it would mean keying cases by customer rather than alert."*

That last sentence turns a limitation into a design opinion, which is the right move.

---

## 13.5 `audit.py` — the append-only log

```python
@dataclass(frozen=True)
class AuditEvent:
    """One thing that happened. 'before' and 'after' are short plain-text states."""
    time: str
    alert_id: str
    action: str
    before: str
    after: str
    note: str


def append_event(alert_id, action, before="", after="", note="", log_path=AUDIT_LOG) -> AuditEvent:
    """Add one event to the end of the log and return it."""
    event = AuditEvent(now_text(), alert_id, action, before, after, note.strip())
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as log_file:
        log_file.write(json.dumps(asdict(event), ensure_ascii=False) + "\n")
    return event
```

Fifty-one lines, and conceptually the most important file in the application layer.

**`open(path, "a")`** — append mode. The file is opened at the end; existing content cannot be overwritten. There is no update function and no delete function in this module. The only operations are append and read.

That is what "append-only" means in practice, and it is enforced by the **absence** of code rather than the presence of it. A good thing to point out: the guarantee comes from what the module refuses to offer.

**`with` statement** — the file is closed even if an exception is raised mid-write.

**JSON Lines again** — appending to a JSON array would require rewriting the file; appending a line does not.

**`frozen=True`** on the event — once created, an event cannot be modified in memory either.

### Before and after

```python
append_event(alert.alert_id, f"decision: {action}",
             before=f"{words_for(alert.model_typology)} / {alert.model_risk}",
             after=f"{words_for(typology)} / {risk}", note=note, log_path=log_path)
```

For a decision, `before` is the model's verdict and `after` is the analyst's. That single line is the audit trail: it shows what the machine said, what the human decided, when, and why.

For a workflow step, `before` is empty — nothing changed, something merely happened.

This is the line to show in a demo. Open the audit log after approving an alert and point at the before/after. It is the most concrete expression of "the AI labels, a person decides".

---

## 13.6 The decision, and the guardrails around it

```python
def check_decision(action: str, typology: str, risk: str, note: str) -> None:
    """Refuse a decision that is incomplete, uses unknown labels, or uses accusing words."""
    if action not in ACTIONS:
        raise DecisionError("The decision must be approve or override.")
    if typology not in ALL_LABELS or risk not in RISK_LEVELS:
        raise DecisionError("Choose a typology and a risk level from the lists.")
    if action == "override" and not note.strip():
        raise DecisionError("Add a note to explain the override.")
    try:
        assert_clean_wording(note)
    except GuardrailError as problem:
        raise DecisionError(str(problem))
```

Four rules, every one of them a policy decision expressed as code:

1. The action must be approve or override.
2. Labels must come from the fixed lists — the analyst cannot invent a typology either.
3. **An override requires a written note.** Disagreeing with the model costs you a sentence of justification. That is deliberate friction, and it is exactly what an auditor would want.
4. The analyst's note passes the same wording check as the model's output.

Point 4 is worth emphasising: the guardrail is not aimed only at the AI. A human writing "this customer is a criminal" into a case note is refused by the same function.

```python
def record_decision(alert, case, action, typology, risk, note,
                    case_folder=CASE_FOLDER, log_path=AUDIT_LOG) -> Case:
    """Step 6: save the analyst's decision beside the model's verdict, which stays unchanged."""
    check_decision(action, typology, risk, note)
    case.decision = {"time": now_text(), "action": action, "typology": typology, "risk": risk,
                     "note": note.strip()}
    case.status = DECIDED
    case.steps[5] = StepRecord(6, "Analyst decision", "done",
                               f"Analyst {PAST_TENSE[action]}: {words_for(typology)}, risk {risk}.",
                               [note.strip()] if note.strip() else [])
    save_case(case, case_folder)
    append_event(alert.alert_id, f"decision: {action}", before=..., after=..., note=note, log_path=log_path)
    return case
```

**The model's verdict is never touched.** `alert.model_typology` is read for the `before` field and left alone. The decision is stored as a separate field — an overlay, not an edit. Both are in the case file afterwards.

```python
PAST_TENSE = {"approve": "approved", "override": "overrode"}
```

This exists because an earlier version produced "Analyst overrided", from naive string concatenation. A tiny dictionary fixing a tiny bug — and a nice illustration that a project written to be read out loud catches things a project written for a demo does not.

### Exports are blocked

```python
class ExportBlockedError(Exception):
    """Raised when someone tries to export a case before the analyst has decided."""


def export_markdown(case: Case) -> str:
    """The case note plus the analyst's decision. Blocked until the analyst has decided."""
    if case.decision is None:
        raise ExportBlockedError("Nothing can be exported before the analyst records a decision.")
    return "\n".join([case.note] + decision_section(case))
```

A named exception type, not a `ValueError`. The app catches it; the message is written for a human to read.

The rule it enforces comes from the PRD: *"No side effects without approval. Nothing is filed, frozen or sent before the analyst's decision."* In a real system the equivalent would be filing a report with the regulator or freezing an account. Here the irreversible thing is a download, so that is what is gated.

---

## 13.7 Why this layer is testable

`tests/test_investigator.py` has eleven tests and needs no browser, no GPU and no model.

That works because of a design choice visible in every function signature:

```python
def run_investigation(alert, transactions, case_folder=CASE_FOLDER, log_path=AUDIT_LOG) -> Case:
def append_event(alert_id, action, before="", after="", note="", log_path=AUDIT_LOG) -> AuditEvent:
def save_case(case: Case, folder: Path = CASE_FOLDER) -> None:
```

**Every path is a parameter with a default.** Production uses the defaults; tests pass `tmp_path` and write to a temporary folder that pytest deletes afterwards. No mocking of the filesystem, no global state, no test leaving files behind.

This is **dependency injection** in its simplest Python form, and it is worth naming in an interview. The alternative — hard-coding `AUDIT_LOG` inside the functions — would make these tests either impossible or dependent on patching module globals.

---

## 13.8 Exercises

1. Trace `run_investigation` for an alert whose model answer failed validation. Which steps get which status, and what is the final case status?
2. Why is `field(default_factory=list)` required on `StepRecord.details`? Write the bug that the mutable default would cause.
3. Try to export a case before deciding. Which exception, and where is it caught in the app?
4. `record_decision` sets `case.steps[5]`. Why index 5, and what would happen if a seventh step were added?
5. Add a `request_more_information` action. Which functions change, and what should the audit `before`/`after` look like?
6. Explain in two sentences why an override needs a note but an approval does not.
7. The audit module has no update and no delete. Describe how you would prove to an auditor that the log has not been tampered with. (Hint: hashing.)
