# Chapter 16 — Deployment and publishing

How the project left the laptop: `publish.py` to Hugging Face, `build_space.py` for a Docker Space that was never used, and Streamlit Community Cloud for the live demo.

---

## 16.1 What was published, and where

| Artefact | Location |
| --- | --- |
| Code | github.com/coachuttam/aml-alert-investigator |
| Fine-tuned adapter | huggingface.co/coachuttam/aml-alert-investigator-qwen2.5-1.5b-qlora |
| Synthetic dataset | huggingface.co/datasets/coachuttam/aml-alert-investigator-data |
| Live demo | aml-alert-investigator.streamlit.app |

Four links. The job post asked for "contributing to open-source LLM projects or publishing models and datasets on Hugging Face" and "demonstrating practical implementations through GitHub repositories" — this covers both.

---

## 16.2 `publish.py` — uploading to Hugging Face

```python
"""Publishes the trained adapter and the dataset to Hugging Face.

    python -m src.publish --adapter /path/to/adapter            private repos (default)
    python -m src.publish --adapter /path/to/adapter --public   make them public

The token is read from the HF_TOKEN environment variable, never typed into a file.
"""

USERNAME = "coachuttam"
MODEL_REPO = f"{USERNAME}/aml-alert-investigator-qwen2.5-1.5b-qlora"
DATASET_REPO = f"{USERNAME}/aml-alert-investigator-data"
```

### Private by default

```python
parser.add_argument("--public", action="store_true", help="make the repos public (default: private)")
...
publish_dataset(api, private=not args.public)
publish_model(api, Path(args.adapter), private=not args.public)
```

The safe choice is the default. Making something public requires an explicit flag; accidentally publishing requires a mistake in the opposite direction. This is the same thinking as `--final` on the evaluation script: **make the irreversible action the one you have to ask for.**

### Secrets

```python
def get_api():
    """A Hugging Face client using the HF_TOKEN environment variable."""
    token = os.environ.get("HF_TOKEN")
    if not token:
        raise SystemExit("HF_TOKEN is not set. In Colab: os.environ['HF_TOKEN'] = userdata.get('HF_TOKEN')")
    from huggingface_hub import HfApi
    return HfApi(token=token)
```

The token is never in the code, never in a file, never in a notebook cell. It comes from an environment variable, and in Colab from the Secrets panel.

`raise SystemExit(message)` exits with the message and a non-zero status — cleaner than `print` plus `sys.exit(1)`, and it carries a *useful* message telling you how to fix it.

There is a test for this:

```python
# tests/test_publish.py asserts the publish script refuses to run without a token
# and never hard-codes one
```

Testing that your code refuses to run without a secret, and that no secret is embedded, is a security control expressed as a test. Worth mentioning.

### Replacing the auto-generated card

```python
def publish_model(api, adapter_folder: Path, private: bool) -> None:
    api.create_repo(MODEL_REPO, repo_type="model", private=private, exist_ok=True)
    api.upload_folder(folder_path=str(adapter_folder), repo_id=MODEL_REPO, repo_type="model",
                      ignore_patterns=["README.md"])
    api.upload_file(path_or_fileobj=str(CARD_FOLDER / "MODEL_CARD.md"), path_in_repo="README.md",
                    repo_id=MODEL_REPO, repo_type="model")
```

PEFT writes its own `README.md` into the adapter folder. `ignore_patterns=["README.md"]` skips it, then the project's own `MODEL_CARD.md` is uploaded in its place.

That card states the honest results and the limits, which `AGENTS.md` requires and a test checks. A model card that says "this did not beat a threshold baseline on held-out data" is unusual on Hugging Face and is exactly the kind of thing a careful reader notices.

`exist_ok=True` makes re-running safe — the script is idempotent.

### Why only the adapter

The adapter is tens of megabytes; the merged model would be about 3 GB. More importantly, from the PRD:

> Base model: decided. Qwen2.5-1.5B-Instruct (Apache-2.0 per its model page); only the adapter is published, not merged weights.

Publishing merged weights means redistributing the base model, which raises a licence question. Publishing the adapter alone sidesteps it: users download Qwen themselves under its own terms and apply your adapter.

**This is a genuinely good answer to a licensing question in an interview**, and licensing is a real concern for a company shipping software to banks.

---

## 16.3 The Hugging Face Space that did not work

`build_space.py` builds a folder for a Hugging Face Space: a `README.md` with YAML front matter, a `Dockerfile`, a `requirements.txt` and the subset of source files the demo needs.

```python
# The Space only reads saved answers, so the training and publishing scripts stay out.
LEFT_OUT_FROM_SRC = {"finetune.py", "predict.py", "publish.py", "build_space.py"}
RAW_SPLITS_SHOWN = ("validation", "test", "heldout")   # the app never reads the raw training set
STREAMLIT_VERSION = "1.50.0"                           # the version tested on the laptop
```

Three deployment decisions in three constants:

- Training code is excluded — the deployment has no business containing the training script.
- The raw training set is excluded — the app never shows it, and shipping it would be waste.
- The Streamlit version is pinned to the one tested locally, so the deployment cannot differ from the laptop.

```python
DOCKERFILE = f"""FROM python:3.10-slim
RUN useradd -m -u 1000 user
USER user
ENV PATH="/home/user/.local/bin:$PATH"
WORKDIR /home/user/app
COPY --chown=user requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY --chown=user . .
EXPOSE {APP_PORT}
CMD ["streamlit", "run", "app.py", "--server.port={APP_PORT}", "--server.address=0.0.0.0", ...]
"""
```

Three Docker practices worth knowing, all present here:

**Run as a non-root user.** `useradd -m -u 1000 user` then `USER user`. Running containers as root is a standard security finding. Hugging Face expects uid 1000 specifically.

**Copy requirements before the code.** Docker caches layers. Requirements change rarely and code changes often; copying requirements first means a code change does not re-run `pip install`.

**`--server.address=0.0.0.0`.** By default Streamlit binds to localhost, which inside a container means "reachable only from inside the container". Binding to all interfaces is what lets the host reach it. This catches almost everyone the first time.

`--no-cache-dir` keeps the image smaller by not storing pip's download cache.

### Why it was abandoned

The module docstring records it:

```python
"""
Hugging Face now needs a PRO subscription for Docker Spaces (402 error on the free plan).
Streamlit Community Cloud is the free alternative; see README.md.
"""
```

The sequence of failures, from the README's problems table:

| Problem | Cause | Fix |
| --- | --- | --- |
| Space rejected `sdk: streamlit` (400) | Hugging Face removed the built-in Streamlit option | Switch to a Docker Space with a Dockerfile |
| Docker Space refused to build (402) | Free Spaces are static-only; Docker needs PRO | Move to Streamlit Community Cloud |
| Upload failed (401) | Token lines pasted together, so the command was swallowed | Run the steps separately and check the token length |

Three platform failures in a row, each with a different cause. This is a good story to tell, because deployment is where portfolio projects usually stop, and persisting through a 400, a 402 and a 401 to get a live demo is the part that most candidates skip.

**Keeping `build_space.py` in the repository was the right call.** It documents the attempt, it still works if the account is upgraded, and the docstring explains why it is unused. Deleting it would erase the reasoning.

---

## 16.4 Streamlit Community Cloud — the live demo

The deployment that worked: free, deploys from a public GitHub repo, no Docker.

Setup is three fields — repository, branch, main file path — and the one that caused trouble was the last: the default is `streamlit_app.py` and this project's entry point is `app.py`. The error was "Main file path: This file does not exist".

### What had to change for a public host

**Commit the raw data the app needs.** `data/raw/{validation,test,heldout}.jsonl` were added to the repository so the evidence table has transactions. `train.jsonl` stayed excluded — the app never reads it.

**Detect the shared environment.** `is_shared_demo()` checks for `/mount/src`, the folder Streamlit Cloud clones into, and shows the notice about shared state.

**Accept that state is shared and temporary.** Everyone's decisions land in the same `audit/` folder on the host, and it resets when the app restarts or sleeps. For a demo that is acceptable; the notice says so plainly.

### The operational facts worth knowing before a demo

- **It sleeps when idle.** The first visit after a quiet period takes about 30 seconds to wake. Open it a few minutes before showing anyone.
- **Decisions reset on restart.** Run one investigation and one approval immediately before a demo, so the audit log is not empty.
- **It is public.** The notice asks visitors not to type personal information.

---

## 16.5 Why the demo needs no GPU

The single most important architectural fact about the deployment, and the one to lead with if asked how it is hosted.

`predict.py` ran on Colab and wrote `results/finetuned_test.jsonl` and friends. The app reads those files. No model is ever loaded.

```
Colab (GPU)                          Streamlit Cloud (free, CPU)
───────────                          ───────────────────────────
load model in 4-bit                  read results/*.jsonl
generate 400 answers                 read data/*.jsonl
check each one                       run the rules live
save to results/*.jsonl    ────────► join and display
```

The honest phrasing: **"Inference for the sample alerts is offline and batched. The app displays saved verdicts, which is why it deploys anywhere."**

Say "saved answers" rather than letting someone assume the model is running. It is checkable, and the README states it.

**Since 13 November 2026 this is only half the picture.** The obvious next step named here was taken: the Live run tab classifies an uploaded alert with a model running either on your own machine (`AML_LOCAL_MODEL=1`, about 15 to 20 seconds an alert, nothing leaving the laptop) or on a Modal GPU that sleeps when idle. The hosted Streamlit demo still has no GPU, so uploads there go to "needs review" behind an amber warning. Chapter 22 covers both paths and why the hosted one was written but deliberately not deployed.

So the precise sentence is now: *"the sample alerts show saved answers; uploads are classified live, on whichever machine is running the app."*

---

## 16.6 What a production deployment would look like

A reasonable answer to "how would you deploy this properly?", and worth rehearsing because the job description asks about production systems.

**Inference service.** The model behind an API, served with vLLM or Hugging Face TGI — both handle continuous batching, the KV cache and multi-LoRA serving. Inside the bank's network; no customer data leaves.

**One base, many adapters.** A per-customer or per-jurisdiction adapter, each tens of megabytes, swapped per request. Chapter 9 covers why this is the strongest architectural argument the project supports.

**Model registry.** The adapter versioned together with the prompt and the data that produced it, so any verdict can be reproduced and rolled back.

**Rollout in stages.** Shadow mode first — run alongside the existing rules, decide nothing, compare for weeks. Then assistive mode, where it orders the queue and drafts notes but the analyst decides. Never auto-filing.

**Monitoring.** Input drift on the feature distributions, output drift on the label mix, guardrail failure rate (invalid JSON, ungrounded numbers), and the analyst override rate — which this project already records as before/after in the audit log, and which is the most informative signal of the four.

**Persistent, tamper-evident storage.** The case store and audit log move from local JSON files to a real database with retention policies, access control, and ideally a hash chain so the log can be proved unaltered.

**Secrets management.** `HF_TOKEN` from an environment variable is right for a prototype; production uses a secrets manager with rotation.

---

## 16.7 Exercises

1. Why private by default in `publish.py`? Name the other place in the project that uses the same principle.
2. Read the `Dockerfile` string in `build_space.py` and explain each line. Which would you change for a production image?
3. Why is the training set excluded from the Space build but the test set included?
4. The demo shows saved answers for its sample alerts. Read `src/local_model.py` and `model_server.py` and list what each one needs that the Streamlit host cannot provide.
5. `remote_model.py` returns `None` unless the address starts with `https://`. Explain what attack that prevents, and what it does not prevent.
5. Why publish the adapter and not merged weights? Give both the technical and the licensing reason.
6. Write a short runbook for demonstrating the live app: what to do five minutes before, what to click, what to say.
