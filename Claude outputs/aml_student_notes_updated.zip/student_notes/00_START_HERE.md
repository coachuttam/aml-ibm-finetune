# AML Alert Investigator — student notes

These notes explain the whole project, file by file, from first principles. They were written by reading the actual source code, not the project description, and every number in them was re-checked by running the code.

**Who these are for:** you, revising your own project before an interview; and anyone learning how a small fine-tuned language model is put to work inside a controlled workflow.

**What the project is, in one sentence.** A synthetic anti-money-laundering dataset is generated in Python, every number is computed in Python, a Qwen2.5-1.5B model fine-tuned with QLoRA reads a summary of those numbers and returns a typology, a risk level and a one-line reason as JSON, every answer is validated, and a fixed six-step workflow puts the answer in front of a human analyst who approves or overrides it, with every step written to an append-only log.

The design rule the whole project follows: **the AI labels and explains, Python counts, a person decides.**

---

## Chapters

| # | File | What it covers |
| --- | --- | --- |
| 1 | `01_architecture_and_flow.md` | How the parts fit together and what happens in what order |
| 2 | `02_repository_map.md` | Every directory and file, and how to run everything |
| 3 | `03_data_models_and_helpers.md` | `models.py`, `money.py`, `names.py`, `schema.py` |
| 4 | `04_synthetic_data_generation.md` | `patterns.py` and `generator.py` — how fake customers are built |
| 5 | `05_feature_engineering.md` | `features.py` — where "Python counts" happens |
| 6 | `06_templates_and_dataset.md` | `templates.py` and `dataset.py` — turning numbers into text |
| 7 | `07_rules_baseline.md` | `rules.py` and `metrics.py` — the baseline that beat the model |
| 8 | `08_llm_and_transformer_basics.md` | Background: tokens, attention, instruction tuning |
| 9 | `09_lora_qlora_peft_nf4.md` | The fine-tuning theory, tied to your exact configuration |
| 10 | `10_prompt_and_finetuning_code.md` | `prompt.py` and `finetune.py`, line by line |
| 11 | `11_inference_and_guardrails.md` | `predict.py` and the output checker in `schema.py` |
| 12 | `12_evaluation_and_results.md` | `evaluate.py` and an honest reading of every number |
| 13 | `13_investigation_workflow.md` | `investigator.py`, `case_store.py`, `case_note.py`, `audit.py` |
| 14 | `14_streamlit_app.md` | `app.py`, `review.py`, `review_scores.py` |
| 15 | `15_testing.md` | All 143 tests and what each file proves |
| 16 | `16_deployment.md` | `publish.py`, `build_space.py`, Streamlit Community Cloud |
| 17 | `17_aml_domain_concepts.md` | The financial-crime background |
| 18 | `18_python_concepts.md` | Every Python technique the project uses |
| 19 | `19_glossary.md` | Every term in one place |
| 20 | `20_interview_questions.md` | Questions with answers, grouped by chapter |
| 21 | `21_exercises.md` | Coding exercises with solutions |
| 22 | `22_live_run_and_evidence.md` | The live run, evidence links, and the data bug they found |

---

## Three corrections to the usual description

While inspecting the code I found three places where the common summary of this project is slightly wrong. Knowing these protects you in an interview.

**1. Numbers are grounded against the summary, not the transactions.** The check in `schema.py` is `numbers_in(reason) - numbers_in(summary)`. It compares the model's reason against *the text the model was given*, not against the raw transaction list. That is the correct design — it tests whether the model invented anything — but if you say "grounded against source transactions" and someone opens the file, the wording does not match.

**2. Step 4 reads a saved answer for the sample alerts, and a live one for uploads.** For the 1,000 alerts in `data/`, step 4 shows an answer produced earlier on a GPU and stored in `results/`, which is why the hosted demo needs no GPU. An alert uploaded in the Live run tab is classified there and then, by a model running on your laptop or on a hosted GPU. Chapter 22 covers that path. Be precise about which one you are showing.

**3. The workflow is deterministic, not agentic.** There is no planner, no tool-calling loop and no model deciding what to do next. `run_investigation` calls five functions in a fixed order. This was a deliberate choice and a good one — but it is not an autonomous agent, and the code makes that obvious.

---

## The numbers, verified

Re-run on 12 November 2026 with `python -m src.evaluate --final`:

| System | Macro-F1 test | Macro-F1 held-out | False alarms test / held-out |
| --- | --- | --- | --- |
| A1 rules, default thresholds | 0.962 | 0.948 | 8.1% / 14.2% |
| A2 rules, tuned on train | 0.990 | 0.990 | 0.0% / 1.7% |
| B base model, no training | 0.135 | 0.181 | 100% / 100% |
| C fine-tuned model | 1.000 | 0.936 | 0.0% / 8.3% |

The fine-tuned model matched the tuned rules on test and lost to them on held-out. Chapter 12 explains why in detail, and why that result is the most valuable thing in the project rather than a failure.

---

## How to use these notes

Read chapters 1 and 2 first, then follow the pipeline in order: 3 → 4 → 5 → 6 → 7 for the data half, then 8 → 9 → 10 → 11 → 12 for the model half, then 13 → 14 for the application, and 22 for the live run and evidence links added afterwards.

If you are revising for an interview and short of time: chapters 9, 11 and 12 carry the most weight, because fine-tuning internals, guardrails and honest evaluation are what a technical interviewer will dig into. Chapter 22 is next, because it is what you will be demonstrating on screen.

Each chapter ends with exercises. Do them in a scratch file; never edit the original source.
