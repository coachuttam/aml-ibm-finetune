# Chapter 18 — Python concepts used in this project

Every technique in the codebase, with the line that uses it.

---

## 18.1 Dataclasses

```python
@dataclass(frozen=True)
class Transaction:
    txn_id: str
    day: date
    amount: int
```

Generates `__init__`, `__repr__` and `__eq__` from the annotations. `frozen=True` makes instances immutable and hashable.

**Mutable defaults need a factory:**

```python
details: List[str] = field(default_factory=list)     # correct
details: List[str] = []                              # BUG: shared by every instance
```

A bare `[]` is evaluated once at class definition, so every instance shares the same list.

**Copying a frozen instance with changes:**

```python
from dataclasses import replace
replace(DEFAULT_CONFIG, just_under_min=5)
```

**Converting to a dictionary:**

```python
from dataclasses import asdict
asdict(case)      # recurses into nested dataclasses
```

Used in `save_case`, `append_event` and `build_example`.

Where to find them: `models.py`, `features.py`, `schema.py`, `rules.py`, `case_store.py`, `audit.py`, `review.py`, `names.py`, `generator.py`.

---

## 18.2 Type hints

```python
def ratio_to_income(amount: int, income: int) -> float:
def load_split(path: Path) -> List[dict]:
def last_checkpoint(output_dir: Path) -> Optional[str]:
GenerateFunction = Callable[[str], str]
```

Hints are not enforced at runtime. They exist for readers and for tools (mypy, your editor).

`Optional[str]` means `str` or `None`. `Callable[[str], str]` means a function taking one string and returning a string — used in `predict.py` to define what a "generate function" is, which is what lets tests pass fakes.

### `from __future__ import annotations`

Every file starts with it. It makes all annotations strings at runtime rather than evaluated expressions.

Two benefits:

1. You can use newer syntax (`list[str]`, `X | Y`) in annotations on older Pythons, because they are never evaluated.
2. Forward references work — a class can refer to itself in a hint.

`AGENTS.md` explains the real reason:

> Python 3.9+ compatible, because the owner's Mac environment may be 3.9 while Colab is newer: start files with `from __future__ import annotations`, use `typing.List` and `Optional`, and avoid `match` statements and `X | Y` unions at runtime.

The project still uses `typing.List` rather than `list[str]` in some places, because those appear in positions that *are* evaluated — such as dataclass field types processed by `dataclasses`.

---

## 18.3 Comprehensions

```python
# list
credits = [t for t in raw.transactions if t.direction == "credit"]

# nested (outer loop first)
[f"{first} {last}" for first in self.first_names for last in self.last_names]

# set — discards duplicates
senders = len({c.counterparty for c in span})

# dict
{row["alert_id"]: row for row in rows}

# generator — no list built
sum(c.amount for c in cash)
```

**When not to use one.** `AGENTS.md` says: *"Prefer simple loops and clear `if` statements over dense one-liners and nested comprehensions."* The codebase keeps comprehensions to one level in almost every case. `all_configs()` in `rules.py` is the one dense exception, and it is commented.

**Generator versus list.** `sum(c.amount for c in cash)` streams; `sum([c.amount for c in cash])` builds a list first. For small data the difference is negligible; the generator is the better habit.

---

## 18.4 Dispatch tables

```python
INCOME_ADDERS: Dict[str, Callable] = {
    "salaried employee": add_salary,
    "shopkeeper": add_shop_receipts,
    ...
}

INCOME_ADDERS[customer.occupation](ledger, rng, customer, start, end, pool)
```

Functions are values. Store them in a dict, look one up, call it.

Replaces an `if/elif` chain. Adding a case is one line; the full set of options is visible in one place; there is no chance of a missing branch. A missing key raises `KeyError`, which here is the desired behaviour.

Four in the project: `INCOME_ADDERS`, `TYPOLOGY_PLANTERS`, `HARD_NEGATIVE_PLANTERS`, plus a value-dispatch version in `risk_level`.

---

## 18.5 Unpacking

```python
# dictionary into keyword arguments
Customer(**data["customer"])
return Features(..., **cash, **large, **senders, **returns)

# iterable into positional arguments
rng.randint(*age_range)
product(*(GRID[name] for name in names))

# tuple unpacking
day, _, amount, direction, channel, counterparty = row
best, most_senders = span, senders
start, end = raw_text.find("{"), raw_text.rfind("}")
```

`_` is the conventional name for a value you are deliberately discarding.

Duplicate keys across two `**` unpackings raise `TypeError`, which is why the four feature helpers must return disjoint key sets.

---

## 18.6 f-strings and format specs

```python
f"{self.alert_id}-T{number:03d}"        # zero-padded to 3 digits
f"{'typology':<20}{'low':>6}"           # left-align 20, right-align 6
f"macro-F1 {result['macro_f1']:.3f}"    # 3 decimal places
f"{rate:6.1%}"                          # percentage, 1 decimal, width 6
f"{word!r}"                             # repr() rather than str()
```

The spec after `:` controls formatting: alignment (`<` `>` `^`), width, precision (`.3f`), and type (`d`, `f`, `%`).

`{rate:.1%}` multiplies by 100 and adds the sign, so `0.083` prints as `8.3%`.

---

## 18.7 Paths with `pathlib`

```python
ROOT = Path(__file__).resolve().parent.parent
DATA_FOLDER = ROOT / "data"
path = DATA_FOLDER / f"{split}.jsonl"

path.exists()
path.parent.mkdir(parents=True, exist_ok=True)
path.read_text(encoding="utf-8")
path.write_text(content, encoding="utf-8")
folder.glob("*.json")
```

`/` is overloaded to join paths, and it works on every operating system. Far cleaner than `os.path.join`.

`Path(__file__).resolve().parent.parent` is the project root from inside `src/`: the file, made absolute, up to `src/`, up to the root. This is why scripts work regardless of the directory you run them from.

`with log_path.open("a", encoding="utf-8") as f:` — append mode, and the `with` block closes the file even on an exception.

---

## 18.8 Modules, packages and `__main__`

```python
def main() -> None:
    ...

if __name__ == "__main__":
    main()
```

`__name__` is `"__main__"` when the file is run directly and the module name when imported. The guard means `python -m src.generator` runs `main()` while `from src.generator import generate_all` does not.

`src/__init__.py` is empty but present — it makes `src` a package so `from src.models import Customer` works.

`python -m src.generator` runs the module as a script with the project root on the path, which is why the imports resolve. Running `python src/generator.py` would fail.

**Lazy imports:**

```python
def load_model_and_tokenizer(base_model: str):
    import torch
    from peft import LoraConfig, get_peft_model
    from transformers import AutoModelForCausalLM
```

Imports inside the function, not at module level, because those libraries are only installed on Colab. This is what lets the test suite import `finetune.py` on a laptop.

---

## 18.9 Exceptions

```python
class GuardrailError(Exception):
    """Raised when text contains a word we never use about a customer."""

class DecisionError(Exception):
    """Raised when an analyst decision is incomplete or not allowed."""

class ExportBlockedError(Exception):
    """Raised when someone tries to export a case before the analyst has decided."""
```

Custom exception types let callers catch exactly what they mean:

```python
try:
    record_decision(alert, case, action.lower(), typology, risk, note)
except DecisionError as problem:
    st.error(str(problem))
```

Catching `Exception` here would also swallow bugs. Catching `DecisionError` catches only the thing the UI knows how to report.

**Converting one to another:**

```python
try:
    assert_clean_wording(note)
except GuardrailError as problem:
    raise DecisionError(str(problem))
```

The caller only needs to know about `DecisionError`.

**`raise SystemExit(message)`** in `publish.py` exits with a useful message and a non-zero status.

---

## 18.10 Closures and higher-order functions

```python
def load_model(adapter_folder, base_model=BASE_MODEL):
    model = ...        # expensive
    tokenizer = ...

    def generate_batch(summaries):
        ...uses model and tokenizer...

    def generate(summary):
        return generate_batch([summary])[0]

    return generate, generate_batch
```

The inner functions **close over** `model` and `tokenizer` — they keep access to those variables after `load_model` returns. Callers receive two plain functions and never touch the model.

Functions taking functions:

```python
def classify_with_retry(summary: str, generate: GenerateFunction) -> CheckedAnswer:
def predict_split(examples, generate, generate_batch=None, batch_size=BATCH_SIZE):
```

And a lambda as an argument:

```python
data_collator=lambda batch: pad_batch(batch, tokenizer.pad_token_id)
sorted(..., key=lambda item: (-item[1], item[0]))
```

---

## 18.11 Sorting

```python
# stable sort, twice, to mix directions
by_date = sorted(alerts, key=lambda a: a.window_end, reverse=True)
return sorted(by_date, key=lambda a: RISK_ORDER.get(a.model_risk, 3))

# tuple key: descending by amount, ascending by name
sorted(totals.items(), key=lambda item: (-item[1], item[0]))

# numeric sort on text that looks numeric
sorted(output_dir.glob("checkpoint-*"), key=lambda p: int(p.name.split("-")[1]))
```

Python's sort is **stable**: equal keys keep their relative order. That is what makes the two-pass sort work.

The checkpoint sort is the classic trap — alphabetically, `checkpoint-1000` comes before `checkpoint-200`.

---

## 18.12 Sets

```python
numbers_in(reason) - numbers_in(summary)      # difference
set(templates) == set(HELDOUT_TEMPLATES)      # equality
if credit.txn_id in used:                      # membership, O(1)
{c.counterparty for c in span}                 # deduplicate
```

Set difference is the entire faithfulness check. Set equality is how template separation is tested. Membership is O(1), which is why `used` is a set and not a list.

---

## 18.13 `defaultdict` and `Counter`

```python
totals: Dict[str, int] = defaultdict(int)
for debit in debits:
    totals[debit.counterparty] += debit.amount     # no "if key not in" needed

mix = Counter((e["label"]["typology"], e["label"]["risk"]) for e in examples)
```

`defaultdict(int)` supplies `0` for a missing key. `Counter` counts occurrences; its keys can be tuples.

---

## 18.14 Truthiness and the `or` idiom

```python
if income else 0.0              # 0 is falsy
if just_under else 0            # empty list is falsy
assert not missing              # empty set is falsy
valid = not problems            # empty list is falsy

kind or "ordinary"              # None → "ordinary"
limit or 300                    # None → 300
alert.window_end or 'not available'
```

Falsy values: `False`, `None`, `0`, `""`, `[]`, `{}`, `set()`.

`a or b` returns `a` if truthy, otherwise `b`. Convenient — and a trap when `0` is a legitimate value, because `0 or 300` gives 300.

---

## 18.15 Chained comparison and `any` / `all`

```python
if low <= c.amount <= high:                    # evaluated once, both bounds
if 0 < gap <= RETURN_DAYS and ...

any(word in reason.lower() for word in BANNED_WORDS)
any(step.status == "needs_review" for step in steps)
```

`any` and `all` short-circuit, so they stop at the first decisive element.

---

## 18.16 Slicing

```python
train_examples = load_split(...)[:limit]        # first N; None means all
ranked[:TOP_PAYEES]                              # safe past the end
examples[start:start + batch_size]               # safe past the end
table.iloc[::-1]                                 # reverse (pandas)
output[:, inputs["input_ids"].shape[1]:]         # 2-D tensor slice (PyTorch)
raw_text[start:end + 1]
```

Slicing never raises for out-of-range indices, which is why the final partial batch needs no special case.

`[:None]` returns everything, which is why `[:limit]` works when `limit` is `None`.

---

## 18.17 Randomness and determinism

```python
rng = random.Random(f"{SEED}:{plan.name}:{index}")
random.Random(alert_id).choice(options)
```

`random.Random(seed)` creates an **independent** generator. Separate instances do not interfere — which is what makes each alert reproducible on its own.

Using the global `random.choice` would couple every alert to every other one through a shared stream.

Methods used: `randint(a, b)` (inclusive both ends), `uniform(a, b)` (float), `random()` (0 to 1), `choice(seq)`, `sample(seq, k)` (distinct), `shuffle(list)` (in place).

---

## 18.18 Regular expressions

```python
re.findall(r"\d[\d,]*", text)
```

`\d` a digit, `[\d,]*` any run of digits and commas. `r"..."` is a raw string so backslashes are not escape sequences — always use raw strings for regexes.

`findall` returns every non-overlapping match as a list.

---

## 18.19 Ceiling division

```python
steps_per_epoch = -(-example_count // (BATCH_SIZE * ACCUMULATION_STEPS))
```

`//` floors. Negating, flooring and negating again gives the ceiling. `-(-2401 // 16)` = 151, while `2401 // 16` = 150.

The modern alternative is `math.ceil(a / b)`, which is clearer but introduces float division. For integers, the negation trick is exact.

---

## 18.20 Testing idioms

```python
@pytest.fixture(scope="module")
def dataset(raw_alerts):
    return build_dataset(raw_alerts)

def test_a_saved_dataset_loads_back_unchanged(dataset, tmp_path):
```

Fixtures are requested by parameter name. `scope="module"` builds once per file. `tmp_path` is built in and gives a fresh temporary directory per test.

```python
assert not missing, f"{example['alert_id']}: reason uses {missing}"
```

The second argument to `assert` is the failure message.

---

## 18.21 Exercises

1. Write a dataclass with a mutable default the wrong way, create two instances, mutate one, and observe the bug.
2. Convert the `INCOME_ADDERS` dispatch table into an `if/elif` chain. Which is easier to extend, and why?
3. Explain `-(-a // b)` to someone who knows `//`. Verify it for a=10,b=3 and a=9,b=3.
4. Why does `sort_for_queue` use two sorts? Write the single-key version and explain the problem.
5. Find three places where `or` provides a default. For each, say what happens if the value is legitimately `0`.
6. Rewrite `numbers_in` without a regex. Is it clearer?
7. Explain closures using `load_model` as the example, in three sentences.
