# Chapter 6 — Turning numbers into text (`templates.py`, `dataset.py`)

The model cannot read a `Features` object. It reads English. This chapter covers the step that turns thirty numbers into a paragraph, and the step that assembles the final training files.

---

## 6.1 Why five templates exist

```python
SHARED_TEMPLATES = ["digest", "prose", "terse"]
HELDOUT_TEMPLATES = ["report", "bullets"]
```

Three wordings are used by train, validation and test. Two are reserved for the held-out set and appear nowhere else.

The reason is the single most important methodological idea in the project. If every alert were phrased identically, a model could learn the phrasing rather than the pattern — for example, that the word "just under" followed by a number above 8 means structuring. It would score beautifully on test and fall apart on anything written differently.

Reserving two templates creates a measurement: **how much of the model's performance was pattern recognition, and how much was phrase matching?** The answer, from Chapter 12, is 1.000 on familiar wording and 0.936 on unfamiliar wording. That 0.064 gap is the price of the shortcut the model took, and it is only visible because these two templates were held back.

`AGENTS.md` locks them:

> The two held-out wording templates (`report` and `bullets` in `templates.py`) are fixed: do not edit them after seeing any result.

---

## 6.2 How a template is structured

Each template is a dictionary of named pieces of wording:

```python
TEMPLATES: Dict[str, Dict[str, str]] = {
    "digest": {
        "header": "",
        "joiner": "\n",
        "profile": "Customer: {occupation}, declared monthly income {income}, account open {age} months.",
        "cash": "Cash: {cash_deposits} totalling {cash_total}; just under the {limit} limit: {just_under_count} ...",
        "cash_plain": "Cash: {cash_deposits} totalling {cash_total}; none just under the {limit} limit.",
        "cash_none": "Cash: no deposits.",
        "inflows": "Large credits: {large_count} of {large_min} or more, ...",
        "inflows_none": "Large credits: none of {large_min} or more.",
        "senders": "Senders: {sender_count} different senders paid in {sender_total} ...",
        "senders_none": "Senders: fewer than 3 different senders in any {sender_window} days.",
        "returns": "Returned money: {return_payments} of {return_min} or more came back ...",
        "returns_none": "Returned money: none.",
        "payees": "Biggest payees: {payees}.",
        "totals": "Total in {credits_total} ({credits_ratio}x monthly income), total out {debits_total}.",
    },
    ...
}
```

Every template has the same twelve keys. Three of the five sections come in three variants — full, plain and none — because "Cash: no deposits" reads better than "Cash: 0 deposits totalling ₹0; just under the ₹50,000 limit: 0 (₹0, 0.0x monthly income) over 0 days".

A test enforces the uniformity:

```python
def test_every_template_defines_every_piece_of_wording():
    expected_keys = set(TEMPLATES["digest"])
    assert set(TEMPLATES) == set(SHARED_TEMPLATES) | set(HELDOUT_TEMPLATES)
    for name, template in TEMPLATES.items():
        assert set(template) == expected_keys, f"{name} is missing or has extra wording"
```

Adding a sixth template without all twelve keys fails immediately rather than crashing later with a `KeyError` on one unlucky alert.

### The same facts, five ways

Here is the profile line in all five:

| Template | Wording |
| --- | --- |
| `digest` | `Customer: {occupation}, declared monthly income {income}, account open {age} months.` |
| `prose` | `The customer is a {occupation} with a declared monthly income of {income}; the account is {age} months old.` |
| `terse` | `{occupation} \| income {income}/month \| account {age} months` |
| `report` | `Profile — {occupation}; stated income {income} a month; account age {age} months` |
| `bullets` | `- Holder works as: {occupation}. Monthly income on file: {income}. Account has existed for {age} months.` |

The held-out pair also changes vocabulary, not just layout: "lodgements" instead of "deposits", "remitters" instead of "senders", "just beneath the threshold" instead of "just under the limit". That is a harder test than reformatting alone — the model has to map unfamiliar words onto familiar concepts.

`report` and `bullets` are the only templates with a non-empty `header` (`"ALERT REVIEW"` and `"Review notes:"`), another surface difference.

---

## 6.3 `template_context` — one dictionary of ready-made strings

```python
def template_context(features: Features) -> Dict[str, str]:
    """Every placeholder value, already written out as text."""
    f = features
    payees = ", ".join(f"{name} {format_rupees(amount)}" for name, amount in f.top_payees)
    return {
        "occupation": f.occupation,
        "income": format_rupees(f.income),
        "age": str(f.account_age_months),
        "limit": format_rupees(CASH_REPORTING_LIMIT),
        "cash_count": str(f.cash_count),
        "cash_deposits": plural(f.cash_count, "cash deposit"),
        "cash_total": format_rupees(f.cash_total),
        ...
    }
```

Everything is converted to a string **here**, once, rather than inside each template. Amounts go through `format_rupees`, counts that need a noun go through `plural`.

Note two entries for the same underlying number:

- `"cash_count": str(f.cash_count)` → `"11"`
- `"cash_deposits": plural(f.cash_count, "cash deposit")` → `"11 cash deposits"`

The `terse` template uses `{cash_count}` because it writes `count 11`; `prose` uses `{cash_deposits}` because it writes `They made 11 cash deposits`. Both are available and each template picks what fits its grammar.

`", ".join(f"{name} {format_rupees(amount)}" for ...)` builds `"Meena Patel ₹4,29,000, ATM withdrawal ₹17,000, Landlord ₹5,000"` from the list of `(name, amount)` tuples. `join` with a generator expression is the idiomatic way to build a delimited string in Python; repeated `+=` on a string is slower and uglier.

---

## 6.4 `section_keys` — choosing which variant to use

```python
def section_keys(features: Features) -> List[str]:
    """For each section, which wording applies: full, plain or none."""
    f = features
    cash = "cash" if f.just_under_count else ("cash_plain" if f.cash_count else "cash_none")
    return [
        "profile",
        cash,
        "inflows" if f.large_count else "inflows_none",
        "senders" if f.sender_count >= 3 else "senders_none",
        "returns" if f.return_count else "returns_none",
        "payees",
        "totals",
    ]
```

Seven sections, always in the same order. The cash line is a nested conditional expression, which reads as:

- any just-under deposits → the full `cash` line
- otherwise, any cash at all → `cash_plain`
- otherwise → `cash_none`

`if f.just_under_count` works because `0` is falsy. Writing `if f.just_under_count > 0` would be equivalent and arguably clearer; the project chose the shorter form consistently.

`f.sender_count >= 3` uses the `MIN_SENDERS` idea, though here the literal 3 is inlined rather than using the constant — a small inconsistency with the project's own no-magic-numbers rule. Worth spotting; it is the kind of thing a reviewer notices.

A test pins the structure:

```python
def test_the_section_list_always_covers_profile_to_totals():
    keys = section_keys(features)
    assert keys[0] == "profile" and keys[-1] == "totals" and len(keys) == 7
```

---

## 6.5 `render_summary`

```python
def render_summary(template_id: str, features: Features) -> str:
    template = TEMPLATES[template_id]
    context = template_context(features)
    lines = [template[key].format(**context) for key in section_keys(features)]
    body = template["joiner"].join(lines)
    return f"{template['header']}\n{body}" if template["header"] else body
```

Four lines doing four things: pick the template, build the values, format each section, join with the template's joiner.

`template[key].format(**context)` unpacks the context dictionary as keyword arguments to `str.format`. A template referring to `{unknown_key}` raises `KeyError`; one that ignores a key is fine. So the context can be a superset of what any single template needs, which is exactly how it is designed.

The joiner differs per template: `"\n"` for digest, report and bullets, `" "` for prose (one paragraph), `" | "` for terse (one line).

### Deliberate omission

From `ARCHITECTURE.md`:

> **No shortcuts in the text.** Summaries never state the number of transactions, which would separate ordinary alerts from patterns by length alone.

A mule alert has 10–25 extra transactions; an ordinary one does not. Printing the count would let the model classify on that single number. It is excluded, and a test enforces it:

```python
def test_summaries_never_give_the_number_of_transactions(dataset):
    for example in all_examples(dataset):
        assert "transaction" not in example["summary"].lower()
```

A crude but effective test: the word never appears, so the number cannot.

---

## 6.6 Choosing a template deterministically

```python
def pick_template(alert_id: str, template_group: str) -> str:
    options = HELDOUT_TEMPLATES if template_group == "heldout" else SHARED_TEMPLATES
    return random.Random(alert_id).choice(options)
```

The same per-alert seeding idea as the generator, with the alert id itself as the seed. Alert `A-test-0308` always gets `terse`, every time the dataset is rebuilt, on any machine.

`template_group` comes from the `SplitPlan`, so held-out alerts can only ever draw from the reserved pair. The separation is structural — not a filter applied afterwards, but a different set of options.

A test proves it from the data side:

```python
def test_heldout_uses_only_reserved_templates_and_no_other_split_does(dataset):
    for split in SPLITS:
        templates = {example["template_id"] for example in dataset[split]}
        if split == "heldout":
            assert templates == set(HELDOUT_TEMPLATES)
        else:
            assert templates == set(SHARED_TEMPLATES)
```

Equality, not subset. Held-out uses *both* reserved templates and *only* those; the others use all three shared ones and none of the reserved ones.

---

## 6.7 `dataset.py` — assembling the training example

```python
def build_example(raw: RawAlert) -> dict:
    """One training example: what the model reads, and the answer it should give."""
    features = compute_features(raw)
    template_id = pick_template(raw.alert_id, raw.template_group)
    feature_values = asdict(features)
    # Store payees as lists, which is what a JSON file gives back.
    feature_values["top_payees"] = [list(payee) for payee in features.top_payees]
    return {
        "alert_id": raw.alert_id,
        "customer_id": raw.customer.customer_id,
        "split": raw.split,
        "template_id": template_id,
        "hard_negative_kind": raw.hard_negative_kind,
        "summary": render_summary(template_id, features),
        "label": {
            "typology": raw.typology,
            "risk": risk_level(raw.typology, features),
            "reason": reason_for(raw, features),
        },
        "features": feature_values,
    }
```

The whole pipeline in one function: compute, pick wording, render, label.

### The tuple-to-list line

```python
feature_values["top_payees"] = [list(payee) for payee in features.top_payees]
```

`asdict` converts the dataclass to a dictionary, but `top_payees` is a list of tuples. JSON has no tuple type — `json.dumps` writes tuples as arrays, and `json.loads` reads arrays back as **lists**. So saving and reloading would turn `[("Meena Patel", 429000)]` into `[["Meena Patel", 429000]]`, and the two would not compare equal.

Converting to lists up front makes the in-memory object match what a round trip produces, which is what lets this test pass:

```python
def test_a_saved_dataset_loads_back_unchanged(dataset, tmp_path):
    save_dataset(dataset, tmp_path)
    for split in SPLITS:
        assert load_split(tmp_path / f"{split}.jsonl") == dataset[split]
```

A one-line fix for a class of bug that is genuinely hard to find later.

### Why features are saved at all

The model never sees the `features` block — it only reads `summary`. But three other consumers need it:

- `rules.py` classifies directly from `features`, so the baseline needs them.
- `case_note.py` writes the findings from `features`.
- the app's evidence table and header read them.

Storing the computed values alongside the text means none of those has to re-run the generator.

### Saving

```python
def save_dataset(dataset, folder: Path) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    for split, examples in dataset.items():
        lines = [json.dumps(example, sort_keys=True, ensure_ascii=False) for example in examples]
        (folder / f"{split}.jsonl").write_text("\n".join(lines) + "\n", encoding="utf-8")
```

`ensure_ascii=False` is essential here. By default `json.dumps` escapes non-ASCII characters, so `₹` would be written as `₹`. The file would still be valid JSON, but unreadable to a human opening it. With `ensure_ascii=False` the rupee sign is written as itself — and `encoding="utf-8"` is then required, explicitly, because the default encoding differs between operating systems.

`mkdir(parents=True, exist_ok=True)` creates the folder and any missing parents, and does not complain if it already exists. The `pathlib` equivalent of `mkdir -p`.

### A small reporting function

```python
def print_training_summary(examples: List[dict]) -> None:
    mix = Counter((e["label"]["typology"], e["label"]["risk"]) for e in examples)
    print(f"{'typology':<20}{'low':>6}{'medium':>8}{'high':>6}")
    for typology in sorted({typology for typology, _ in mix}):
        counts = [mix[(typology, risk)] for risk in ("low", "medium", "high")]
        print(f"{typology:<20}{counts[0]:>6}{counts[1]:>8}{counts[2]:>6}")
```

`Counter` counts occurrences of each `(typology, risk)` pair. `{'low':>6}` right-aligns in six characters; `{'typology':<20}` left-aligns in twenty. This prints the table that tells you whether every pattern has a spread of risk levels — which a test also checks:

```python
def test_the_training_set_has_every_risk_level_for_every_pattern(dataset):
    for typology in TYPOLOGIES:
        levels = {e["label"]["risk"] for e in dataset["train"] if e["label"]["typology"] == typology}
        assert levels == set(RISK_LEVELS), f"{typology} has only {levels}"
```

This is how the lopsided-risk bug in the README's problems table was caught: with cut-offs of 3 and 10, some typology had no low-risk examples at all. The cut-offs moved to 5 and 15.

---

## 6.8 The test that ties the whole pipeline together

```python
def test_every_reason_uses_only_numbers_found_in_its_summary(dataset):
    for example in all_examples(dataset):
        missing = numbers_in(example["label"]["reason"]) - numbers_in(example["summary"])
        assert not missing, f"{example['alert_id']}: reason uses {missing} which the summary does not show"
```

This runs over all 3,400 examples and asserts that the ground-truth reason never contains a number absent from the summary.

Why it matters: it validates the *training targets*, not the model. If a target reason mentioned a number the summary did not show, you would be training the model to invent numbers — and then the faithfulness check at inference would be punishing it for doing what it was taught. This test makes the guardrail and the training data consistent.

Set subtraction (`a - b`) gives elements in `a` but not in `b`. An empty set is falsy, so `assert not missing` passes when nothing is missing.

---

## 6.9 Exercises

1. Pick an alert from `data/test.jsonl` and find its `template_id`. Re-render the same features with each of the other two shared templates and compare.
2. Add a sixth template with only eleven keys. Which test fails, and what is the message?
3. Why does `template_context` convert everything to strings? What happens in `.format()` if you pass an `int`? (Try it — then work out why doing it in one place is still better.)
4. Write a script that counts how many alerts in each split use each template. Are the three shared templates evenly distributed? Should they be?
5. Remove `ensure_ascii=False` from `save_dataset`, rebuild into a temporary folder, and look at the file. Does the round-trip test still pass? Does the file still read well?
6. Explain to someone non-technical why two templates are hidden from training, in under thirty seconds.
