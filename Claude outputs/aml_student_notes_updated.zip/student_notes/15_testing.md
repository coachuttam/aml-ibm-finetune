# Chapter 15 — Testing (143 tests)

```bash
$ python -m pytest -q
143 passed in 4.6s
```

| File | Tests | Covers |
| --- | --- | --- |
| `test_features.py` | 26 | feature maths, risk levels, templates, the whole dataset |
| `test_generator.py` | 20 | determinism, split separation, patterns |
| `test_investigator.py` | 17 | the six steps, decisions, exports |
| `test_live.py` | 17 | uploads, the live model, failing safe (chapter 22) |
| `test_evidence.py` | 10 | findings linked to rows, and agreement with the features (chapter 22) |
| `test_review.py` | 8 | the app's data layer |
| `test_predict.py` | 10 | checking and retry, with fake models |
| `test_rules.py` | 8 | the baseline and its tuning |
| `test_prompt.py` | 6 | prompt format and loss masking |
| `test_audit_and_cases.py` | 5 | the log and case memory |
| `test_build_space.py` | 5 | the deployment build |
| `test_publish.py` | 4 | the Hugging Face upload |
| `test_metrics.py` | 4 | precision, recall, F1 |
| `test_evaluate.py` | 3 | scoring and reporting |

Three and a half seconds for the whole suite, with no GPU, no network and no browser.

---

## 15.1 Test names are sentences

From `AGENTS.md`:

> Test names read as sentences: `test_split_never_puts_a_customer_in_two_sets`.

Real examples from the suite:

```
test_deposits_just_under_the_limit_are_counted_with_their_span
test_money_moved_to_the_customers_own_deposit_is_not_counted_as_sent_on
test_a_burst_of_senders_is_found_even_when_regular_payouts_continue_all_month
test_cash_withdrawals_and_deposits_are_never_treated_as_returned_payments
test_heldout_uses_only_reserved_templates_and_no_other_split_does
test_the_app_text_never_uses_accusing_words
test_a_public_host_is_recognised_so_the_shared_demo_notice_can_show
```

Each name is a claim about the system. Read the list of test names and you have read a specification. When one fails, the name tells you what broke without reading the body.

Compare with `test_features_1`, `test_edge_case`, `test_bug_fix`. The habit costs nothing and pays every time a test fails.

---

## 15.2 The four kinds of test here

### 1. Maths on tiny hand-built inputs

```python
def test_deposits_just_under_the_limit_are_counted_with_their_span():
    ledger = Ledger("A-test")
    for offset in (3, 4, 6):
        ledger.credit(day(offset), 45_000, "cash", "Cash deposit")
    ledger.credit(day(10), 5_000, "cash", "Cash deposit")        # ordinary, far below the limit
    features = compute_features(make_alert(ledger))
    assert features.cash_count == 4
    assert features.just_under_count == 3
    assert features.just_under_total == 135_000
    assert features.just_under_span_days == 4                   # day 3 to day 6, both included
```

Four transactions, four assertions, every expected value computable in your head. The comment on the last line documents the inclusive-span decision at the exact point it is tested.

This is the right shape for testing numeric logic: construct the smallest input that exercises the rule, assert the exact answer. No fixtures, no randomness, no reliance on generated data.

The same file tests each boundary deliberately:

```python
def test_money_sent_after_the_two_day_limit_is_not_a_quick_exit():
    ledger.credit(day(5), 200_000, "neft", "Sharma Traders")
    ledger.debit(day(9), 190_000, "neft", "Patel Stores")       # four days later
    assert compute_features(make_alert(ledger)).quick_exit_percent == 0
```

Day 6 counts, day 9 does not. Both sides of the threshold are pinned.

### 2. Properties over the whole dataset

```python
@pytest.fixture(scope="module")
def raw_alerts():
    return generate_all()

@pytest.fixture(scope="module")
def dataset(raw_alerts):
    return build_dataset(raw_alerts)
```

A **fixture** is reusable setup. `scope="module"` means it is built once per file rather than once per test, so generating 3,400 alerts happens a single time. Fixtures are requested by naming them as test arguments — pytest matches by name.

Then properties are asserted across everything:

```python
def test_every_reason_uses_only_numbers_found_in_its_summary(dataset):
    for example in all_examples(dataset):
        missing = numbers_in(example["label"]["reason"]) - numbers_in(example["summary"])
        assert not missing, f"{example['alert_id']}: reason uses {missing} which the summary does not show"
```

Over all 3,400 examples. The failure message names the offending alert and the offending numbers, so a failure is immediately actionable.

```python
def test_each_pattern_is_visible_in_the_numbers(dataset):
    """If the numbers do not show the pattern, no model could be expected to find it."""
    for example in all_examples(dataset):
        f, typology = example["features"], example["label"]["typology"]
        if typology == "STRUCTURING":
            assert f["just_under_count"] >= 6
        elif typology == "RAPID_PASS_THROUGH":
            assert f["large_count"] >= 2 and f["quick_exit_percent"] >= 80
        elif typology == "MULE_ACCOUNT":
            assert f["sender_count"] >= 10
        elif typology == "ROUND_TRIPPING":
            assert f["return_count"] >= 2
```

This is an unusual and valuable test. It checks the **data**, not the code: every alert labelled with a pattern must actually show that pattern in its computed numbers. If the generator ever produced a structuring alert with only two just-under deposits, the label would be unlearnable — and this test fails before you waste a GPU hour discovering it.

The docstring says it exactly: *"If the numbers do not show the pattern, no model could be expected to find it."*

### 3. Methodology tests

These enforce the project's own rules, and they are the most distinctive thing in the suite.

```python
def test_heldout_uses_only_reserved_templates_and_no_other_split_does(dataset):
    for split in SPLITS:
        templates = {example["template_id"] for example in dataset[split]}
        if split == "heldout":
            assert templates == set(HELDOUT_TEMPLATES)
        else:
            assert templates == set(SHARED_TEMPLATES)
```

Equality in both directions. Held-out uses both reserved templates and only those; the others use all three shared ones and none of the reserved ones. A leak in either direction fails.

`test_generator.py` has twenty tests, and the ones that matter most assert that no customer appears in two splits and that held-out names never appear elsewhere.

```python
def test_tuning_uses_only_the_training_examples_it_is_given():
```

The grid search cannot reach beyond what it was handed.

```python
def test_summaries_never_give_the_number_of_transactions(dataset):
    for example in all_examples(dataset):
        assert "transaction" not in example["summary"].lower()
```

Blocks the length shortcut described in Chapter 6.

```python
def test_no_summary_or_reason_uses_accusing_words(dataset):
    for example in all_examples(dataset):
        text = (example["summary"] + " " + example["label"]["reason"]).lower()
        for word in BANNED_WORDS:
            assert word not in text
```

And the one that reads the user interface as a text file:

```python
def test_the_app_text_never_uses_accusing_words():
    from pathlib import Path
    from src.schema import BANNED_WORDS
    app_text = (Path(__file__).resolve().parent.parent / "app.py").read_text(encoding="utf-8").lower()
    for word in BANNED_WORDS:
        assert word not in app_text
```

Greps your own source for forbidden language. Crude, effective, and it catches the case where someone writes "possible fraud" into a caption months later.

**Why methodology tests matter.** Honest evaluation usually depends on discipline, and discipline erodes. These tests turn "we promised not to leak the held-out set" into "the build fails if we do". That is the difference between a claim and a guarantee, and it is worth saying in an interview: *"The discipline is in the test suite, not in my memory."*

### 4. Tests with fakes, so no GPU is needed

```python
# tests/test_predict.py — 10 tests, no torch, no model
```

The whole checking and retry path is tested by passing fake generate functions:

```python
def always_valid(summary):
    return '{"typology": "STRUCTURING", "risk": "high", "reason": "11 cash deposits."}'

def always_broken(summary):
    return "I think this is suspicious."

def fails_then_works(summary):
    # first call broken, second call fine
```

Because `predict.py` defines its dependency as a type —

```python
GenerateFunction = Callable[[str], str]
```

— anything matching that shape works. No mocking framework, no patching. The design made the test easy rather than the test framework making it possible.

The same idea covers loss masking: `test_prompt.py` uses a stub tokenizer to verify that prompt positions get `-100` and answer positions do not, without loading Qwen.

---

## 15.3 Temporary directories

```python
def test_a_saved_dataset_loads_back_unchanged(dataset, tmp_path):
    save_dataset(dataset, tmp_path)
    for split in SPLITS:
        assert load_split(tmp_path / f"{split}.jsonl") == dataset[split]
```

`tmp_path` is a built-in pytest fixture giving a fresh temporary directory per test, deleted afterwards. Tests never touch the real `data/` folder and never leave files behind.

This only works because every writing function takes its folder as a parameter:

```python
def save_dataset(dataset, folder: Path) -> None:
def save_case(case: Case, folder: Path = CASE_FOLDER) -> None:
def append_event(..., log_path: Path = AUDIT_LOG) -> AuditEvent:
```

**Dependency injection with defaults**: production uses the default, tests pass `tmp_path`. If these functions hard-coded their paths, testing them would mean patching module globals — fragile, and it leaks between tests.

There was a real incident here: an app test once wrote an `audit/` folder into the project and it had to be cleaned up. The fix was to pass the path.

---

## 15.4 Round-trip tests

```python
def test_building_the_dataset_twice_gives_identical_examples(raw_alerts, dataset):
    assert build_dataset(raw_alerts) == dataset
```

Determinism, asserted directly.

```python
def test_a_saved_dataset_loads_back_unchanged(dataset, tmp_path):
```

Serialisation is lossless. This is the test that caught the tuple-versus-list problem in Chapter 6 — `top_payees` came back from JSON as lists and would not compare equal to tuples. The fix was one line in `build_example`, and this test is why it was found at all rather than causing a confusing failure later.

Round-trip tests are cheap and catch a whole class of bug: *save then load must equal the original.*

---

## 15.5 What is not tested

Be honest about this; it is a likely question.

**No test of the model itself.** Nothing asserts that the fine-tuned model achieves any score. That would need a GPU and would make the suite slow and non-deterministic. Model quality is measured by `evaluate.py`, not by pytest — which is the right split, but it means a regression in model quality would not fail the build.

**No UI test.** `app.py` is only checked for banned words. No test clicks a button or verifies a rendered table. Streamlit testing exists (`streamlit.testing.v1`) but was not used.

**No end-to-end test** from `python -m src.generator` through to a decision in the app.

**No property-based testing.** A library like Hypothesis could generate random ledgers and assert invariants — for example, that `quick_exit_percent` is always between 0 and 100 for any input. That would probably find edge cases the hand-written tests miss.

**No coverage measurement.** There is no evidence of which lines are exercised.

A good answer if asked what you would add: *"Property-based tests on the feature maths, a coverage report, and one end-to-end test through the workflow. I would not add model-quality tests to the suite — that belongs in a separate evaluation job, because it needs a GPU and would make the fast suite slow."*

---

## 15.6 Why 143 tests on a portfolio project

Three reasons, and they are all worth saying:

1. **The data pipeline is the product.** A bug in `features.py` corrupts the training data, the rules baseline and the case notes simultaneously, and you would see it as a mysteriously poor model rather than as an error.

2. **The methodology claims need enforcing.** "We never tuned on held-out" is a claim a reader has to take on trust — unless a test asserts it.

3. **It makes the project safe to change.** Four of the bugs in the README's problems table were found or prevented by tests. Without them, each change to the generator would be a gamble.

And the interview line: **"143 tests, running in under five seconds with no GPU, and several of them test the methodology rather than the code."** That second clause is the one that makes people look up.

A fourth reason arrived later: the evidence tests in chapter 22 assert that two independent pieces of code — the feature counts and the evidence row lists — agree with each other. That is a test of *consistency between components*, which is harder to keep in your head than any single function.

---

## 15.7 Exercises

1. Run `python -m pytest -q` and time it. Then run `python -m pytest tests/test_features.py -v` and read the names as a specification.
2. Break `days_between` by removing the `+ 1`. Which tests fail, and do their names tell you what is wrong?
3. Write a test asserting that every alert's transactions are sorted by date.
4. Change one held-out template in a scratch copy. Which test catches it?
5. Write a property-based test (with or without Hypothesis) asserting `0 <= percent(a, b) <= 100` for any non-negative `a` and `b`.
6. Why is `scope="module"` used on the dataset fixture? What happens with the default scope?
7. Add an end-to-end test: generate, build, investigate, decide, and assert the audit log has six lines.
