# Chapter 4 — Synthetic data generation

Two files: `patterns.py` builds one customer's thirty days, `generator.py` decides what to build and does it 3,400 times.

---

## 4.1 The central design decision

Every alert is built in two layers:

```
Layer 1: everyday activity    income + rent + groceries + ATM withdrawals
Layer 2: one planted pattern  a typology, OR a legitimate look-alike, OR nothing
```

Nothing in `patterns.py` decides a label. The caller already knows which pattern it asked for, so the label is true *by construction*. This is what makes the data usable as ground truth — and also its deepest limitation, covered in Chapter 12.

The two-layer design matters because without layer 1, a "structuring" alert would be eleven cash deposits and nothing else, and any classifier could find it by noticing the account had no ordinary life. Burying the pattern in realistic noise is what makes the task non-trivial.

---

## 4.2 `Ledger` — collecting transactions in order

```python
class Ledger:
    """Collects the transactions of one alert and numbers them in date order."""

    def __init__(self, alert_id: str) -> None:
        self.alert_id = alert_id
        self._rows: List[Tuple[date, int, int, str, str, str]] = []

    def credit(self, day, amount, channel, counterparty) -> None:
        self._add(day, amount, "credit", channel, counterparty)

    def debit(self, day, amount, channel, counterparty) -> None:
        self._add(day, amount, "debit", channel, counterparty)

    def _add(self, day, amount, direction, channel, counterparty) -> None:
        # The insertion number keeps the order stable when two rows share a day.
        self._rows.append((day, len(self._rows), int(amount), direction, channel, counterparty))

    def finish(self) -> List[Transaction]:
        """Return the transactions sorted by date, with ids T001, T002, ..."""
        transactions = []
        for number, row in enumerate(sorted(self._rows), start=1):
            day, _, amount, direction, channel, counterparty = row
            txn_id = f"{self.alert_id}-T{number:03d}"
            transactions.append(Transaction(txn_id, day, amount, direction, channel, counterparty))
        return transactions
```

### The insertion number is the interesting line

`_rows` stores tuples of `(day, insertion_number, amount, direction, channel, counterparty)`. The insertion number is never used in the final `Transaction`; it is thrown away in `finish` (that is what the `_` does). So why store it?

Because `sorted()` on tuples compares element by element. Two transactions on the same day would compare their *second* element next. Without the insertion number, that would be the amount, so same-day rows would be ordered by size — and if two rows had the same day *and* amount, Python would compare the direction string, and so on.

With the insertion number second, same-day rows keep the order they were added in. That makes generation **stable**: the same seed always produces the same transaction ids. Without it, an unrelated change could silently reshuffle ids and break reproducibility.

This is a small line with a big purpose, and it is a good thing to be able to explain.

### `enumerate(..., start=1)` and `{number:03d}`

`enumerate` yields `(index, item)` pairs; `start=1` makes the first index 1 rather than 0, because transaction ids read better as T001 than T000.

`f"{number:03d}"` is format-spec syntax: `d` means integer, `3` means minimum width 3, `0` means pad with zeros. So 7 becomes `007`. Zero-padding matters because `T10` sorts before `T9` as text, while `T010` sorts after `T009` correctly.

### Why a class here, when the rest of the project is functions?

Because a ledger has **state** that many functions add to. Each planting function receives the same ledger and appends to it. A class is the natural container for "an object many callers mutate, then finalise". Elsewhere in the project, where data flows through transformations without shared state, plain functions are used.

---

## 4.3 Everyday activity

Seven occupations, each with its own income pattern:

```python
INCOME_ADDERS: Dict[str, Callable] = {
    "salaried employee": add_salary,
    "shopkeeper":        add_shop_receipts,
    "small trader":      add_shop_receipts,
    "freelancer":        add_freelance_payments,
    "student":           add_family_transfer,
    "homemaker":         add_family_transfer,
    "delivery driver":   add_weekly_payouts,
}
```

### Dispatch tables

This is a **dispatch table**: a dictionary mapping a key to a function. Instead of

```python
if customer.occupation == "salaried employee":
    add_salary(...)
elif customer.occupation == "shopkeeper":
    add_shop_receipts(...)
elif ...
```

you write

```python
INCOME_ADDERS[customer.occupation](ledger, rng, customer, start, end, pool)
```

The dictionary lookup returns the function, and the parentheses call it. Functions in Python are ordinary values you can store in containers — that is what makes this work.

Why it is better than the `if` chain: adding an occupation means adding one line to the table, there is no chance of forgetting an `elif`, and the whole set of options is visible in one place. The same pattern appears three more times in this file (`TYPOLOGY_PLANTERS`, `HARD_NEGATIVE_PLANTERS`) and in `features.py`.

The cost: a missing key raises `KeyError` instead of falling through to an `else`. Here that is a feature — an unknown occupation should be a loud failure.

### Every planter shares one signature

The module docstring says it:

> All planting functions share one signature so the generator can call them from a table: `plant_x(ledger, rng, customer, start, end, pool, scale)`.

`add_salary` does not use `end` or `pool`. `plant_structuring` does not use `scale`. They take them anyway, because a uniform signature is what lets the dispatch table work. This is a real trade-off: slightly redundant parameters in exchange for a uniform interface.

### An example: `add_shop_receipts`

```python
def add_shop_receipts(ledger, rng, customer, start, end, pool):
    """Many small customer payments, by UPI and a little cash."""
    count = rng.randint(10, 16)
    typical = customer.declared_monthly_income / count
    for _ in range(count):
        amount = round_to(typical * rng.uniform(0.6, 1.4), 100)
        if rng.random() < 0.7:
            ledger.credit(day_in(rng, start, end), max(amount, 100), "upi", "Customer receipts")
        else:
            ledger.credit(day_in(rng, start, end), min(max(amount, 100), EVERYDAY_CASH_CAP), "cash", "Cash deposit")
```

Line by line:

- `rng.randint(10, 16)` — between 10 and 16 payments, both ends included.
- `typical = income / count` — so the month's receipts add up to roughly the declared income. Without this, a shopkeeper's takings would have no relationship to their stated earnings and the income ratio features would be meaningless.
- `rng.uniform(0.6, 1.4)` — each payment varies between 60% and 140% of typical.
- `round_to(..., 100)` — rounded to the nearest ₹100, because real amounts are rarely ₹4,237.19.
- `rng.random() < 0.7` — 70% of receipts by UPI, 30% in cash.
- `max(amount, 100)` — never below ₹100.
- `min(..., EVERYDAY_CASH_CAP)` — **this is the important one.** `EVERYDAY_CASH_CAP = 0.70 * CASH_REPORTING_LIMIT` = ₹35,000. Ordinary cash deposits are capped below the "just under the limit" band of 80–99%. Without this cap, a prosperous shopkeeper's normal takings could land in the structuring band by accident and the label would be wrong.

That one `min()` is a data-quality guarantee holding the label space apart.

---

## 4.4 The four typologies

### Structuring

```python
def plant_structuring(ledger, rng, customer, start, end, pool, scale):
    """Many cash deposits just under the reporting limit, then most of it moved on."""
    count = rng.randint(6, 14)
    span = rng.randint(3, 8)
    first_day = day_in(rng, start, end - timedelta(days=span + 3))
    total = 0
    for _ in range(count):
        amount = round_to(CASH_REPORTING_LIMIT * rng.uniform(JUST_UNDER_LOW, JUST_UNDER_HIGH), 100)
        ledger.credit(first_day + timedelta(days=rng.randint(0, span)), amount, "cash", "Cash deposit")
        total += amount
    if rng.random() < 0.7:
        moved = round_to(total * rng.uniform(0.6, 0.9), 1_000)
        ledger.debit(first_day + timedelta(days=span + rng.randint(1, 3)), moved, "neft", pool.person(rng))
```

The real-world behaviour: someone with cash to deposit splits it into chunks below the threshold that triggers a report. Here, 6 to 14 deposits between 80% and 99% of ₹50,000 (so ₹40,000–₹49,500), inside a window of 3 to 8 days.

`end - timedelta(days=span + 3)` makes sure the burst starts early enough that the whole span, plus the money moving out afterwards, still fits inside the window.

The `if rng.random() < 0.7` means only 70% of structuring cases move the money on. Variety stops the model learning "cash deposits always followed by one big transfer".

**Note `scale` is unused here.** Structuring amounts are pinned to the reporting limit, which does not change with income. Pass-through and mule amounts do scale. This is a deliberate asymmetry.

### Rapid pass-through

```python
def plant_rapid_pass_through(ledger, rng, customer, start, end, pool, scale):
    day = day_in(rng, start, start + timedelta(days=8))
    for _ in range(rng.randint(2, 4)):
        amount = round_to(rng.uniform(150_000, 600_000) * scale, 1_000)
        ledger.credit(day, amount, rng.choice(["neft", "rtgs"]), pool.business(rng))
        out_day = day + timedelta(days=rng.randint(1, 2))
        ledger.debit(out_day, round_to(amount * rng.uniform(0.90, 0.99), 100), rng.choice(["neft", "rtgs"]), pool.business(rng))
        day += timedelta(days=rng.randint(2, 6))
```

Money arrives and 90–99% of it leaves within one or two days, to a different business. The account is a conduit. `day` advances inside the loop so the pairs do not overlap.

### Mule account

```python
def plant_mule_account(ledger, rng, customer, start, end, pool, scale):
    span = rng.randint(2, 5)
    first_day = day_in(rng, start, end - timedelta(days=span + 4))
    total = 0
    for sender in pool.people(rng, rng.randint(10, 25)):
        amount = round_to(rng.uniform(3_000, 25_000) * scale, 500)
        ledger.credit(first_day + timedelta(days=rng.randint(0, span)), amount, rng.choice(["upi", "imps"]), sender)
        total += amount
    cash_out_day = first_day + timedelta(days=span + 1)
    atm_total = 0
    for _ in range(rng.randint(3, 5)):
        ledger.debit(cash_out_day + timedelta(days=rng.randint(0, 1)), 10_000, "atm", "ATM withdrawal")
        atm_total += 10_000
    remaining = round_to(total * rng.uniform(0.90, 0.98), 1_000) - atm_total
    if remaining > 0:
        ledger.debit(cash_out_day + timedelta(days=2), remaining, "neft", pool.person(rng))
```

Ten to twenty-five different people pay small amounts into the account within a few days, then 90–98% is taken out — partly at ATMs in ₹10,000 chunks, the rest by transfer.

`pool.people(rng, count)` guarantees distinct senders (§3.3). The ATM withdrawals are fixed at ₹10,000 because that is a realistic daily cap.

There is a subtlety in `remaining`: it is the target cash-out minus what already left by ATM, and the `if remaining > 0` guard handles the case where the ATM withdrawals already covered it.

**Mules get young accounts.** In `generator.py`:

```python
MULE_ACCOUNT_AGE_MONTHS = (1, 6)
NORMAL_ACCOUNT_AGE_MONTHS = (12, 120)
```

Real mule accounts are often newly opened, and the generator encodes that. It also means account age is a genuine signal, which is why the summary includes it.

### Round-tripping

```python
def plant_round_tripping(ledger, rng, customer, start, end, pool, scale):
    day = day_in(rng, start, start + timedelta(days=4))
    for _ in range(rng.randint(2, 3)):
        amount = round_to(rng.uniform(100_000, 400_000) * scale, 1_000)
        ledger.debit(day, amount, "neft", pool.business(rng))
        back_day = day + timedelta(days=rng.randint(3, 6))
        ledger.credit(back_day, round_to(amount * rng.uniform(0.95, 1.0), 100), "neft", pool.business(rng))
        day = back_day + timedelta(days=rng.randint(1, 2))
```

Money goes out to one business and comes back, at 95–100% of the amount, from a *different* business three to six days later. The different counterparty is what makes it layering rather than a simple refund — and it is exactly what distinguishes it from the `repay_friend` hard negative below.

---

## 4.5 The hard negatives — the most valuable 45 lines in the file

Four kinds of legitimate activity that look suspicious:

```python
HARD_NEGATIVE_PLANTERS = {
    "cash_heavy_shop":         plant_cash_heavy_shop,
    "house_sale":              plant_house_sale,
    "salary_then_commitments": plant_salary_then_commitments,
    "repay_friend":            plant_repay_friend,
}
```

| Kind | Looks like | Why it is innocent |
| --- | --- | --- |
| `cash_heavy_shop` | structuring | 15–24 cash deposits, but all between 10% and 60% of the limit — never in the just-under band |
| `house_sale` | pass-through | one credit of ₹20–60 lakh, but 60–80% goes to the customer's **own** fixed deposit, not to a third party |
| `salary_then_commitments` | pass-through | salary in, then rent, loan EMI and SIP out within two days — to regular payees, in proportion to income |
| `repay_friend` | round-tripping | money lent and returned in full by **the same person** |

Each one isolates a single discriminating feature:

```python
def plant_house_sale(ledger, rng, customer, start, end, pool, scale):
    day = day_in(rng, start + timedelta(days=2), start + timedelta(days=10))
    amount = round_to(rng.uniform(2_000_000, 6_000_000) * scale, 10_000)
    ledger.credit(day, amount, "rtgs", pool.person(rng))
    deposit = round_to(amount * rng.uniform(0.60, 0.80), 10_000)
    ledger.debit(day + timedelta(days=rng.randint(3, 7)), deposit, "internal", "Own fixed deposit")
```

The `"internal"` channel is the whole trick. In `features.py`:

```python
external_debits = [d for d in debits if d.channel != "internal"]
```

Money moved to your own deposit is excluded from "sent on to other people", so `quick_exit_percent` stays at 0 and the pass-through rule does not fire. One channel name carries the entire distinction.

`plant_salary_then_commitments` is cleverer still:

```python
salary_day = ledger.first_day_with_channel("salary") or start
```

It reads the ledger to find when salary actually landed, then schedules the commitments one or two days later. The hard negative is *aware of* layer 1. This is why `Ledger` has a `first_day_with_channel` method at all.

Note also in `generator.py`:

```python
needs_rent = hard_negative_kind != "salary_then_commitments"
```

Rent is suppressed from the everyday expenses for this kind, because the hard negative adds its own rent payment. Without that, the customer would pay rent twice.

### Why hard negatives decide the project

Without them, "no concern" means "nothing much happened", and a model can score well by flagging anything busy. With them, the model must distinguish *eleven cash deposits just under ₹50,000* from *twenty cash deposits well under it*. The false-positive rates in Chapter 12 are measured per hard-negative kind, and that is where both the rules and the model show their real weaknesses:

- Default rules flag `salary_then_commitments` **80%** of the time on test.
- The fine-tuned model flags it **53%** of the time on held-out, having got it perfect on test.

Neither number would exist without these four functions.

---

## 4.6 `generator.py` — split plans

```python
@dataclass(frozen=True)
class SplitPlan:
    name: str
    per_typology: int          # alerts for each of the four patterns
    benign: int                # ordinary activity
    hard_negatives: int        # legitimate look-alikes, shared equally
    income_scale: float        # 1.0 normally, larger for held-out
    template_group: str        # which wording templates may describe these
    name_pool: NamePool


SPLIT_PLANS = {
    "train":      SplitPlan("train",      350, 700, 300, 1.0, "shared",  STANDARD_NAMES),
    "validation": SplitPlan("validation",  45,  80,  40, 1.0, "shared",  STANDARD_NAMES),
    "test":       SplitPlan("test",        60, 100,  60, 1.0, "shared",  STANDARD_NAMES),
    "heldout":    SplitPlan("heldout",     45,  60,  60, 1.6, "heldout", HELDOUT_NAMES),
}
```

Check the arithmetic:

| Split | 4 × per_typology | benign | hard negatives | total |
| --- | --- | --- | --- | --- |
| train | 1,400 | 700 | 300 | **2,400** |
| validation | 180 | 80 | 40 | **300** |
| test | 240 | 100 | 60 | **400** |
| held-out | 180 | 60 | 60 | **300** |
| | | | | **3,400** |

"No concern" alerts are benign + hard negatives: 1,000 of 2,400 in training, 160 of 400 in test. Deliberately the largest class, because in real AML work most alerts are not suspicious.

The held-out row differs in **three** ways at once: `income_scale` 1.6, the `heldout` template group, and a different name pool.

### Determinism: a seed per alert

```python
SEED = 42

def generate_alert(plan, index, typology, hard_negative_kind):
    rng = random.Random(f"{SEED}:{plan.name}:{index}")
```

This is the most important line in the file. Each alert gets its **own** random generator seeded from a string unique to that alert — `"42:test:307"` — rather than all alerts sharing one global stream.

Why it matters: with a single shared generator, adding one transaction to alert 5 shifts every random number drawn afterwards, so alerts 6 through 400 all change. Debugging becomes impossible and a one-line change produces a completely different dataset. With a per-alert seed, alert 307 depends only on its own seed, so changing one alert leaves every other one byte-identical.

`random.Random` accepts a string seed and hashes it internally. The ordering of recipes gets its own seed too:

```python
random.Random(f"{SEED}:{plan.name}:order").shuffle(recipes)
```

### Building the recipe list

```python
def build_recipes(plan):
    recipes = []
    for typology in TYPOLOGIES:
        recipes += [(typology, None)] * plan.per_typology
    recipes += [(NO_CONCERN, None)] * plan.benign
    for number in range(plan.hard_negatives):
        recipes.append((NO_CONCERN, HARD_NEGATIVE_KINDS[number % len(HARD_NEGATIVE_KINDS)]))
    random.Random(f"{SEED}:{plan.name}:order").shuffle(recipes)
    return recipes
```

`[(typology, None)] * 350` repeats a one-item list 350 times — a standard Python idiom.

The modulo in `HARD_NEGATIVE_KINDS[number % 4]` cycles through the four kinds: 0,1,2,3,0,1,2,3… so 60 hard negatives become 15 of each, exactly balanced. Clean and obviously correct.

**One caution with `*` on lists:** `[[]] * 3` creates three references to the *same* list, so appending to one appends to all. Here the repeated item is a tuple, which is immutable, so there is no problem. But it is a classic bug and worth knowing.

### Occupation constraints

```python
TYPOLOGY_OCCUPATIONS = {
    "STRUCTURING":        ALL_OCCUPATIONS,
    "RAPID_PASS_THROUGH": ALL_OCCUPATIONS,
    "MULE_ACCOUNT":       ["student", "homemaker", "delivery driver", "salaried employee"],
    "ROUND_TRIPPING":     BUSINESS_OCCUPATIONS,
    NO_CONCERN:           ALL_OCCUPATIONS,
}
```

Mule accounts skew to low-income occupations, as in real cases; round-tripping needs a business. This adds realism — but it also adds a **shortcut risk**: if only students and homemakers were ever mules, a model could classify by occupation alone. The mitigation is that "salaried employee" is in the mule list and all occupations appear in `NO_CONCERN`, so occupation is correlated with the label without determining it.

If an interviewer asks about leakage, this is a good honest answer: "Occupation is partly informative by design, which mirrors reality but does create a shortcut. I limited it by overlapping the lists. A cleaner v2 would measure how much the model relies on it by permuting occupation at test time."

---

## 4.7 Saving and loading

```python
def alert_to_dict(alert: RawAlert) -> dict:
    ...
    "window_start": alert.window_start.isoformat(),
    ...

def alert_from_dict(data: dict) -> RawAlert:
    ...
    window_start=date.fromisoformat(data["window_start"]),
```

JSON has no date type, so dates become ISO strings (`"2026-05-23"`) on the way out and are parsed back on the way in. ISO 8601 is chosen because it sorts correctly as text — `"2026-05-23" < "2026-06-01"` is true as a string comparison, which is not true of `"23/05/2026"` style formats.

```python
lines = [json.dumps(alert_to_dict(alert), sort_keys=True) for alert in alerts]
(folder / f"{split}.jsonl").write_text("\n".join(lines) + "\n")
```

`sort_keys=True` makes the output deterministic: the same data always produces byte-identical files, so `git diff` shows real changes rather than reordered keys.

`Customer(**data["customer"])` is **dictionary unpacking**: it turns `{"customer_id": "C-1", "occupation": "student", ...}` into keyword arguments. It works only because the JSON keys exactly match the dataclass field names — a small, deliberate coupling.

---

## 4.8 Exercises

1. Set `EVERYDAY_CASH_CAP` to `0.95 * CASH_REPORTING_LIMIT` in a scratch copy, regenerate, and run `python -m pytest tests/test_features.py -k pattern`. Which test fails, and why?
2. Explain in two sentences why `_add` stores `len(self._rows)` as the second tuple element.
3. Add a fifth hard negative, `insurance_payout`: one large credit, then 50% into a fixed deposit and 50% spent over two weeks. Which existing hard negative does it most resemble, and what feature separates them?
4. Change `SEED` to 43 and regenerate. Do the tests still pass? What does that tell you about whether the tests depend on specific values?
5. In `build_recipes`, replace `number % len(HARD_NEGATIVE_KINDS)` with `rng.choice(HARD_NEGATIVE_KINDS)`. What property of the dataset do you lose?
